/**
 * Created by sahila.r on 10/24/2016.
 */
/**
 * Created by sahila.r on 10/24/2016.
 */
declare class Controller {
    constructor();
}
export = Controller;
