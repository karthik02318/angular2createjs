/**
 * Created by sahila.r on 10/24/2016.
 */
/**
 * Created by sahila.r on 10/24/2016.
 */
"use strict";
var Controller = (function () {
    function Controller() {
    }
    return Controller;
}()); //end
module.exports = Controller;
//# sourceMappingURL=Controller.js.map