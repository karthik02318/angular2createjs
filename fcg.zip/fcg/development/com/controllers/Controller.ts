/**
 * Created by sahila.r on 10/24/2016.
 */
/**
 * Created by sahila.r on 10/24/2016.
 */

class Controller
{
    constructor() {

    }

}//end
export=Controller;