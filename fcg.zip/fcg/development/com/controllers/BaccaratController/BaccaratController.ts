/**
 * Created by sahila.r on 10/24/2016.
 */

import Controller=require("../../controllers/Controller");
import View=require("../../views/ui/View");
class BaccaratController extends Controller
{
    constructor() {
        super();

    }


}//this end baccaratcontroller
