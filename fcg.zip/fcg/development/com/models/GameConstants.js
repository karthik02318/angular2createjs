"use strict";
/**
 * Created by sahila.r on 10/24/2016.
 */
var GameConstants = (function () {
    function GameConstants() {
    }
    ;
    return GameConstants;
}());
module.exports = GameConstants;
//# sourceMappingURL=GameConstants.js.map