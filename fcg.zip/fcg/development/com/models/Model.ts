/**
 * Created by sahila.r on 10/24/2016.
 */

class Model
{

    constructor() {

    }



}//this is end Model
export=Model;