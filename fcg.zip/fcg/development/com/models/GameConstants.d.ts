/**
 * Created by sahila.r on 10/24/2016.
 */
declare class GameConstants {
    static COMMONASSETS: any;
    static GAMEASSETS: any;
    static DATALANGUAGE: any;
    constructor();
}
export = GameConstants;
