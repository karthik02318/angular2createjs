/**
 * Created by sahila.r on 10/24/2016.
 */
"use strict";
var Model = (function () {
    function Model() {
    }
    return Model;
}()); //this is end Model
module.exports = Model;
//# sourceMappingURL=Model.js.map