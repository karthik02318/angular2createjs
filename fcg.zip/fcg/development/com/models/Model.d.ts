/**
 * Created by sahila.r on 10/24/2016.
 */
declare class Model {
    constructor();
}
export = Model;
