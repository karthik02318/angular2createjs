/**
 * Created by sahila.r on 10/24/2016.
 */
class GameConstants
{
    public static COMMONASSETS;
    public static GAMEASSETS;
    public static DATALANGUAGE;
    constructor() {};
}
export=GameConstants;