/**
 * Created by sahila.r on 10/24/2016.
 */
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Model = require("../Model");
var BaccaratModel = (function (_super) {
    __extends(BaccaratModel, _super);
    function BaccaratModel() {
        _super.call(this);
    }
    return BaccaratModel;
}(Model)); //this is end Model
module.exports = BaccaratModel;
//# sourceMappingURL=BaccaratModel.js.map