/**
 * Created by sahila.r on 10/24/2016.
 */

import Model=require("../Model");
import Controller=require("../../Controllers/Controller");
import Event = createjs.Event;

class BaccaratModel extends Model
{
    constructor() {
        super();
    }


}//this is end Model
export=BaccaratModel;
