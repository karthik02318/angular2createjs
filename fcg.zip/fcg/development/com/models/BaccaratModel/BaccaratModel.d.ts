/**
 * Created by sahila.r on 10/24/2016.
 */
import Model = require("../Model");
declare class BaccaratModel extends Model {
    constructor();
}
export = BaccaratModel;
