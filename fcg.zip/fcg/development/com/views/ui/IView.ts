/**
 * Created by sahila.r on 10/24/2016.
 */
interface IView {
    showGame():void;
    languageChanged():void;
}
export = IView;