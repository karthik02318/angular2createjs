/**
 * Created by sahila.r on 10/24/2016.
 */
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var View = (function (_super) {
    __extends(View, _super);
    function View() {
        var _this = this;
        _super.call(this);
        this.init = function (game) {
            _this.gameView = new game;
            _this.gameView.showGame();
            _this.gameView.languageChanged();
        };
    }
    return View;
}(createjs.Container)); //end
module.exports = View;
//# sourceMappingURL=View.js.map