/**
 * Created by sahila.r on 10/24/2016.
 */
declare class View extends createjs.Container {
    private gameView;
    constructor();
    init: (game: any) => void;
}
export = View;
