/// <reference path="../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts" />
import IView = require("../IView");
import View = require("../View");
declare class BaccaratView extends View implements IView {
    seatNum: number;
    totalBet: number;
    boardStage: any;
    chipPlacement: any;
    minBetLimit: number;
    maxBetLimit: number;
    balance: number;
    boardContent: any;
    private betbar;
    private letMainBet;
    private curSeatArr;
    private betspotArr;
    private baccaratRuleArr;
    private betLimit;
    private selectedChip;
    constructor();
    showGame: () => void;
    private enableBoard;
    private showBetbar;
    private selectedChipHandler;
    private betSpotClickHandler;
    private betAmountUpdate;
    private betLogicHandler;
    private betSpotOverHandler;
    private betSpotOutHandler;
    private betspotUpdation;
    languageChanged: () => void;
}
export = BaccaratView;
