"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
var ChipPlacement = require("../../../component/ChipPlacement");
var GameConstants = require("../../../models/GameConstants");
var Betbar = require("../../../views/ui/BaccaratView/com/Betbar");
var Event = createjs.Event;
var View = require("../View");
var BaccaratTrend = require("./com/trend/BaccaratTrend");
var BaccaratView = (function (_super) {
    __extends(BaccaratView, _super);
    function BaccaratView() {
        var _this = this;
        _super.call(this);
        this.seatNum = 4;
        this.totalBet = 0;
        this.minBetLimit = 5;
        this.maxBetLimit = 500;
        this.balance = 450;
        this.betbar = new Betbar();
        this.letMainBet = 0;
        this.curSeatArr = new Array("banker_", "player_", "tie_mc", "mc_minus_2", "mc_minus_3", "mc_plus_2", "mc_plus_3");
        this.betspotArr = new Array("mc_minus_2", "mc_plus_2", "tie_mc", "mc_minus_3", "mc_plus_3", "banker_7", "banker_6", "banker_5", "banker_4", "banker_3", "banker_2", "banker_1", "player_7", "player_6", "player_5", "player_4", "player_3", "player_2", "player_1");
        this.baccaratRuleArr = ["tie_mc", "mc_minus_2", "mc_minus_3", "mc_plus_2", "mc_plus_3"];
        this.betLimit = [1, 5, 25, 100, 500];
        this.selectedChip = 1;
        this.showGame = function () {
            _this.chipPlacement.commonDesign = GameConstants.COMMONASSETS;
            _this.chipPlacement.betlimit = _this.betLimit;
            _this.boardContent = new GameConstants.GAMEASSETS.bgMC;
            _this.boardStage.enableMouseOver(10);
            _this.boardContent["textMC"].mouseEnabled = false;
            for (var k = 0; k < _this.betspotArr.length; k++) {
                var spotName = _this.betspotArr[k];
                _this.boardContent[spotName].gotoAndStop("rout");
                _this.boardContent[spotName].name = spotName;
                var helper = new createjs.ButtonHelper(_this.boardContent[spotName]);
                _this.boardContent[spotName].cursor = "default";
                _this.boardContent[spotName].removeEventListener("click", _this.betSpotClickHandler);
                _this.boardContent[spotName].removeEventListener("mouseover", _this.betSpotOverHandler);
                _this.boardContent[spotName].removeEventListener("mouseout", _this.betSpotOutHandler);
                _this.boardContent[spotName].gotoAndStop("rout");
            }
            _this.enableBoard();
            _this.boardStage.addChild(_this.boardContent);
            _this.showBetbar();
            var baccaratTrend = new BaccaratTrend();
            baccaratTrend.createBigPathTrend(_this.boardStage);
            _this.boardStage.addChild(baccaratTrend);
            _this.boardStage.update();
        };
        this.enableBoard = function () {
            for (var k = 0; k < _this.curSeatArr.length; k++) {
                var spName = _this.curSeatArr[k];
                if (spName == "banker_" || spName == "player_") {
                    spName = spName + _this.seatNum;
                }
                _this.boardContent[spName].mouseEnabled = true;
                _this.boardContent[spName].cursor = "pointer";
                _this.boardContent[spName].addEventListener("click", _this.betSpotClickHandler);
                _this.boardContent[spName].addEventListener("mouseover", _this.betSpotOverHandler);
                _this.boardContent[spName].addEventListener("mouseout", _this.betSpotOutHandler);
            }
        };
        this.showBetbar = function () {
            _this.betbar.commonDesign = GameConstants.COMMONASSETS;
            _this.betbar.init(GameConstants.GAMEASSETS, _this.betLimit, _this);
            _this.betbar.addEventListener("chipSelected", _this.selectedChipHandler);
            _this.boardStage.update();
        };
        this.selectedChipHandler = function (event) {
            _this.selectedChip = event.data;
        };
        this.betSpotClickHandler = function (evt) {
            var curChip = _this.betspotUpdation(evt.currentTarget);
            var getSpotDetails = [];
            if (curChip.name == "banker_" + _this.seatNum) {
                getSpotDetails[0] = _this.chipPlacement.getBetSpotAmt("player_" + _this.seatNum);
                getSpotDetails[1] = "player_";
            }
            else if (curChip.name == "player_" + _this.seatNum) {
                getSpotDetails[0] = _this.chipPlacement.getBetSpotAmt("banker_" + _this.seatNum);
                getSpotDetails[1] = "banker_";
            }
            else {
                var getNum = _this.betLogicHandler(curChip.name);
                getSpotDetails[0] = getNum;
                getSpotDetails[1] = undefined;
                if (_this.chipPlacement.getBetSpotAmt("banker_" + _this.seatNum) > 0) {
                    _this.letMainBet = _this.chipPlacement.getBetSpotAmt("banker_" + _this.seatNum);
                }
                if (_this.chipPlacement.getBetSpotAmt("player_" + _this.seatNum) > 0) {
                    _this.letMainBet = _this.chipPlacement.getBetSpotAmt("player_" + _this.seatNum);
                }
                var sidebet = _this.chipPlacement.getBetSpotAmt(curChip.name) + _this.selectedChip;
                if (sidebet > _this.letMainBet && curChip.name != "tie_mc_" + _this.seatNum) {
                    alert("Side bets cannot exceed Banker/Player/Tie bets");
                    getSpotDetails[0] = sidebet;
                    getSpotDetails[1] = "null";
                }
            }
            if (getSpotDetails[0] == 0) {
                var totalAmt = _this.totalBet + _this.selectedChip;
                if (totalAmt <= _this.maxBetLimit) {
                    if (_this.selectedChip <= _this.balance) {
                        _this.chipPlacement.placebet(curChip, curChip.name, _this.selectedChip, _this.boardStage);
                        _this.totalBet += _this.selectedChip;
                        _this.betAmountUpdate(_this.totalBet);
                        _this.balance -= _this.selectedChip;
                        _this.betbar.updateBalance(_this.balance);
                    }
                    else {
                        alert("Not enought money");
                    }
                }
                else {
                    alert("All bets must be at or below the maximum of " + _this.maxBetLimit);
                }
            }
            else {
                if (getSpotDetails[1] == "player_" || getSpotDetails[1] == "banker_") {
                    alert("That bet conflicts with your bets placed on the table");
                }
                else if (getSpotDetails[1] == undefined) {
                    alert("Only one side bet allowed per hand.");
                }
            }
            //TweenMax.to(this.chipmcc, 1, {x:700,ease:Elastic.easeOut});
            //createjs.Ticker.addEventListener("tick", this.boardStage);
            _this.boardStage.update();
        };
        this.betAmountUpdate = function (totalbet) {
            var dataEvent = new Event("updateChipAmt", false, false);
            dataEvent.data = totalbet;
            _this.betbar.dispatchEvent(dataEvent);
        };
        this.betLogicHandler = function (betSptName) {
            var getSpotAmt = 0;
            for (var jj = 0; jj < _this.baccaratRuleArr.length; jj++) {
                var chBetSpot = _this.baccaratRuleArr[jj] + "_" + _this.seatNum;
                if (chBetSpot != betSptName) {
                    getSpotAmt = _this.chipPlacement.getBetSpotAmt(chBetSpot);
                    if (getSpotAmt != 0) {
                        return getSpotAmt;
                    }
                }
            }
            return getSpotAmt;
        };
        this.betSpotOverHandler = function (evt) {
            evt.currentTarget.gotoAndStop("rover");
            _this.boardStage.update();
        };
        this.betSpotOutHandler = function (evt) {
            evt.currentTarget.gotoAndStop("rout");
            _this.boardStage.update();
        };
        this.betspotUpdation = function (Object) {
            if (Object.name == "tie_mc" || Object.name == "mc_minus_2" || Object.name == "mc_minus_3" || Object.name == "mc_plus_2" || Object.name == "mc_plus_3") {
                _this.chipPlacement.chipScale = 25;
                var cname = Object.name + "_" + _this.seatNum;
                Object = _this.boardContent[cname];
                Object.name = cname;
            }
            else {
                _this.chipPlacement.chipScale = 40;
            }
            return Object;
        };
        this.languageChanged = function () {
            console.log("dispatching");
            var event = new Event("languagechanged", false, false);
            _this.dispatchEvent(event);
        };
        this.boardStage = new createjs.Stage("stageCanvas");
        this.chipPlacement = new ChipPlacement();
        this.chipPlacement.chipScale = 40;
        this.boardStage.update();
    }
    return BaccaratView;
}(View));
module.exports = BaccaratView;
//# sourceMappingURL=BaccaratView - Copy.js.map