"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GameConstants = require("../../../../models/GameConstants");
var Event = createjs.Event;
var BetBarButton = (function (_super) {
    __extends(BetBarButton, _super);
    function BetBarButton() {
        var _this = this;
        _super.call(this);
        this.init = function (parentObj) {
            _this.parentObj = parentObj;
            _this.betBarBtn = new _this.commonDesign.betbarBtn();
            _this.betBarBtn.x = 0;
            _this.betBarBtn.y = 0;
            _this.betBarBtn.gotoAndStop(0);
            _this.betbarStg.enableMouseOver(10);
            _this.addChild(_this.betBarBtn);
            _this.selectedBtn = _this.betBarBtn.bet_btn;
            _this.enableDisable(_this.betBarBtn.bet_btn, "bet_btn", true);
            _this.enableDisable(_this.betBarBtn.clear_btn, "clear_btn", true);
            _this.enableDisable(_this.betBarBtn.rebet_btn, "rebet_btn", true);
            _this.parentObj.parentObj.addEventListener("languagechanged", _this.languageChanged);
            // this.betbarStg.update();
        };
        this.enableDisable = function (object, objname, isTrue) {
            if (isTrue) {
                object.mouseEnabled = isTrue;
                object.cursor = "pointer";
                object.gotoAndStop("rout");
                object.name = objname;
                object.addEventListener("click", _this.betBarBtnHandler);
                object.addEventListener("mouseover", _this.betBarBtnOverHandler);
                object.addEventListener("mouseout", _this.betBarBtnOutHandler);
            }
            else {
                object.mouseEnabled = isTrue;
                object.cursor = "default";
                object.removeEventListener("click", _this.betBarBtnHandler);
                object.removeEventListener("mouseover", _this.betBarBtnOverHandler);
                object.removeEventListener("mouseout", _this.betBarBtnOutHandler);
            }
        };
        this.betBarBtnHandler = function (evt) {
            switch (evt.currentTarget.name) {
                case "bet_btn":
                    _this.betHandler();
                    break;
                case "clear_btn":
                    _this.clearBetHandler();
                    break;
                case "rebet_btn":
                    _this.reBetHandler();
                    break;
            }
        };
        this.lastBetArr = [];
        this.betHandler = function () {
            if (_this.totalBet() < _this.parentObj.parentObj.minBetLimit) {
                alert("All bets must meet the minimum of" + _this.parentObj.parentObj.minBetLimit);
            }
            else {
                _this.lastBetArr = [];
                _this.lastBetUpdate();
                _this.isConfirm = true;
            }
        };
        this.isConfirm = false;
        this.clearBetHandler = function () {
            if (_this.isConfirm == false) {
                var getTotal = _this.totalBet();
                var bal = _this.parentObj.parentObj.balance + getTotal;
                _this.parentObj.updateBalance(bal);
            }
            var dataEvent = new Event("updateChipAmt", false, false);
            _this.parentObj.parentObj.totalBet = 0;
            dataEvent.data = 0;
            _this.parentObj.dispatchEvent(dataEvent);
            _this.parentObj.parentObj.chipPlacement.clearAllBetSpot();
            _this.parentObj.parentObj.boardStage.update();
        };
        this.reBetHandler = function () {
            alert(_this.lastbetTotal + "  " + _this.parentObj.parentObj.balance);
            if (_this.lastbetTotal <= _this.parentObj.parentObj.balance) {
                for (var j = 0; j < _this.lastBetArr.length; j++) {
                    var chipAmt = _this.lastBetArr[j].amount;
                    _this.parentObj.parentObj.chipPlacement.placebet(_this.lastBetArr[j], _this.lastBetArr[j].name, chipAmt, _this.parentObj.parentObj.boardStage);
                }
                _this.parentObj.parentObj.betAmountUpdate(_this.lastbetTotal);
            }
            else {
                alert("Not enought money");
            }
        };
        this.btnYpos = 38.6;
        this.betBarBtnOverHandler = function (evt) {
            evt.currentTarget.gotoAndStop("rover");
            TweenMax.to(_this.selectedBtn, 0.25, { y: _this.btnYpos });
            TweenMax.to(evt.currentTarget, 0.25, { y: _this.btnYpos - 10 });
            _this.selectedBtn = evt.currentTarget;
            createjs.Ticker.addEventListener("tick", _this.betbarStg);
            _this.betbarStg.update();
        };
        this.betBarBtnOutHandler = function (evt) {
            evt.currentTarget.gotoAndStop("rout");
            TweenMax.to(_this.selectedBtn, 0.25, { y: _this.btnYpos });
            createjs.Ticker.addEventListener("tick", _this.betbarStg);
            _this.betbarStg.update();
        };
        this.totalBet = function () {
            var total = 0;
            for (var j = 0; j <= _this.parentObj.parentObj.chipPlacement.betPlacedArr.length; j++) {
                var btname = _this.parentObj.parentObj.chipPlacement.betPlacedArr[j];
                total += _this.parentObj.parentObj.chipPlacement.getBetSpotAmt(btname);
            }
            return total;
        };
        this.lastbetTotal = 0;
        this.lastBetUpdate = function () {
            _this.lastbetTotal = 0;
            for (var j = 0; j < _this.parentObj.parentObj.chipPlacement.betPlacedArr.length; j++) {
                var btname = _this.parentObj.parentObj.chipPlacement.betPlacedArr[j];
                for (var m = 0; m < _this.parentObj.parentObj.chipPlacement.betSptArr[btname].length; m++) {
                    var chipAmt = _this.parentObj.parentObj.chipPlacement.betSptArr[btname][m].amount;
                    _this.lastbetTotal += chipAmt;
                    _this.lastBetArr.push(_this.parentObj.parentObj.chipPlacement.betSptArr[btname][m]);
                }
            }
        };
        this.languageChanged = function (event) {
            console.log("changed in languageChanged");
            _this.betBarBtn.bet_btn.betTxtMC.blkbetTxt.text = GameConstants.DATALANGUAGE.bet;
            _this.betBarBtn.bet_btn.betTxtMC.whitebetTxt.text = GameConstants.DATALANGUAGE.bet;
            _this.betBarBtn.clear_btn.betTxtMC.blkbetTxt.text = GameConstants.DATALANGUAGE.clear;
            _this.betBarBtn.clear_btn.betTxtMC.whitebetTxt.text = GameConstants.DATALANGUAGE.clear;
            _this.betBarBtn.rebet_btn.betTxtMC.blkbetTxt.text = GameConstants.DATALANGUAGE.rebet;
            _this.betBarBtn.rebet_btn.betTxtMC.whitebetTxt.text = GameConstants.DATALANGUAGE.rebet;
        };
    }
    return BetBarButton;
}(createjs.Container)); //end
module.exports = BetBarButton;
//# sourceMappingURL=BetBarButton.js.map