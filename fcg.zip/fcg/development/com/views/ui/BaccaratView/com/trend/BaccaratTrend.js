"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
/// <reference path="../../../../../../assets/commonAssets/commonObject.d.ts"/>
var GameConstants = require("../../../../../models/GameConstants");
var HorizontalScrollBar = require("com/component/HorizontalScrollBar");
var BaccaratTrend = (function (_super) {
    __extends(BaccaratTrend, _super);
    function BaccaratTrend() {
        var _this = this;
        _super.call(this);
        //private len:number=0;
        // private row:number=6;
        //private div:number=5;
        this.beadPlateContainer = new createjs.Container();
        this.bigRoadContainer = new createjs.Container();
        this.bigEyeBoyContainer = new createjs.Container();
        this.smallRoadContainer = new createjs.Container();
        this.cockroachPigContainer = new createjs.Container();
        this.beadPlateArr = [];
        this.bigRoadArr = [];
        this.builderArr = [];
        this.bigEyeBoyArr = [];
        this.smallRoadArr = [];
        this.cockroachArr = [];
        this.coln = 0;
        this.secondEntry = 1;
        this.cellLeft = 1;
        this.cellUp = 1;
        this.checkFir = 1;
        this.checkSec = 1;
        this.trendArray = [0, 1, 0, 0, 1, 0, 0, 2, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1];
        this.createBigPathTrend = function (stage) {
            //this.baccaratStg=stage;
            _this.simpleStage = new createjs.Stage("simpleCanvas");
            var tempArr = [];
            for (var len = 0; len < _this.trendArray.length; len++) {
                var trendMov = new GameConstants.GAMEASSETS.solidCircle();
                trendMov.gotoAndStop(0);
                trendMov.ht = trendMov.nominalBounds.height;
                trendMov.wh = trendMov.nominalBounds.width;
                trendMov.txt.text = _this.trendArray[len];
                if (_this.trendArray[len] == 1) {
                    trendMov.gotoAndStop(1);
                }
                else if (_this.trendArray[len] == 2) {
                    trendMov.gotoAndStop(2);
                }
                tempArr.push(trendMov);
                if (tempArr.length == 6) {
                    _this.beadPlateArr.push(tempArr);
                    tempArr = [];
                }
                _this.beadPlateContainer.addChild(trendMov);
            }
            _this.beadPlateScrollbar = new HorizontalScrollBar();
            _this.beadPlateArr.push(tempArr);
            _this.showBGHandler(_this.beadPlateContainer, _this.beadPlateArr, _this.beadPlateScrollbar, 0, 0, _this.simpleStage);
            _this.simpleStage.addChild(_this.beadPlateContainer);
            _this.scorePortraitHandler(_this.beadPlateArr);
            _this.createBigRoad();
            var green = new GameConstants.GAMEASSETS.greenBtn();
            stage.addChild(green);
            var red = new GameConstants.GAMEASSETS.redBtn();
            stage.addChild(red);
            green.addEventListener("click", _this.greenBtnHandler);
            green.x = 650;
            green.y = 250;
            red.x = 570;
            red.y = 250;
            red.addEventListener("click", _this.redBtnHandler);
            _this.simpleStage.update();
        };
        this.greenBtnHandler = function (evt) {
            _this.trendArray.push(1);
            _this.updateBeadPlateHandler();
        };
        this.redBtnHandler = function (evt) {
            _this.trendArray.push(0);
            _this.updateBeadPlateHandler();
        };
        this.createBigRoad = function () {
            _this.sequanceStage = new createjs.Stage("squenceCanvas");
            _this.bigRoadScrollbar = new HorizontalScrollBar();
            _this.creatingStatsArr(_this.trendArray, _this.bigRoadArr, _this.bigRoadContainer, GameConstants.GAMEASSETS.bigRoad, _this.sequanceStage);
            _this.scorePortraitHandler(_this.bigRoadArr);
            _this.showBGHandler(_this.bigRoadContainer, _this.bigRoadArr, _this.bigRoadScrollbar, 0, 0, _this.sequanceStage);
            _this.sequanceStage.update();
            // this.createBigEyeBoy();
            // this.createSmallRoad();
            // this.createCockroachPig();
        };
        this.createBigEyeBoy = function () {
            _this.coln = 1;
            _this.secondEntry = 1;
            _this.cellLeft = 1;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 1;
            _this.checkFir = 1;
            _this.checkSec = 2;
            _this.bigEyeBoyContainer.y = 240;
            _this.updateArrHandler(newCol, existCol, _this.bigEyeBoyArr, _this.bigEyeBoyContainer, GameConstants.GAMEASSETS.bigEyeBoy);
        };
        this.createSmallRoad = function () {
            _this.builderArr = [];
            _this.coln = 2;
            _this.secondEntry = 1;
            _this.cellLeft = 2;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 2;
            _this.checkFir = 1;
            _this.checkSec = 3;
            _this.smallRoadContainer.y = 360;
            _this.updateArrHandler(newCol, existCol, _this.smallRoadArr, _this.smallRoadContainer, GameConstants.GAMEASSETS.smallRoad);
        };
        this.createCockroachPig = function () {
            _this.builderArr = [];
            _this.coln = 3;
            _this.secondEntry = 1;
            _this.cellLeft = 3;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 3;
            _this.checkFir = 1;
            _this.checkSec = 4;
            _this.cockroachPigContainer.y = 480;
            _this.updateArrHandler(newCol, existCol, _this.cockroachArr, _this.cockroachPigContainer, GameConstants.GAMEASSETS.cockroachRoad);
        };
        this.updateArrHandler = function (newCol, existCol, productArr, container, asset) {
            if (_this.bigRoadArr[_this.coln][_this.secondEntry] == undefined) {
                newCol++;
                _this.checkNewColumn(newCol, existCol, _this.builderArr);
            }
            else {
                _this.exstingEntry(newCol, existCol, _this.builderArr);
            }
            // this.creatingStatsArr(this.builderArr,productArr,container,asset);
            _this.scorePortraitHandler(productArr);
        };
        this.checkNewColumn = function (newCol, existCol, arr) {
            if (_this.bigRoadArr[newCol] != undefined) {
                if (_this.bigRoadArr[newCol - _this.checkFir].length == _this.bigRoadArr[newCol - _this.checkSec].length) {
                    arr.push(0);
                }
                else {
                    arr.push(1);
                }
                _this.exstingEntry(newCol, existCol, arr);
            }
        };
        this.exstingEntry = function (newCol, existCol, arr) {
            if (_this.bigRoadArr[newCol][existCol] != undefined) {
                if (typeof (_this.bigRoadArr[newCol - _this.cellLeft][existCol]) == typeof (_this.bigRoadArr[newCol - _this.cellLeft][existCol - _this.cellUp])) {
                    arr.push(0);
                }
                else {
                    arr.push(1);
                }
                existCol++;
                _this.exstingEntry(newCol, existCol, arr);
            }
            else {
                newCol++;
                _this.checkNewColumn(newCol, 1, _this.builderArr);
            }
        };
        this.creatingStatsArr = function (getArray, setArray, container, asset, stage) {
            var tempArr = [];
            for (var len = 0; len < getArray.length; len++) {
                var trendMov = new asset();
                trendMov.gotoAndStop(0);
                if (trendMov.tie != undefined) {
                    trendMov.tie.visible = false;
                }
                trendMov.ht = trendMov.nominalBounds.height;
                trendMov.wh = trendMov.nominalBounds.width;
                trendMov.val = getArray[len];
                container.addChild(trendMov);
                if (getArray[len] == 1) {
                    trendMov.gotoAndStop(1);
                }
                if (len == 0) {
                    tempArr.push(trendMov);
                }
                else if (getArray[len - 1] == getArray[len] || getArray[len - 1] == 2 && trendMov.tie != undefined) {
                    tempArr.push(trendMov);
                }
                else if (getArray[len] == 2 && len != 0) {
                    tempArr[tempArr.length - 1].tie.visible = true;
                }
                else {
                    setArray.push(tempArr);
                    tempArr = [];
                    tempArr.push(trendMov);
                }
            }
            setArray.push(tempArr);
            stage.addChild(container);
            stage.update();
        };
        this.scorePortraitHandler = function (statsArr) {
            var lShape = false;
            var move = 0;
            var lValue = 6;
            for (var col = 0; col < statsArr.length; col++) {
                for (var row = 0; row < statsArr[col].length; row++) {
                    statsArr[col][row].x = (statsArr[col][row].wh) * col;
                    if (row < lValue) {
                        statsArr[col][row].y = statsArr[col][row].ht * row;
                        lShape = false;
                    }
                    else {
                        move++;
                        statsArr[col][row].y = statsArr[col][row].ht * (row - move);
                        statsArr[col][row].x = statsArr[col][row].x + (statsArr[col][row].ht) * move;
                        lShape = true;
                    }
                }
                if (lShape) {
                    lValue--;
                    move = 0;
                }
            }
        };
        this.updateBigRoad = function () {
            var tempArr = [];
            var trendMov = new GameConstants.GAMEASSETS.bigRoad();
            trendMov.gotoAndStop(0);
            if (trendMov.tie != undefined) {
                trendMov.tie.visible = false;
            }
            trendMov.ht = trendMov.nominalBounds.height;
            trendMov.wh = trendMov.nominalBounds.width;
            var len = _this.trendArray.length - 1;
            if (_this.trendArray[len] == 1) {
                trendMov.gotoAndStop(1);
            }
            if (_this.trendArray[len - 1] == _this.trendArray[len] || _this.trendArray[len - 1] == 2) {
                _this.bigRoadArr[_this.bigRoadArr.length - 1].push(trendMov);
                _this.bigRoadContainer.addChild(trendMov);
                _this.scorePortraitHandler(_this.bigRoadArr);
            }
            else if (_this.trendArray[len] == 2 && len != 0) {
                _this.bigRoadArr[_this.bigRoadArr.length - 1].tie.visible = true;
                _this.bigRoadContainer.addChild(trendMov);
                _this.scorePortraitHandler(_this.bigRoadArr);
            }
            else {
                alert("new");
                tempArr = [];
                tempArr.push(trendMov);
                _this.bigRoadArr.push(tempArr);
                _this.bigRoadContainer.addChild(trendMov);
                _this.scorePortraitHandler(_this.bigRoadArr);
            }
        };
        this.updateBigEyeBoyRoad = function () {
            _this.cellLeft = 1;
            _this.checkFir = 1;
            _this.checkSec = 2;
            _this.updateAllRoads(_this.bigEyeBoyArr, _this.bigEyeBoyContainer, GameConstants.GAMEASSETS.bigEyeBoy);
        };
        this.updateSmallRoad = function () {
            _this.cellLeft = 2;
            _this.checkFir = 1;
            _this.checkSec = 3;
            _this.updateAllRoads(_this.smallRoadArr, _this.smallRoadContainer, GameConstants.GAMEASSETS.smallRoad);
        };
        this.updateCockroachPig = function () {
            _this.cellLeft = 3;
            _this.checkFir = 1;
            _this.checkSec = 4;
            _this.updateAllRoads(_this.cockroachArr, _this.cockroachPigContainer, GameConstants.GAMEASSETS.cockroachRoad);
        };
        this.updateAllRoads = function (currArr, container, assets) {
            var newCol = _this.bigRoadArr.length - 1;
            var trendMov = new assets();
            trendMov.gotoAndStop(0);
            trendMov.ht = trendMov.nominalBounds.height;
            trendMov.wh = trendMov.nominalBounds.width;
            if (_this.bigRoadArr[_this.bigRoadArr.length - 1].length > 1) {
                var existCol = _this.bigRoadArr[_this.bigRoadArr.length - 1].length - 1;
                if (_this.bigRoadArr[newCol][existCol] != undefined) {
                    if (typeof (_this.bigRoadArr[newCol - _this.cellLeft][existCol]) == typeof (_this.bigRoadArr[newCol - _this.cellLeft][existCol - _this.cellUp])) {
                        trendMov.gotoAndStop(0);
                        _this.updateSameType(currArr, trendMov);
                    }
                    else {
                        trendMov.gotoAndStop(1);
                        _this.updateSameType(currArr, trendMov);
                    }
                }
            }
            else {
                if (_this.bigRoadArr[newCol] != undefined) {
                    if (_this.bigRoadArr[newCol - _this.checkFir].length == _this.bigRoadArr[newCol - _this.checkSec].length) {
                        trendMov.gotoAndStop(0);
                        _this.updateSameType(currArr, trendMov);
                    }
                    else {
                        trendMov.gotoAndStop(1);
                        _this.updateSameType(currArr, trendMov);
                    }
                }
            }
            container.addChild(trendMov);
            _this.scorePortraitHandler(currArr);
        };
        this.updateSameType = function (currArr, trendMov) {
            if (currArr[currArr.length - 1][0].currentFrame == trendMov.currentFrame) {
                currArr[currArr.length - 1].push(trendMov);
            }
            else {
                var tempArr = [];
                tempArr.push(trendMov);
                currArr.push(tempArr);
            }
        };
        this.addScrollBar = function (content, xval, yval, scrollbar, stg) {
            var content = content;
            var slider = new GameConstants.COMMONASSETS.slider();
            var track = new GameConstants.COMMONASSETS.track();
            var cMask = new GameConstants.COMMONASSETS.contentMask();
            var contentMask = new createjs.Shape();
            contentMask.graphics.drawRect(cMask.x, cMask.y, cMask.nominalBounds.width, cMask.nominalBounds.height);
            contentMask.setBounds(cMask.x, cMask.y, cMask.nominalBounds.width, cMask.nominalBounds.height);
            scrollbar.init(content, contentMask, track, slider, .5, stg, xval, yval);
            stg.addChild(scrollbar);
            stg.update();
        };
        this.showBGHandler = function (container, statsArr, scrollbar, xv, yv, stage) {
            var bgArr = [];
            var len = statsArr.length + 2;
            var widt = 0;
            for (var row = 0; row < 6; row++) {
                bgArr[row] = [];
                for (var col = 0; col < len; col++) {
                    var bgBox = new GameConstants.GAMEASSETS.checkBox();
                    bgArr[row].push(bgBox);
                    widt = bgBox.nominalBounds.width;
                    bgBox.x = bgBox.nominalBounds.width * col;
                    bgBox.y = bgArr[row][col].nominalBounds.height * row;
                    if (col % 2 != 0 && row % 2 != 0) {
                        bgBox.gotoAndStop(0);
                    }
                    else if (col % 2 != 0 && row % 2 == 0) {
                        bgBox.gotoAndStop(1);
                    }
                    else if (col % 2 == 0 && row % 2 == 0) {
                        bgBox.gotoAndStop(0);
                    }
                    container.addChildAt(bgArr[row][col], 0);
                }
            }
            container.setBounds(0, 0, len * widt);
            _this.addScrollBar(container, xv, yv, scrollbar, stage);
            stage.update();
        };
        this.updateBGHandler = function (container, updateArr, scrollbar, stage) {
            var bgArr = [];
            var len = updateArr.length + 2;
            var widt = 0;
            for (var row = 0; row < 6; row++) {
                bgArr[row] = [];
                for (var col = len - 1; col < len; col++) {
                    var bgBox = new GameConstants.GAMEASSETS.checkBox();
                    bgArr[row].push(bgBox);
                    widt = bgBox.nominalBounds.width;
                    bgBox.x = bgBox.nominalBounds.width * col;
                    bgBox.y = bgBox.nominalBounds.height * row;
                    if (col % 2 != 0 && row % 2 != 0) {
                        bgBox.gotoAndStop(0);
                    }
                    else if (col % 2 != 0 && row % 2 == 0) {
                        bgBox.gotoAndStop(1);
                    }
                    else if (col % 2 == 0 && row % 2 == 0) {
                        bgBox.gotoAndStop(0);
                    }
                    container.addChildAt(bgBox, 0);
                }
            }
            container.setBounds(0, 0, len * widt);
            scrollbar.updateContent(container);
            stage.update();
        };
    }
    //--------------------------------------------------below code for updation---------------------------------------------
    BaccaratTrend.prototype.updateBeadPlateHandler = function () {
        var temArr = [];
        var trendMov = new GameConstants.GAMEASSETS.solidCircle();
        trendMov.gotoAndStop(0);
        trendMov.ht = trendMov.nominalBounds.height;
        trendMov.wh = trendMov.nominalBounds.width;
        trendMov.txt.text = this.trendArray[this.trendArray[this.trendArray.length - 1]];
        if (trendMov.txt.text == 1) {
            trendMov.gotoAndStop(1);
        }
        if (this.beadPlateArr[this.beadPlateArr.length - 1].length > 5) {
            temArr = [];
            temArr.push(trendMov);
            this.beadPlateArr.push(temArr);
            this.beadPlateContainer.addChild(trendMov);
            this.scorePortraitHandler(this.beadPlateArr);
            this.updateBGHandler(this.beadPlateContainer, this.beadPlateArr, this.beadPlateScrollbar, this.simpleStage);
        }
        else {
            this.beadPlateArr[this.beadPlateArr.length - 1].push(trendMov);
            this.beadPlateContainer.addChild(trendMov);
            this.scorePortraitHandler(this.beadPlateArr);
        }
        //   this.updateBigRoad();
        //  this.updateBigEyeBoyRoad();
        //   this.updateSmallRoad();
        // this.updateCockroachPig();
    };
    return BaccaratTrend;
}(createjs.Container)); //end
module.exports = BaccaratTrend;
//# sourceMappingURL=BaccaratTrend.js.map