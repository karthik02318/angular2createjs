/// <reference path="../../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
/// <reference path="../../../../../../assets/commonAssets/commonObject.d.ts"/>
import GameConstants=require("../../../../../models/GameConstants");
import HorizontalScrollBar=require("com/component/HorizontalScrollBar");

class BaccaratTrend extends createjs.Container
{
    //private len:number=0;
   // private row:number=6;
    //private div:number=5;
    private beadPlateContainer=new createjs.Container();
    private bigRoadContainer=new createjs.Container();
    private bigEyeBoyContainer=new createjs.Container();
    private smallRoadContainer=new createjs.Container();
    private cockroachPigContainer=new createjs.Container();
    private beadPlateArr=[];
    private baccaratStg;
    private bigRoadArr=[];
    private builderArr=[];
    private bigEyeBoyArr=[];
    private smallRoadArr=[];
    private cockroachArr=[];
    private coln:number=0;
    private secondEntry:number=1;
    private cellLeft:number=1;
    private cellUp:number=1;
    private checkFir:number=1;
    private checkSec:number=1;
    //private content;
    //private contentMask;
    //private track;
    //private slider;
    private beadPlateScrollbar;
    private bigRoadScrollbar;
    private bigEyeScrollbar;
    private smallScrollbar;
    private cockroachScrollbar;
    private simpleStage;
    private sequanceStage;
    private trendArray = [0, 1, 0, 0, 1, 0, 0, 2, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0,1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1];
    constructor() {
        super();

    }
    public createBigPathTrend=(stage):void=>
    {
        //this.baccaratStg=stage;
        this.simpleStage= new createjs.Stage("simpleCanvas");
        var tempArr=[];
        for(var len=0;len<this.trendArray.length;len++) {
            var trendMov=new GameConstants.GAMEASSETS.solidCircle();
            trendMov.gotoAndStop(0);
            trendMov.ht=trendMov.nominalBounds.height;
            trendMov.wh=trendMov.nominalBounds.width;
            trendMov.txt.text = this.trendArray[len];
            if(this.trendArray[len]==1)
            {
                trendMov.gotoAndStop(1);
            }else if(this.trendArray[len]==2)
            {
                trendMov.gotoAndStop(2);
            }
            tempArr.push(trendMov);
            if(tempArr.length==6)
            {
                this.beadPlateArr.push(tempArr);
                tempArr=[];
            }
            this.beadPlateContainer.addChild(trendMov);
        }
        this.beadPlateScrollbar=new HorizontalScrollBar();
        this.beadPlateArr.push(tempArr);
        this.showBGHandler(this.beadPlateContainer,this.beadPlateArr,this.beadPlateScrollbar,0,0,this.simpleStage);
        this.simpleStage.addChild( this.beadPlateContainer);
        this.scorePortraitHandler(this.beadPlateArr);
        this.createBigRoad();

        var green=new GameConstants.GAMEASSETS.greenBtn();
        stage.addChild(green);
        var red=new GameConstants.GAMEASSETS.redBtn();
        stage.addChild(red);

        green.addEventListener("click", this.greenBtnHandler);
        green.x=650;
        green.y=250;
        red.x=570;
        red.y=250;
        red.addEventListener("click", this.redBtnHandler);
        this.simpleStage.update();
    };

    private greenBtnHandler=(evt):void=>
    {
        this.trendArray.push(1);
        this.updateBeadPlateHandler();
    };
    private redBtnHandler=(evt):void=>
    {
        this.trendArray.push(0);
        this.updateBeadPlateHandler();
    };
    private createBigRoad=()=>
    {
        this.sequanceStage=new createjs.Stage("squenceCanvas");
        this.bigRoadScrollbar=new HorizontalScrollBar();
        this.creatingStatsArr(this.trendArray,this.bigRoadArr,this.bigRoadContainer,GameConstants.GAMEASSETS.bigRoad,this.sequanceStage);
        this.scorePortraitHandler(this.bigRoadArr);
        this.showBGHandler(this.bigRoadContainer,this.bigRoadArr,this.bigRoadScrollbar,0,0,this.sequanceStage);
        this.sequanceStage.update()
       // this.createBigEyeBoy();
       // this.createSmallRoad();
       // this.createCockroachPig();

    };
    private createBigEyeBoy=():void=>
    {
        this.coln=1;
        this.secondEntry=1;
        this.cellLeft=1;
        this.cellUp=1;
        var existCol=1;
        var newCol=1;
        this.checkFir=1;
        this.checkSec=2;
        this.bigEyeBoyContainer.y=240;
        this.updateArrHandler(newCol,existCol,this.bigEyeBoyArr,this.bigEyeBoyContainer,GameConstants.GAMEASSETS.bigEyeBoy);
    };
    private createSmallRoad=():void=>
    {
        this.builderArr=[];
        this.coln=2;
        this.secondEntry=1;
        this.cellLeft=2;
        this.cellUp=1;
        var existCol=1;
        var newCol=2;
        this.checkFir=1;
        this.checkSec=3;
        this.smallRoadContainer.y=360;
        this.updateArrHandler(newCol,existCol,this.smallRoadArr,this.smallRoadContainer,GameConstants.GAMEASSETS.smallRoad)
    };
    private createCockroachPig=():void=>
    {
        this.builderArr=[];
        this.coln=3;
        this.secondEntry=1;
        this.cellLeft=3;
        this.cellUp=1;
        var existCol=1;
        var newCol=3;
        this.checkFir=1;
        this.checkSec=4;
        this.cockroachPigContainer.y=480;
        this.updateArrHandler(newCol,existCol,this.cockroachArr,this.cockroachPigContainer,GameConstants.GAMEASSETS.cockroachRoad)
    };
    private updateArrHandler=(newCol,existCol,productArr,container,asset):void=>
    {

        if(this.bigRoadArr[this.coln][this.secondEntry]==undefined)
        {
            newCol++;
            this.checkNewColumn(newCol,existCol,this.builderArr);
        }else
        {
            this.exstingEntry(newCol, existCol, this.builderArr);
        }
       // this.creatingStatsArr(this.builderArr,productArr,container,asset);
        this.scorePortraitHandler(productArr);

    };
    private checkNewColumn=(newCol,existCol,arr):void=>
    {
        if(this.bigRoadArr[newCol]!=undefined) {

            if (this.bigRoadArr[newCol - this.checkFir].length == this.bigRoadArr[newCol - this.checkSec].length) {
               arr.push(0);

           } else {
               arr.push(1);
           }
        this.exstingEntry(newCol, existCol, arr);
       }
    };
    private exstingEntry=(newCol,existCol,arr):void=>
    {
        if(this.bigRoadArr[newCol][existCol]!=undefined) {

            if (typeof(this.bigRoadArr[newCol - this.cellLeft][existCol]) == typeof(this.bigRoadArr[newCol - this.cellLeft][existCol - this.cellUp])) {

                arr.push(0);
            } else {

                arr.push(1);
            }
            existCol++;
            this.exstingEntry(newCol,existCol,arr)
        }else
        {
            newCol++;
            this.checkNewColumn(newCol, 1, this.builderArr);
        }

    };
    private creatingStatsArr=(getArray,setArray,container,asset,stage):void=>
    {
        var tempArr=[];
        for(var len=0;len<getArray.length;len++) {

            var trendMov=new asset();
            trendMov.gotoAndStop(0);

            if(trendMov.tie!=undefined) {
                trendMov.tie.visible = false;
            }
            trendMov.ht=trendMov.nominalBounds.height;
            trendMov.wh=trendMov.nominalBounds.width;
            trendMov.val=getArray[len];
            container.addChild(trendMov);
            if(getArray[len]==1)
            {
                trendMov.gotoAndStop(1);
            }
            if(len==0)
            {
                tempArr.push(trendMov);
            }else if(getArray[len-1]==getArray[len] || getArray[len-1]==2 && trendMov.tie!=undefined)
            {
                tempArr.push(trendMov);
            }else if(getArray[len]==2 && len!=0)//not for very first tie
            {

                tempArr[tempArr.length-1].tie.visible=true;

            }
            else
            {
                setArray.push(tempArr);
                tempArr=[];
                tempArr.push(trendMov);
            }

        }
        setArray.push(tempArr);
        stage.addChild(container);
        stage.update()
    };

    private scorePortraitHandler=(statsArr):void=>
    {
        var lShape:Boolean=false;
        var move:number=0;
        var lValue:number=6;

        for(var col=0; col<statsArr.length; col++)
        {
          for(var row=0;row<statsArr[col].length;row++)
            {
                statsArr[col][row].x=(statsArr[col][row].wh)*col;

                if(row<lValue) {
                    statsArr[col][row].y = statsArr[col][row].ht * row;
                    lShape=false;
                }else{
                    move++;
                    statsArr[col][row].y =  statsArr[col][row].ht * (row-move);
                    statsArr[col][row].x= statsArr[col][row].x+(statsArr[col][row].ht)*move;
                    lShape=true;
                }

            }
            if(lShape)
            {
                lValue--;
                move=0;
            }
        }


    };
//--------------------------------------------------below code for updation---------------------------------------------
    private updateBeadPlateHandler()
    {
        var temArr=[];
        var trendMov=new GameConstants.GAMEASSETS.solidCircle();
        trendMov.gotoAndStop(0);
        trendMov.ht=trendMov.nominalBounds.height;
        trendMov.wh=trendMov.nominalBounds.width;
        trendMov.txt.text = this.trendArray[this.trendArray[this.trendArray.length-1]];
        if(trendMov.txt.text==1)
        {
            trendMov.gotoAndStop(1);
        }
        if(this.beadPlateArr[this.beadPlateArr.length-1].length>5)
        {
            temArr=[];
            temArr.push(trendMov);
            this.beadPlateArr.push(temArr);
            this.beadPlateContainer.addChild(trendMov);
            this.scorePortraitHandler(this.beadPlateArr);
            this.updateBGHandler(this.beadPlateContainer,this.beadPlateArr,this.beadPlateScrollbar,this.simpleStage)

        }else
        {

            this.beadPlateArr[this.beadPlateArr.length-1].push(trendMov);
            this.beadPlateContainer.addChild(trendMov);
            this.scorePortraitHandler(this.beadPlateArr);
        }


     //   this.updateBigRoad();
      //  this.updateBigEyeBoyRoad();
     //   this.updateSmallRoad();
       // this.updateCockroachPig();
    }
    private updateBigRoad=():void=>
    {
        var tempArr=[];
        var trendMov=new GameConstants.GAMEASSETS.bigRoad();
        trendMov.gotoAndStop(0);
        if(trendMov.tie!=undefined) {
            trendMov.tie.visible = false;
        }
        trendMov.ht=trendMov.nominalBounds.height;
        trendMov.wh=trendMov.nominalBounds.width;
        var len=this.trendArray.length-1;
        if(this.trendArray[len]==1)
        {
            trendMov.gotoAndStop(1);
        }
        if(this.trendArray[len-1]==this.trendArray[len] || this.trendArray[len-1]==2)
        {
            this.bigRoadArr[this.bigRoadArr.length-1].push(trendMov);
            this.bigRoadContainer.addChild(trendMov);
            this.scorePortraitHandler(this.bigRoadArr);
        }
        else if(this.trendArray[len]==2 && len!=0)//not for very first tie
        {

            this.bigRoadArr[this.bigRoadArr.length-1].tie.visible=true;
            this.bigRoadContainer.addChild(trendMov);
            this.scorePortraitHandler(this.bigRoadArr);
        }
        else
        {
            alert("new");
            tempArr=[];
            tempArr.push(trendMov);
            this.bigRoadArr.push(tempArr);
            this.bigRoadContainer.addChild(trendMov);
            this.scorePortraitHandler(this.bigRoadArr);
            //this.updateBGHandler(this.bigRoadContainer,this.bigRoadArr,this.bigRoadScrollbar)
        }

    };
    private updateBigEyeBoyRoad=():void=>
    {
        this.cellLeft=1;
        this.checkFir=1;
        this.checkSec=2;
        this.updateAllRoads(this.bigEyeBoyArr,this.bigEyeBoyContainer,GameConstants.GAMEASSETS.bigEyeBoy);

    };
    private updateSmallRoad=():void=>
    {
        this.cellLeft=2;
        this.checkFir=1;
        this.checkSec=3;
        this.updateAllRoads(this.smallRoadArr,this.smallRoadContainer,GameConstants.GAMEASSETS.smallRoad);
    };
    private updateCockroachPig=():void=>
    {
        this.cellLeft=3;
        this.checkFir=1;
        this.checkSec=4;
        this.updateAllRoads(this.cockroachArr,this.cockroachPigContainer,GameConstants.GAMEASSETS.cockroachRoad);
    };
    private updateAllRoads=(currArr,container,assets):void=>
    {
        var newCol = this.bigRoadArr.length - 1;
        var trendMov = new assets();
        trendMov.gotoAndStop(0);
        trendMov.ht = trendMov.nominalBounds.height;
        trendMov.wh = trendMov.nominalBounds.width;
        if(this.bigRoadArr[this.bigRoadArr.length-1].length>1) {

            var existCol = this.bigRoadArr[this.bigRoadArr.length - 1].length - 1;

            if (this.bigRoadArr[newCol][existCol] != undefined) {

                if (typeof(this.bigRoadArr[newCol- this.cellLeft][existCol]) == typeof(this.bigRoadArr[newCol - this.cellLeft][existCol - this.cellUp])) {
                    trendMov.gotoAndStop(0);
                    this.updateSameType(currArr, trendMov);

                } else {
                    trendMov.gotoAndStop(1);
                    this.updateSameType(currArr, trendMov);

                }
            }
        }else {

            if (this.bigRoadArr[newCol] != undefined) {

                if (this.bigRoadArr[newCol - this.checkFir].length == this.bigRoadArr[newCol - this.checkSec].length) {
                    trendMov.gotoAndStop(0);
                    this.updateSameType(currArr, trendMov);

                } else {
                    trendMov.gotoAndStop(1);
                    this.updateSameType(currArr, trendMov);
                }
            }
        }
        container.addChild(trendMov);
        this.scorePortraitHandler(currArr);

    };
    private updateSameType=(currArr,trendMov):void=>
    {
        if(currArr[currArr.length-1][0].currentFrame==trendMov.currentFrame)
        {
            currArr[currArr.length-1].push(trendMov);
        }else {
            var tempArr=[];
            tempArr.push(trendMov);
            currArr.push(tempArr);
        }
    };
    private addScrollBar=(content,xval,yval,scrollbar,stg):void=>
    {
        var content=content;
        var slider=new GameConstants.COMMONASSETS.slider();
        var track=new GameConstants.COMMONASSETS.track();
        var cMask=new GameConstants.COMMONASSETS.contentMask();
        var contentMask=new createjs.Shape();
            contentMask.graphics.drawRect(cMask.x,cMask.y,cMask.nominalBounds.width,cMask.nominalBounds.height);
            contentMask.setBounds(cMask.x,cMask.y,cMask.nominalBounds.width,cMask.nominalBounds.height);

        scrollbar.init(content,contentMask,track,slider,.5,stg,xval,yval);
        stg.addChild(scrollbar);
        stg.update()
    };

    private showBGHandler=(container,statsArr,scrollbar,xv,yv,stage):void=>
    {
        var bgArr=[];
        var len=statsArr.length+2;
        var widt=0;
        for(var row=0;row<6;row++)
        {
            bgArr[row]=[];
            for(var col=0;col<len;col++)
            {
                var bgBox=new GameConstants.GAMEASSETS.checkBox();
                bgArr[row].push(bgBox);
                widt=bgBox.nominalBounds.width;
                bgBox.x= bgBox.nominalBounds.width*col;
                bgBox.y= bgArr[row][col].nominalBounds.height*row;
                if(col%2!=0 && row%2!=0)
                {
                    bgBox.gotoAndStop(0);
                }else if(col%2!=0 && row%2==0)
                {
                    bgBox.gotoAndStop(1);
                }else if(col%2==0 && row%2==0){
                    bgBox.gotoAndStop(0)
                }
                container.addChildAt(bgArr[row][col],0);
            }
        }
        container.setBounds(0,0,len*widt);
        this.addScrollBar(container,xv,yv,scrollbar,stage);
        stage.update()
    };
    private updateBGHandler=(container,updateArr,scrollbar,stage):void=>
    {
        var bgArr=[];
        var len=updateArr.length+2;
        var widt=0;
        for(var row=0; row<6; row++)
        {
            bgArr[row]=[];
            for(var col=len-1;col<len;col++)
            {
                var bgBox=new GameConstants.GAMEASSETS.checkBox();
                bgArr[row].push(bgBox);
                widt=bgBox.nominalBounds.width;
                bgBox.x= bgBox.nominalBounds.width*col;
                bgBox.y= bgBox.nominalBounds.height*row;

                if(col%2!=0 && row%2!=0)
                {
                    bgBox.gotoAndStop(0);
                }else if(col%2!=0 && row%2==0)
                {
                    bgBox.gotoAndStop(1);
                }else if(col%2==0 && row%2==0){
                    bgBox.gotoAndStop(0)
                }
                container.addChildAt(bgBox,0);
            }
        }
        container.setBounds(0,0,len*widt);
        scrollbar.updateContent(container);
        stage.update()
    };
    //------------------------------------------------------------------------------------------------------------------
}//end
export = BaccaratTrend


