/// <reference path="../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ChipTray = require("../../../../component/ChipTray");
var Event = createjs.Event;
var BetBarButton = require("./BetBarButton");
var GameConstants = require("../../../../models/GameConstants");
var Betbar = (function (_super) {
    __extends(Betbar, _super);
    function Betbar() {
        var _this = this;
        _super.call(this);
        this.init = function (gamedesign, betlimitArr, parentObj) {
            _this.parentObj = parentObj;
            _this.gameDesign = gamedesign;
            _this.betbarStg = new createjs.Stage("bbarCanvas");
            _this.addBGHandler();
            _this.chipTrayHandler(betlimitArr);
            _this.addBBarButton();
            _this.updateBetlimitPanel();
            _this.updateBalance(parentObj.balance);
            _this.addEventListener("updateChipAmt", _this.betBarUpdation);
            _this.parentObj.addEventListener("languagechanged", _this.languageChanged);
            _this.betbarStg.update();
        };
        this.updateBetlimitPanel = function () {
            _this.betBarMC.dealerVal.text = "Admin";
            _this.betBarMC.betlimitVal.text = _this.parentObj.minBetLimit + " - " + _this.parentObj.maxBetLimit;
        };
        this.updateBalance = function (balance) {
            _this.betBarMC.balanceVal.text = balance;
            _this.parentObj.balance = balance;
        };
        this.chipTrayHandler = function (betlimitArr) {
            _this.chipTray = new ChipTray();
            _this.chipTray.commonDesign = _this.commonDesign;
            _this.chipTray.addEventListener("chipSelected", _this.selectedChipHandler);
            _this.chipTray.betbarStg = _this.betbarStg;
            _this.chipTray.createChip(betlimitArr);
            _this.chipTray.y = 10;
            _this.chipTray.x = 440;
            _this.betBarMC.addChild(_this.chipTray);
        };
        this.addBBarButton = function () {
            _this.betbarButton = new BetBarButton();
            _this.betbarButton.commonDesign = _this.commonDesign;
            _this.betbarButton.betbarStg = _this.betbarStg;
            _this.betBarMC.addChild(_this.betbarButton);
            _this.betbarButton.init(_this);
        };
        this.selectedChipHandler = function (event) {
            var dataEvent = new Event("chipSelected", false, false);
            dataEvent.data = event.data;
            _this.dispatchEvent(dataEvent);
        };
        this.showBetbar = function () {
            // this.showBGHandler();
            // this.showBBarButton();
            // this.betbarStg.update(); 
        };
        this.addBGHandler = function () {
            _this.betBarMC = new _this.gameDesign.betbarMC();
            _this.betbarStg.addChild(_this.betBarMC);
            //this.betbarStg.update(); 
        };
        this.betBarUpdation = function (event) {
            _this.betBarMC.betAmountVal.text = event.data;
            _this.betbarStg.update();
        };
        this.languageChanged = function (event) {
            console.log("changed in betbar");
            _this.betBarMC.dealerTxt.text = GameConstants.DATALANGUAGE.dealer;
            _this.betBarMC.betLimitTxt.text = GameConstants.DATALANGUAGE.betlimit;
            _this.betBarMC.betAmountTxt.text = GameConstants.DATALANGUAGE.betamount;
            _this.betBarMC.balanceTxt.text = GameConstants.DATALANGUAGE.balance;
            _this.betbarStg.update();
        };
    }
    return Betbar;
}(createjs.Container)); //end betbar class
module.exports = Betbar;
//# sourceMappingURL=Betbar.js.map