/**
 * Created by sahila.r on 10/20/2016.
 */
import ChipPlacement=require("../../../../component/ChipPlacement");
import GameConstants=require("../../../../models/GameConstants");
import Event = createjs.Event;

class BetBarButton extends createjs.Container
{
    public commonDesign;
    public betbarStg;
    private betBarBtn;
    private parentObj;
    private selectedBtn;
    constructor() {
        super();
    }
    public init=(parentObj):void=>
    {
        this.parentObj=parentObj;
        this.betBarBtn=new this.commonDesign.betbarBtn();
        this.betBarBtn.x=0;
        this.betBarBtn.y=0;
        this.betBarBtn.gotoAndStop(0);
        this.betbarStg.enableMouseOver(10);
        this.addChild(this.betBarBtn);
        this.selectedBtn=this.betBarBtn.bet_btn;
        this.enableDisable(this.betBarBtn.bet_btn,"bet_btn",true);
        this.enableDisable(this.betBarBtn.clear_btn,"clear_btn",true);
        this.enableDisable(this.betBarBtn.rebet_btn,"rebet_btn",true);
        this.parentObj.parentObj.addEventListener("languagechanged",this.languageChanged);
        // this.betbarStg.update();
    };
    private enableDisable=(object,objname,isTrue):void=>
    {
        if(isTrue) {
            object.mouseEnabled = isTrue;
            object.cursor = "pointer";
            object.gotoAndStop("rout");
            object.name=objname;
            object.addEventListener("click", this.betBarBtnHandler);
            object.addEventListener("mouseover", this.betBarBtnOverHandler);
            object.addEventListener("mouseout", this.betBarBtnOutHandler);
        }else
        {
            object.mouseEnabled = isTrue;
            object.cursor = "default";
            object.removeEventListener("click", this.betBarBtnHandler);
            object.removeEventListener("mouseover", this.betBarBtnOverHandler);
            object.removeEventListener("mouseout", this.betBarBtnOutHandler);
        }

    };
    private betBarBtnHandler=(evt):void=>
    {
        switch (evt.currentTarget.name){

            case "bet_btn":
                this.betHandler();
                break;

            case "clear_btn":
                this.clearBetHandler();
                break;

            case "rebet_btn":
                this.reBetHandler();
                break;

        }
    };
    private lastBetArr=[];

    private betHandler=():void=>
    {
        if(this.totalBet()<this.parentObj.parentObj.minBetLimit)
        {
            alert("All bets must meet the minimum of"+this.parentObj.parentObj.minBetLimit);
        }else
        {
            this.lastBetArr=[];
            this.lastBetUpdate();
            this.isConfirm=true;
        }
    }
    private isConfirm=false;
    private clearBetHandler=():void=>
    {
       if(this.isConfirm==false)
        {
            var getTotal=this.totalBet();
            var bal=this.parentObj.parentObj.balance+getTotal;
            this.parentObj.updateBalance(bal);
        }
        var dataEvent = new Event("updateChipAmt", false, false);
        this.parentObj.parentObj.totalBet=0;
        dataEvent.data = 0;
        this.parentObj.dispatchEvent(dataEvent);
        this.parentObj.parentObj.chipPlacement.clearAllBetSpot();
        this.parentObj.parentObj.boardStage.update();
    }

    private reBetHandler=():void=>
    {
        alert(this.lastbetTotal+"  "+this.parentObj.parentObj.balance);
        if(this.lastbetTotal<=this.parentObj.parentObj.balance)
        {

            for(var j=0; j<this.lastBetArr.length;j++)
            {
                var chipAmt =this.lastBetArr[j].amount;
                this.parentObj.parentObj.chipPlacement.placebet(this.lastBetArr[j], this.lastBetArr[j].name, chipAmt, this.parentObj.parentObj.boardStage);
            }
            this.parentObj.parentObj.betAmountUpdate(this.lastbetTotal);
        }else
        {
            alert("Not enought money");
        }

    };
    private btnYpos=38.6;
    private betBarBtnOverHandler=(evt):void=>
    {
        evt.currentTarget.gotoAndStop("rover");
        TweenMax.to(this.selectedBtn, 0.25, {y:this.btnYpos});
        TweenMax.to( evt.currentTarget, 0.25, {y:this.btnYpos-10});
        this.selectedBtn=evt.currentTarget;
        createjs.Ticker.addEventListener("tick", this.betbarStg);
        this.betbarStg.update();
    };
    private betBarBtnOutHandler=(evt):void=>
    {
        evt.currentTarget.gotoAndStop("rout");
        TweenMax.to(this.selectedBtn, 0.25, {y:this.btnYpos});
        createjs.Ticker.addEventListener("tick", this.betbarStg);
        this.betbarStg.update();
    };
    private totalBet=():number=>
    {
        var total=0;
        for(var j=0; j<=this.parentObj.parentObj.chipPlacement.betPlacedArr.length;j++)
        {
            var btname=this.parentObj.parentObj.chipPlacement.betPlacedArr[j];
            total+=this.parentObj.parentObj.chipPlacement.getBetSpotAmt(btname);
        }

    return total;
    };
    private lastbetTotal=0;
    private lastBetUpdate=():void=>
    {
        this.lastbetTotal=0;
        for(var j=0; j<this.parentObj.parentObj.chipPlacement.betPlacedArr.length;j++)
        {
            var btname=this.parentObj.parentObj.chipPlacement.betPlacedArr[j];
            for(var m=0; m<this.parentObj.parentObj.chipPlacement.betSptArr[btname].length; m++) {
                var chipAmt =this.parentObj.parentObj.chipPlacement.betSptArr[btname][m].amount;
                this.lastbetTotal+=chipAmt;
                this.lastBetArr.push(this.parentObj.parentObj.chipPlacement.betSptArr[btname][m])
            }

        }
    };
    public languageChanged=(event):void=> {
        console.log("changed in languageChanged");
        this.betBarBtn.bet_btn.betTxtMC.blkbetTxt.text=GameConstants.DATALANGUAGE.bet;
        this.betBarBtn.bet_btn.betTxtMC.whitebetTxt.text=GameConstants.DATALANGUAGE.bet;

        this.betBarBtn.clear_btn.betTxtMC.blkbetTxt.text=GameConstants.DATALANGUAGE.clear;
        this.betBarBtn.clear_btn.betTxtMC.whitebetTxt.text=GameConstants.DATALANGUAGE.clear;

        this.betBarBtn.rebet_btn.betTxtMC.blkbetTxt.text=GameConstants.DATALANGUAGE.rebet;
        this.betBarBtn.rebet_btn.betTxtMC.whitebetTxt.text=GameConstants.DATALANGUAGE.rebet;

    }

    }//end
export = BetBarButton;