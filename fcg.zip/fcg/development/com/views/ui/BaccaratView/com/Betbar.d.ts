/// <reference path="../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts" />
declare class Betbar extends createjs.Container {
    commonDesign: any;
    private betbarStg;
    private betBarMC;
    private gameDesign;
    private chipTray;
    private parentObj;
    private betbarButton;
    constructor();
    init: (gamedesign: any, betlimitArr: any, parentObj: any) => void;
    private updateBetlimitPanel;
    updateBalance: (balance: any) => void;
    private chipTrayHandler;
    private addBBarButton;
    private selectedChipHandler;
    showBetbar: () => void;
    addBGHandler: () => void;
    betBarUpdation: (event: any) => void;
    languageChanged: (event: any) => void;
}
export = Betbar;
