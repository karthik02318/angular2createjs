"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
var GameConstants = require("../../../../../models/GameConstants");
var BaccaratTrend = (function (_super) {
    __extends(BaccaratTrend, _super);
    function BaccaratTrend() {
        var _this = this;
        _super.call(this);
        this.len = 0;
        this.row = 6;
        this.div = 5;
        this.beadPlateContainer = new createjs.Container();
        this.bigRoadContainer = new createjs.Container();
        this.bigEyeBoyContainer = new createjs.Container();
        this.smallRoadContainer = new createjs.Container();
        this.cockroachPigContainer = new createjs.Container();
        this.beadPlateArr = [];
        this.bigRoadArr = [];
        this.builderArr = [];
        this.bigEyeBoyArr = [];
        this.smallRoadArr = [];
        this.cockroachArr = [];
        this.coln = 0;
        this.secondEntry = 1;
        this.cellLeft = 1;
        this.cellUp = 1;
        this.checkFir = 1;
        this.checkSec = 1;
        this.trendArray = [0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1];
        this.createBigPathTrend = function (stage) {
            _this.baccaratStg = stage;
            var tempArr = [];
            for (var len = 0; len < _this.trendArray.length; len++) {
                var trendMov = new GameConstants.GAMEASSETS.solidCircle();
                trendMov.gotoAndStop(0);
                trendMov.ht = trendMov.nominalBounds.height;
                trendMov.wh = trendMov.nominalBounds.width;
                trendMov.txt.text = _this.trendArray[len];
                if (_this.trendArray[len] == 1) {
                    trendMov.gotoAndStop(1);
                }
                tempArr.push(trendMov);
                if (tempArr.length == 6) {
                    _this.beadPlateArr.push(tempArr);
                    tempArr = [];
                }
                _this.beadPlateContainer.addChild(trendMov);
            }
            _this.beadPlateArr.push(tempArr);
            _this.baccaratStg.addChild(_this.beadPlateContainer);
            _this.scorePortraitHandler(_this.beadPlateArr);
            //  this.showStatsHandler(this.beadPlateArr, this.beadPlateContainer,GameConstants.GAMEASSETS.solidCircle);
            _this.createBigRoad();
            var green = new GameConstants.GAMEASSETS.greenBtn();
            stage.addChild(green);
            var red = new GameConstants.GAMEASSETS.redBtn();
            stage.addChild(red);
            green.addEventListener("click", _this.greenBtnHandler);
            green.x = 650;
            green.y = 250;
            red.x = 570;
            red.y = 250;
            red.addEventListener("click", _this.redBtnHandler);
            stage.update();
        };
        this.greenBtnHandler = function (evt) {
            _this.trendArray.push(1);
            _this.updateBeadPlateHandler();
        };
        this.redBtnHandler = function (evt) {
            _this.trendArray.push(0);
            _this.updateBeadPlateHandler();
        };
        this.createBigRoad = function () {
            _this.creatingStatsArr(_this.trendArray, _this.bigRoadArr);
            _this.showStatsHandler(_this.bigRoadArr, _this.bigRoadContainer, GameConstants.GAMEASSETS.bigRoad);
            _this.bigRoadContainer.y = 120;
            _this.createBigEyeBoy();
            _this.createSmallRoad();
            _this.createCockroachPig();
        };
        this.createBigEyeBoy = function () {
            _this.coln = 1;
            _this.secondEntry = 1;
            _this.cellLeft = 1;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 1;
            _this.checkFir = 1;
            _this.checkSec = 2;
            _this.bigEyeBoyContainer.y = 240;
            _this.updateArrHandler(newCol, existCol, _this.bigEyeBoyArr, _this.bigEyeBoyContainer, GameConstants.GAMEASSETS.bigEyeBoy);
        };
        this.createSmallRoad = function () {
            _this.builderArr = [];
            _this.coln = 2;
            _this.secondEntry = 1;
            _this.cellLeft = 2;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 2;
            _this.checkFir = 1;
            _this.checkSec = 3;
            _this.smallRoadContainer.y = 360;
            _this.updateArrHandler(newCol, existCol, _this.smallRoadArr, _this.smallRoadContainer, GameConstants.GAMEASSETS.smallRoad);
        };
        this.createCockroachPig = function () {
            _this.builderArr = [];
            _this.coln = 3;
            _this.secondEntry = 1;
            _this.cellLeft = 3;
            _this.cellUp = 1;
            var existCol = 1;
            var newCol = 3;
            _this.checkFir = 1;
            _this.checkSec = 4;
            _this.cockroachPigContainer.y = 480;
            _this.updateArrHandler(newCol, existCol, _this.cockroachArr, _this.cockroachPigContainer, GameConstants.GAMEASSETS.cockroachRoad);
        };
        this.updateArrHandler = function (newCol, existCol, productArr, container, asset) {
            if (_this.bigRoadArr[_this.coln][_this.secondEntry] == undefined) {
                newCol++;
                _this.checkNewColumn(newCol, existCol, _this.builderArr);
            }
            else {
                _this.exstingEntry(newCol, existCol, _this.builderArr);
            }
            _this.creatingStatsArr(_this.builderArr, productArr);
            _this.showStatsHandler(productArr, container, asset);
        };
        this.checkNewColumn = function (newCol, existCol, arr) {
            if (_this.bigRoadArr[newCol] != undefined) {
                if (_this.bigRoadArr[newCol - _this.checkFir].length == _this.bigRoadArr[newCol - _this.checkSec].length) {
                    arr.push(0);
                }
                else {
                    arr.push(1);
                }
                _this.exstingEntry(newCol, existCol, arr);
            }
        };
        this.exstingEntry = function (newCol, existCol, arr) {
            if (_this.bigRoadArr[newCol][existCol] != undefined) {
                if (_this.bigRoadArr[newCol - _this.cellLeft][existCol] == _this.bigRoadArr[newCol - _this.cellLeft][existCol - _this.cellUp]) {
                    arr.push(0);
                }
                else {
                    arr.push(1);
                }
                existCol++;
                _this.exstingEntry(newCol, existCol, arr);
            }
            else {
                newCol++;
                _this.checkNewColumn(newCol, 1, _this.builderArr);
            }
        };
        this.creatingStatsArr = function (getArray, setArray) {
            var tempArr = [];
            for (var len = 0; len < getArray.length; len++) {
                if (len == 0) {
                    tempArr.push(getArray[len]);
                }
                else if (getArray[len - 1] == getArray[len]) {
                    tempArr.push(getArray[len]);
                }
                else {
                    setArray.push(tempArr);
                    tempArr = [];
                    tempArr.push(getArray[len]);
                }
            }
            setArray.push(tempArr);
        };
        this.scorePortraitHandler = function (statsArr) {
            var lShape = false;
            var move = 0;
            var lValue = 6;
            for (var col = 0; col < statsArr.length; col++) {
                for (var row = 0; row < statsArr[col].length; row++) {
                    statsArr[col][row].x = (statsArr[col][row].wh + 2) * col;
                    statsArr[col][row].y = 0;
                    if (row < lValue) {
                        statsArr[col][row].y = (statsArr[col][row].y + statsArr[col][row].ht) * row;
                        lShape = false;
                    }
                    else {
                        move++;
                        statsArr[col][row].y = (statsArr[col][row].y + statsArr[col][row].ht) * (row - move);
                        statsArr[col][row].x = statsArr[col][row].x + (statsArr[col][row].ht + 2) * move;
                        lShape = true;
                    }
                }
                if (lShape) {
                    lValue--;
                    move = 0;
                }
            }
            _this.baccaratStg.update();
        };
        this.showStatsHandler = function (statsArr, container, assets) {
            var lShape = false;
            var move = 0;
            var lValue = 6;
            for (var col = 0; col < statsArr.length; col++) {
                for (var row = 0; row < statsArr[col].length; row++) {
                    var trendMov = new assets();
                    trendMov.gotoAndStop(0);
                    if (trendMov.txt != undefined) {
                        trendMov.txt.text = statsArr[col][row];
                    }
                    if (statsArr[col][row] == 1) {
                        trendMov.gotoAndStop(1);
                    }
                    trendMov.x = (trendMov.nominalBounds.width + 2) * col;
                    if (row < lValue) {
                        trendMov.y = (trendMov.y + trendMov.nominalBounds.height) * row;
                        lShape = false;
                    }
                    else {
                        move++;
                        trendMov.y = (trendMov.y + trendMov.nominalBounds.height) * (row - move);
                        trendMov.x = trendMov.x + (trendMov.nominalBounds.width + 2) * move;
                        lShape = true;
                    }
                    container.addChild(trendMov);
                }
                if (lShape) {
                    lValue--;
                    move = 0;
                }
            }
            _this.baccaratStg.addChild(container);
            _this.baccaratStg.update();
        };
    }
    BaccaratTrend.prototype.updateBeadPlateHandler = function () {
        var temArr = [];
        var trendMov = new GameConstants.GAMEASSETS.solidCircle();
        trendMov.gotoAndStop(0);
        trendMov.ht = trendMov.nominalBounds.height;
        trendMov.wh = trendMov.nominalBounds.width;
        trendMov.txt.text = this.trendArray[this.trendArray[this.trendArray.length - 1]];
        if (trendMov.txt.text == 1) {
            trendMov.gotoAndStop(1);
        }
        if (this.beadPlateArr[this.beadPlateArr.length - 1].length > 5) {
            temArr = [];
            temArr.push(trendMov);
            this.beadPlateArr.push(temArr);
        }
        else {
            this.beadPlateArr[this.beadPlateArr.length - 1].push(trendMov);
        }
        this.beadPlateContainer.addChild(trendMov);
        this.scorePortraitHandler(this.beadPlateArr);
    };
    return BaccaratTrend;
}(createjs.Container)); //end
module.exports = BaccaratTrend;
//# sourceMappingURL=BaccaratTrend - Copy.js.map