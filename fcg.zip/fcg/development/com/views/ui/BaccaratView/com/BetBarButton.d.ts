declare class BetBarButton extends createjs.Container {
    commonDesign: any;
    betbarStg: any;
    private betBarBtn;
    private parentObj;
    private selectedBtn;
    constructor();
    init: (parentObj: any) => void;
    private enableDisable;
    private betBarBtnHandler;
    private lastBetArr;
    private betHandler;
    private isConfirm;
    private clearBetHandler;
    private reBetHandler;
    private btnYpos;
    private betBarBtnOverHandler;
    private betBarBtnOutHandler;
    private totalBet;
    private lastbetTotal;
    private lastBetUpdate;
    languageChanged: (event: any) => void;
}
export = BetBarButton;
