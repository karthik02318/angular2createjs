/// <reference path="../../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>

import ChipTray=require("../../../../component/ChipTray");
import Event = createjs.Event;
import BetBarButton=require("./BetBarButton");
import GameConstants=require("../../../../models/GameConstants");

class Betbar extends createjs.Container
{
    public commonDesign;
    private betbarStg;
    private betBarMC;
    private gameDesign;
    private chipTray;
    private parentObj;
    private betbarButton;

           constructor() {
            super();
        }

    public init=(gamedesign,betlimitArr,parentObj):void=>
    {
        this.parentObj=parentObj;
        this.gameDesign=gamedesign;
        this.betbarStg= new createjs.Stage("bbarCanvas");
        this.addBGHandler();
        this.chipTrayHandler(betlimitArr);
        this.addBBarButton();
        this.updateBetlimitPanel();
        this.updateBalance(parentObj.balance);
        this.addEventListener("updateChipAmt",this.betBarUpdation);
        this.parentObj.addEventListener("languagechanged",this.languageChanged);
        this.betbarStg.update();

    };
    private updateBetlimitPanel=():void=>
    {
        this.betBarMC.dealerVal.text="Admin";
        this.betBarMC.betlimitVal.text=this.parentObj.minBetLimit+" - "+this.parentObj.maxBetLimit;

    };
    public updateBalance=(balance):void=>
    {

        this.betBarMC.balanceVal.text=balance;
        this.parentObj.balance=balance;
    };
    private chipTrayHandler=(betlimitArr):void=>
    {
        this.chipTray=new ChipTray();
        this.chipTray.commonDesign=this.commonDesign;
        this.chipTray.addEventListener("chipSelected",this.selectedChipHandler);
        this.chipTray.betbarStg=this.betbarStg;
        this.chipTray.createChip(betlimitArr);
        this.chipTray.y=10;
        this.chipTray.x=440;
        this.betBarMC.addChild(this.chipTray);
    };
    private addBBarButton=():void=>
    {
        this.betbarButton=new BetBarButton();
        this.betbarButton.commonDesign=this.commonDesign;
        this.betbarButton.betbarStg=this.betbarStg;
        this.betBarMC.addChild(this.betbarButton);
        this.betbarButton.init(this);
    };
    private selectedChipHandler=(event):void=>
    {
        var dataEvent=new Event("chipSelected",false,false);
        dataEvent.data= event.data;
        this.dispatchEvent(dataEvent);
    };
    public showBetbar=():void=>
    {
       // this.showBGHandler();
       // this.showBBarButton();
       // this.betbarStg.update(); 
    };
    public addBGHandler=():void=>
    {
        this.betBarMC=new this.gameDesign.betbarMC();
        this.betbarStg.addChild(this.betBarMC);
        //this.betbarStg.update(); 
    };
    public betBarUpdation=(event):void=>
    {
       this.betBarMC.betAmountVal.text=event.data;
       this.betbarStg.update();
    };
    public languageChanged=(event):void=>
    {
        console.log("changed in betbar");
        this.betBarMC.dealerTxt.text=GameConstants.DATALANGUAGE.dealer;
        this.betBarMC.betLimitTxt.text=GameConstants.DATALANGUAGE.betlimit;
        this.betBarMC.betAmountTxt.text=GameConstants.DATALANGUAGE.betamount;
        this.betBarMC.balanceTxt.text=GameConstants.DATALANGUAGE.balance;
        this.betbarStg.update();
    }
}//end betbar class
export = Betbar;