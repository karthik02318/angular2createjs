
/// <reference path="../../../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
import ChipPlacement=require("../../../component/ChipPlacement");
import GameConstants=require("../../../models/GameConstants");
import Betbar=require("../../../views/ui/BaccaratView/com/Betbar");
import Event = createjs.Event;
import IView=require("../IView");
import View=require("../View");
import BaccaratTrend=require("./com/trend/BaccaratTrend");

class BaccaratView extends View implements IView
{

    public seatNum=4;
    public totalBet=0;
    public boardStage;
    public chipPlacement;
    public minBetLimit=5;
    public maxBetLimit=500;
    public balance=450;
    public boardContent;

    private betbar= new Betbar();
    private letMainBet=0;
    private curSeatArr=new Array("banker_","player_","tie_mc","mc_minus_2","mc_minus_3","mc_plus_2","mc_plus_3");
    private betspotArr=new Array("mc_minus_2","mc_plus_2","tie_mc","mc_minus_3","mc_plus_3","banker_7","banker_6","banker_5","banker_4","banker_3","banker_2","banker_1","player_7","player_6","player_5","player_4","player_3","player_2","player_1");
    private baccaratRuleArr=["tie_mc","mc_minus_2","mc_minus_3","mc_plus_2","mc_plus_3"];
    private betLimit=[1,5,25,100,500];
    private selectedChip=1;

    constructor() {
        super();
     this.boardStage= new createjs.Stage("stageCanvas");
     this.chipPlacement=new ChipPlacement();
     this.chipPlacement.chipScale=40;
     this.boardStage.update();
      }
    public showGame=():void=>
    {
    this.chipPlacement.commonDesign=GameConstants.COMMONASSETS;
    this.chipPlacement.betlimit=this.betLimit;
    this.boardContent=new GameConstants.GAMEASSETS.bgMC;
    this.boardStage.enableMouseOver(10);
    this.boardContent["textMC"].mouseEnabled=false;

    for(var k=0;k<this.betspotArr.length;k++) {
       var spotName=this.betspotArr[k];
       this.boardContent[spotName].gotoAndStop("rout");
       this.boardContent[spotName].name=spotName;
       var helper = new createjs.ButtonHelper(this.boardContent[spotName]);
       this.boardContent[spotName].cursor = "default";
       this.boardContent[spotName].removeEventListener("click", this.betSpotClickHandler);
       this.boardContent[spotName].removeEventListener("mouseover", this.betSpotOverHandler);
       this.boardContent[spotName].removeEventListener("mouseout", this.betSpotOutHandler);
       this.boardContent[spotName].gotoAndStop("rout");

    }

    this.enableBoard();
    this.boardStage.addChild(this.boardContent);
    this.showBetbar();
        var baccaratTrend=new BaccaratTrend();
        baccaratTrend.createBigPathTrend(this.boardStage);
        this.boardStage.addChild(baccaratTrend);
    this.boardStage.update();

    };
    private enableBoard=():void=>
    {
        for(var k=0;k<this.curSeatArr.length;k++) {
            var spName=this.curSeatArr[k];

            if(spName=="banker_" || spName=="player_")
            {
                spName=spName+this.seatNum;
            }

            this.boardContent[spName].mouseEnabled = true;
            this.boardContent[spName].cursor = "pointer";
            this.boardContent[spName].addEventListener("click", this.betSpotClickHandler);
            this.boardContent[spName].addEventListener("mouseover", this.betSpotOverHandler);
            this.boardContent[spName].addEventListener("mouseout", this.betSpotOutHandler);
        }
    };

    private showBetbar=():void=>
    {
        this.betbar.commonDesign=GameConstants.COMMONASSETS;
        this.betbar.init(GameConstants.GAMEASSETS,this.betLimit,this);
        this.betbar.addEventListener("chipSelected",this.selectedChipHandler);
        this.boardStage.update();
    };

    private  selectedChipHandler=(event):void=>
    {
        this.selectedChip=event.data;

    };
    private betSpotClickHandler=(evt):void=>
    {
        var curChip=this.betspotUpdation(evt.currentTarget);
        var getSpotDetails=[];
        if(curChip.name=="banker_"+this.seatNum)
        {
            getSpotDetails[0]=this.chipPlacement.getBetSpotAmt("player_"+this.seatNum);
            getSpotDetails[1]="player_";

        }else  if(curChip.name=="player_"+this.seatNum)
        {
            getSpotDetails[0]=this.chipPlacement.getBetSpotAmt("banker_"+this.seatNum);
            getSpotDetails[1]="banker_";

        }else
        {
            var getNum=this.betLogicHandler(curChip.name)
            getSpotDetails[0]=getNum;
            getSpotDetails[1]=undefined;
            if(this.chipPlacement.getBetSpotAmt("banker_"+this.seatNum)>0){
                this.letMainBet= this.chipPlacement.getBetSpotAmt("banker_"+this.seatNum);
            }if(this.chipPlacement.getBetSpotAmt("player_"+this.seatNum)>0){

            this.letMainBet= this.chipPlacement.getBetSpotAmt("player_"+this.seatNum);
            }
            var sidebet=this.chipPlacement.getBetSpotAmt(curChip.name)+this.selectedChip;
            if(sidebet>this.letMainBet && curChip.name!="tie_mc_"+this.seatNum)
            {
                alert("Side bets cannot exceed Banker/Player/Tie bets");
                getSpotDetails[0]=sidebet;
                getSpotDetails[1]="null"
            }

        }

        if(getSpotDetails[0]==0)
        {
            var totalAmt=this.totalBet+this.selectedChip;

            if(totalAmt<= this.maxBetLimit) {

                if(this.selectedChip<=this.balance)
                {
                this.chipPlacement.placebet(curChip, curChip.name, this.selectedChip, this.boardStage);
                this.totalBet+=this.selectedChip;
                this.betAmountUpdate(this.totalBet);
                this.balance -= this.selectedChip;
                this.betbar.updateBalance(this.balance);
                } else {
                    alert("Not enought money");
                }
            }else
            {
                alert("All bets must be at or below the maximum of " + this.maxBetLimit);
            }
        }else {

            if(getSpotDetails[1]=="player_" || getSpotDetails[1]=="banker_") {
                alert("That bet conflicts with your bets placed on the table");
            }else if(getSpotDetails[1]==undefined)
            {
                alert("Only one side bet allowed per hand.");
            }
        }

        //TweenMax.to(this.chipmcc, 1, {x:700,ease:Elastic.easeOut});
        //createjs.Ticker.addEventListener("tick", this.boardStage);

        this.boardStage.update();
    };
    private betAmountUpdate=(totalbet):void=>
    {
        var dataEvent=new Event("updateChipAmt",false,false);
        dataEvent.data= totalbet;
        this.betbar.dispatchEvent(dataEvent);
    };
    private betLogicHandler=(betSptName):number=>
    {
        var getSpotAmt=0;
        for(var jj=0;jj<this.baccaratRuleArr.length;jj++)
        {
            var chBetSpot=this.baccaratRuleArr[jj]+"_"+this.seatNum;
            if(chBetSpot!=betSptName)
            {
                getSpotAmt=this.chipPlacement.getBetSpotAmt(chBetSpot);
                if(getSpotAmt!=0)
                {
                    return getSpotAmt;
                }
            }
        }
        return getSpotAmt;
    };
    private betSpotOverHandler=(evt):void=>
    {
      evt.currentTarget.gotoAndStop("rover");
      this.boardStage.update();
    };
    private betSpotOutHandler=(evt):void=>
    {
      evt.currentTarget.gotoAndStop("rout");
      this.boardStage.update();
    };
    private betspotUpdation=(Object):any=>
    {
        if(Object.name=="tie_mc" || Object.name=="mc_minus_2" || Object.name=="mc_minus_3" || Object.name=="mc_plus_2"|| Object.name=="mc_plus_3")  {
            this.chipPlacement.chipScale=25;
            var cname=Object.name+"_"+this.seatNum;
            Object=this.boardContent[cname];
            Object.name=cname;

        }else
        {
            this.chipPlacement.chipScale=40;
        }
        return Object;
    };
    public languageChanged=():void=>
    {
        console.log("dispatching");
        var event=new Event("languagechanged",false,false);
        this.dispatchEvent(event);
    };
    //--------------------------------------------------------------------------end-----------------------------------------------------
    }
    export=BaccaratView;