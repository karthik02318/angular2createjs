/**
 * Created by sahila.r on 10/24/2016.
 */

class View extends createjs.Container
{
    private gameView;
    constructor() {
        super();
    }
    public init=(game):void=>{
        this.gameView=new game;
        this.gameView.showGame();
        this.gameView.languageChanged();
    };

}//end
export = View;