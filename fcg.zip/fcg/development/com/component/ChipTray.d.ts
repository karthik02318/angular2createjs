/// <reference path="../../def/greensock/greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts" />
declare class ChipTray extends createjs.MovieClip {
    private chipTray;
    private betlimitArr;
    commonDesign: any;
    private chipYpos;
    private selectedChip;
    betbarStg: any;
    private scrolpos;
    private staticVal;
    private scrollXpos;
    private dictionary;
    private map;
    constructor();
    createChip: (betlimitArr: number[]) => void;
    private scrollHandler;
    private selectChipHandler;
    private scrollRightHandler;
    private scrollLeftHandler;
}
export = ChipTray;
