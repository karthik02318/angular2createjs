"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="..\..\def\greensock\greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
var Dictionary = require("./Dictionary");
var Event = createjs.Event;
var ChipTray = (function (_super) {
    __extends(ChipTray, _super);
    function ChipTray() {
        var _this = this;
        _super.call(this);
        this.chipYpos = 10;
        this.staticVal = 0;
        this.scrollXpos = 0;
        this.dictionary = new Dictionary();
        this.map = { 1: "blue", 5: "red", 25: "green", 100: "black", 500: "white" };
        this.createChip = function (betlimitArr) {
            _this.chipTray = new _this.commonDesign.chipTray();
            _this.betlimitArr = betlimitArr;
            var maskm = new createjs.Shape();
            var cMask = _this.chipTray.dockMask;
            maskm.graphics.drawRect(cMask.x, cMask.y, cMask.nominalBounds.width, cMask.nominalBounds.height);
            _this.chipTray.addChild(maskm);
            _this.chipTray.dock_mc.mask = maskm;
            _this.chipTray.dockMask.visible = false;
            for (var i = 0; i < betlimitArr.length; i++) {
                var chipmc = new _this.commonDesign.BetBarChip;
                chipmc.gotoAndStop("zero");
                var helper = new createjs.ButtonHelper(chipmc);
                var getColor = _this.map[betlimitArr[i]];
                chipmc.colorChip.gotoAndStop(getColor);
                _this.selectedChip = chipmc;
                var scale = 55 / chipmc.nominalBounds.width; //0.3
                chipmc.scaleX = chipmc.scaleY = scale;
                chipmc.x = (chipmc.x + 75) * i;
                chipmc.y = _this.chipYpos;
                chipmc.val = betlimitArr[i];
                _this.dictionary.applyValue(chipmc, betlimitArr[i]);
                _this.chipTray.dock_mc.addChild(chipmc);
                chipmc.addEventListener("click", _this.selectChipHandler);
            }
            _this.addChild(_this.chipTray);
            _this.scrollHandler();
        };
        this.scrollHandler = function () {
            var wd = _this.betlimitArr.length * 75;
            var contentXpos = wd + _this.chipTray.dock_mc.x;
            _this.scrolpos = _this.chipTray.dockMask.x + _this.chipTray.dockMask.nominalBounds.width;
            _this.scrollXpos = contentXpos - _this.scrolpos;
            _this.staticVal = _this.scrollXpos;
            _this.chipTray.rightBtn.addEventListener("click", _this.scrollRightHandler);
            _this.chipTray.rightBtn.visible = false;
            _this.chipTray.leftBtn.visible = false;
            if (_this.scrollXpos > _this.staticVal) {
                _this.chipTray.rightBtn.visible = true;
                _this.chipTray.leftBtn.visible = true;
            }
            _this.betbarStg.update();
        };
        this.selectChipHandler = function (evt) {
            TweenMax.to(_this.selectedChip, 0.25, { y: _this.chipYpos });
            TweenMax.to(evt.currentTarget, 0.25, { y: _this.chipYpos - 10 });
            createjs.Ticker.addEventListener("tick", _this.betbarStg);
            _this.selectedChip = evt.currentTarget;
            var getValue = evt.currentTarget.val;
            var dataEvent = new Event("chipSelected", false, false);
            dataEvent.data = getValue;
            _this.dispatchEvent(dataEvent);
            _this.betbarStg.update();
        };
        this.scrollRightHandler = function (event) {
            _this.chipTray.dock_mc.x = _this.chipTray.dock_mc.x - 5;
            _this.scrollXpos = _this.scrollXpos - 5;
            if (_this.scrollXpos < 1) {
                _this.chipTray.rightBtn.removeEventListener("click", _this.scrollRightHandler);
                _this.chipTray.rightBtn.buttonMode = false;
            }
            _this.chipTray.leftBtn.addEventListener("click", _this.scrollLeftHandler);
            _this.chipTray.leftBtn.buttonMode = true;
            _this.betbarStg.update();
        };
        this.scrollLeftHandler = function (event) {
            _this.chipTray.dock_mc.x = _this.chipTray.dock_mc.x + 5;
            _this.scrollXpos = _this.scrollXpos + 5;
            if (_this.scrollXpos >= _this.staticVal) {
                _this.chipTray.leftBtn.removeEventListener("click", _this.scrollLeftHandler);
                _this.chipTray.leftBtn.buttonMode = false;
                _this.chipTray.rightBtn.addEventListener("click", _this.scrollRightHandler);
                _this.chipTray.rightBtn.buttonMode = true;
            }
            _this.betbarStg.update();
        };
    }
    return ChipTray;
}(createjs.MovieClip)); //end chiptray
module.exports = ChipTray;
//# sourceMappingURL=ChipTray.js.map