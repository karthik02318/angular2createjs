/**
 * Created by sahila.r on 10/17/2016.
 */
/// <reference path="..\..\def\greensock\greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Dictionary = (function (_super) {
    __extends(Dictionary, _super);
    function Dictionary() {
        _super.call(this);
        this.applyValue = function (chip, value) {
            var str = value.toString();
            if (value >= 1000) {
                value = value / 1000;
                str = value.toString() + "K";
            }
            var len = str.length - 1;
            var res = str.split("");
            chip.chipVal.gotoAndStop(len.toString());
            for (var st = 0; st < str.length; st++) {
                var gt = res[st];
                chip.chipVal["counter" + st].gotoAndStop(gt);
            }
        };
    }
    return Dictionary;
}(createjs.MovieClip));
module.exports = Dictionary;
//# sourceMappingURL=Dictionary.js.map