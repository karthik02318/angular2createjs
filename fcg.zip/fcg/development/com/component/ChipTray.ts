/// <reference path="..\..\def\greensock\greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
import Dictionary=require("./Dictionary");
import Event = createjs.Event;
class ChipTray extends createjs.MovieClip 
{
private chipTray;
private betlimitArr;
public commonDesign;
private chipYpos=10;
private selectedChip;
public betbarStg;
private scrolpos;
private staticVal:number=0;
private scrollXpos:number=0;
private dictionary=new Dictionary();
private map:Object = {1:"blue",5:"red",25:"green",100:"black",500:"white"};

constructor() {
        super();
  }

 public createChip = (betlimitArr:Array<number>): void => {
   
    this.chipTray=new this.commonDesign.chipTray();
    this.betlimitArr=betlimitArr;
    var maskm = new createjs.Shape();
    var cMask=this.chipTray.dockMask;
    maskm.graphics.drawRect(cMask.x,cMask.y,cMask.nominalBounds.width,cMask.nominalBounds.height);
    this.chipTray.addChild(maskm);
    this.chipTray.dock_mc.mask=maskm;
    this.chipTray.dockMask.visible=false;

    for(var i:number=0;i<betlimitArr.length;i++) {
           var chipmc=new this.commonDesign.BetBarChip;
           chipmc.gotoAndStop("zero");
           var helper = new createjs.ButtonHelper(chipmc);
           var getColor=this.map[betlimitArr[i]];
           chipmc.colorChip.gotoAndStop(getColor);
           this.selectedChip=chipmc;
           var scale = 55 / chipmc.nominalBounds.width;//0.3
           chipmc.scaleX = chipmc.scaleY = scale;
           chipmc.x=(chipmc.x+75)*i;
           chipmc.y=this.chipYpos;
           chipmc.val=betlimitArr[i];
           this.dictionary.applyValue(chipmc,betlimitArr[i]);
           this.chipTray.dock_mc.addChild(chipmc);
           chipmc.addEventListener("click",this.selectChipHandler);
        }
     this.addChild(this.chipTray);
     this.scrollHandler();
};
private scrollHandler=():void=>
{
     var wd = this.betlimitArr.length*75;
     var contentXpos=wd+this.chipTray.dock_mc.x;
     this.scrolpos=this.chipTray.dockMask.x+this.chipTray.dockMask.nominalBounds.width;
     this.scrollXpos=contentXpos-this.scrolpos;
     this.staticVal=this.scrollXpos;
     this.chipTray.rightBtn.addEventListener("click",this.scrollRightHandler);
     this.chipTray.rightBtn.visible=false;
     this.chipTray.leftBtn.visible=false;
     if(this.scrollXpos>this.staticVal)
     {
        this.chipTray.rightBtn.visible=true;
        this.chipTray.leftBtn.visible=true;
     }
     this.betbarStg.update();
};
private selectChipHandler=(evt):void=>
  {
      TweenMax.to(this.selectedChip, 0.25, {y:this.chipYpos});
      TweenMax.to(evt.currentTarget, 0.25, {y:this.chipYpos-10});
      createjs.Ticker.addEventListener("tick", this.betbarStg);
      this.selectedChip=evt.currentTarget;
      var getValue:string=evt.currentTarget.val;
      var dataEvent=new Event("chipSelected",false,false);
      dataEvent.data= getValue;
      this.dispatchEvent(dataEvent);
      this.betbarStg.update();
  };

 private scrollRightHandler=(event):void=>
  {
 
  this.chipTray.dock_mc.x=this.chipTray.dock_mc.x-5;
  this.scrollXpos=this.scrollXpos-5;
 
  if(this.scrollXpos<1)
		{
       this.chipTray.rightBtn.removeEventListener("click",this.scrollRightHandler);
       this.chipTray.rightBtn.buttonMode=false;
		}
    this.chipTray.leftBtn.addEventListener("click",this.scrollLeftHandler);
    this.chipTray.leftBtn.buttonMode=true;
	this.betbarStg.update();	
  };
  
  private scrollLeftHandler=(event):void=>
  {
  
  this.chipTray.dock_mc.x=this.chipTray.dock_mc.x+5;
  this.scrollXpos=this.scrollXpos+5;
  
  if(this.scrollXpos>=this.staticVal)
		{
       this.chipTray.leftBtn.removeEventListener("click",this.scrollLeftHandler);
       this.chipTray.leftBtn.buttonMode=false;
       this.chipTray.rightBtn.addEventListener("click",this.scrollRightHandler);
       this.chipTray.rightBtn.buttonMode=true;
		}
 
	this.betbarStg.update();	
  }
}//end chiptray
export = ChipTray;