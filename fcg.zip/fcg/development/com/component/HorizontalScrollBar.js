/// <reference path="..\..\def\greensock\greensock.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var HorizontalScrollBar = (function (_super) {
    __extends(HorizontalScrollBar, _super);
    function HorizontalScrollBar() {
        var _this = this;
        _super.call(this);
        this._scrollSpeed = .5;
        this._scrollWheelSpeed = 10;
        this.init = function ($content, $contentMask, $track, $slider, $scrollSpeed, stage, xval, yval) {
            if ($scrollSpeed === void 0) { $scrollSpeed = .5; }
            _this._content = $content;
            _this._contentMask = $contentMask;
            _this._slider = $slider;
            _this._track = $track;
            _this._scrollSpeed = $scrollSpeed;
            _this._content.mask = _this._contentMask;
            _this._root = stage;
            _this._slider.visible = false;
            _this._track.visible = false;
            _this._content.x = xval;
            _this._contentMask.x = xval;
            _this._slider.x = xval;
            _this._track.x = xval;
            _this._contentMask.y = yval;
            _this._content.y = yval;
            _this._slider.y = _this._contentMask.getBounds().height + yval;
            _this._track.y = _this._contentMask.getBounds().height + yval;
            _this._root.addChild(_this._content);
            _this._root.addChild(_this._contentMask);
            _this._root.addChild(_this._track);
            _this._root.addChild(_this._slider);
            _this.enable();
        };
        this.updateContent = function (content) {
            _this._content = content;
            alert("this-->" + _this._content.getBounds().width);
        };
        this.enable = function () {
            _this._root.mouseEnabled = true;
            _this._root.cursor = "pointer";
            _this._root.addEventListener("pressmove", _this.onMouseMoveHandler);
            _this._slider.addEventListener("mousedown", _this.onMouseDownHandler);
            // this._root.addEventListener("mousewheel", onMouseWheelHandler);
            _this._root.addEventListener("pressup", _this.onMouseUpHandler);
            _this.verifyHeight();
        };
        this.disable = function () {
            _this._track.mouseEnabled = true;
            _this._track.cursor = "default";
            _this._track.removeEventListener("pressmove", _this.onMouseMoveHandler);
            _this._slider.removeEventListener("mousedown", _this.onMouseDownHandler);
            // this._slider.removeEventListener("mousedown", this.onMouseMoveHandler);
            //this._root.removeEventListener(MouseEvent.MOUSE_WHEEL, this.onMouseWheelHandler);
            // this._slider.removeEventListener("mouseup", this.onMouseUpHandler);
            _this._root.removeEventListener("pressup", _this.onMouseUpHandler);
        };
        this.onMouseDownHandler = function (evt) {
            _this.offset = { x: _this._slider.x - evt.stageX, y: _this._slider.y - evt.stageY };
        };
        this.onMouseMoveHandler = function (evt) {
            console.log("offset--->" + _this.offset);
            var end = _this._track.nominalBounds.width - _this._slider.nominalBounds.width + _this._track.x;
            var start = evt.stageX + _this.offset.x;
            if (start < end && _this._track.x < start) {
                _this._slider.x = evt.stageX + _this.offset.x;
            }
            _this._root.update();
            createjs.Ticker.addEventListener("tick", _this.updateContentPosition);
        };
        this.onMouseUpHandler = function (evt) {
            createjs.Ticker.removeEventListener("tick", _this.updateContentPosition);
            if (_this._root != null) {
                createjs.Ticker.removeEventListener("tick", _this.updateContentPosition);
            }
        };
        this.updateContentPosition = function (evt) {
            var _scrollPercent = 100 / (_this._track.nominalBounds.width - _this._slider.nominalBounds.width) * (_this._slider.x - _this._track.x);
            var newContentX = _this._contentMask.x + (_this._contentMask.getBounds().width - _this._content.getBounds().width) / 100 * _scrollPercent;
            TweenMax.to(_this._content, _this._scrollSpeed, { x: newContentX, ease: Expo.easeOut });
            createjs.Ticker.addEventListener("tick", _this._root);
            _this._root.update();
        };
        this.updateSliderPosition = function () {
            var contentPercent = Math.abs((_this._content.x - _this._contentMask.x) / (_this._content.width - _this._contentMask.width) * 100);
            var newDraggerX = (contentPercent / 100 * (_this._track.width - _this._slider.width)) + _this._track.y;
            _this._slider.x = newDraggerX;
        };
        this.verifyHeight = function () {
            if (_this._contentMask.width >= _this._content.width) {
                _this._slider.visible = false;
                _this._track.visible = false;
            }
            else {
                _this._slider.visible = true;
                _this._track.visible = true;
            }
        };
        this.destroy = function () {
            if (createjs.Ticker.addEventListener("tick", _this.updateContentPosition)) {
                createjs.Ticker.removeEventListener("tick", _this.updateContentPosition);
            }
            _this.disable();
        };
    }
    return HorizontalScrollBar;
}(createjs.Container)); //----------end--------
module.exports = HorizontalScrollBar;
//# sourceMappingURL=HorizontalScrollBar.js.map