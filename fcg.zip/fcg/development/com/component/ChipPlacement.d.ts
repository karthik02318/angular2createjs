/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts" />
declare class ChipPlacement extends createjs.Container {
    commonDesign: any;
    gap: number;
    chipScale: any;
    private betlimit;
    betSptArr: any[];
    private betPlmtContainer;
    private mapColor;
    private dictionary;
    betPlacedArr: any[];
    constructor();
    placebet: (betspot: any, betsptName: any, amount: any, stage: any) => void;
    private createBet;
    private getBetChipOrder;
    private creatingContainer;
    private updateChip;
    getBetSpotAmt: (betsptname: any) => number;
    clearBetSpot: (betsptname: any) => void;
    clearAllBetSpot: (event: any) => void;
    private removeChipStack;
}
export = ChipPlacement;
