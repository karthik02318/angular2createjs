/// <reference path="../../def/greensock/greensock.d.ts" />
declare class HorizontalScrollBar extends createjs.Container {
    private _content;
    private _contentMask;
    private _slider;
    private _track;
    private _scrollSpeed;
    private _scrollWheelSpeed;
    private _root;
    private offset;
    constructor();
    init: ($content: any, $contentMask: any, $track: any, $slider: any, $scrollSpeed: number, stage: any, xval: any, yval: any) => void;
    updateContent: (content: any) => void;
    enable: () => void;
    disable: () => void;
    private onMouseDownHandler;
    private onMouseMoveHandler;
    private onMouseUpHandler;
    private updateContentPosition;
    updateSliderPosition: () => void;
    verifyHeight: () => void;
    destroy: () => void;
}
export = HorizontalScrollBar;
