/// <reference path="../../def/greensock/greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts" />
/**
 * Created by sahila.r on 10/17/2016.
 */
declare class Dictionary extends createjs.MovieClip {
    constructor();
    applyValue: (chip: any, value: number) => void;
}
export = Dictionary;
