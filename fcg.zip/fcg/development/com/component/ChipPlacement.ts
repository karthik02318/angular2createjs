/**
 * Created by sahila.r on 10/17/2016.
 */
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>

import Dictionary=require("./Dictionary");

class ChipPlacement extends createjs.Container {
    public commonDesign;
    public gap=8;
    public chipScale;
    private betlimit = [];
    public betSptArr = [];
    private betPlmtContainer = new createjs.Container();
    private mapColor = {1: "blue", 5: "red", 25: "green", 100: "black", 500: "white"};
    private dictionary = new Dictionary();
    public betPlacedArr=[];

    constructor() {

        super();
        this.betPlmtContainer.x = 0;
        this.betPlmtContainer.y = 0;
        this.addEventListener("clearallbetspt", this.clearAllBetSpot);
    }
    public placebet = (betspot, betsptName, amount, stage): void=> {

        if (this.betSptArr[betsptName] != undefined) {
            this.betSptArr[betsptName].chipAmt += amount;

        } else {
            this.creatingContainer(betsptName, amount, amount, betspot);
        }
        this.createBet(betsptName, amount, betspot);
        stage.addChild(this.betPlmtContainer);
        stage.update();
    };

    private createBet = (betsptName, amount, betspot): void=> {

        var getarray = this.getBetChipOrder(this.betSptArr[betsptName].chipAmt);
        this.removeChipStack(betsptName, 0, this.betSptArr[betsptName].length);
        this.creatingContainer(betsptName, amount, this.betSptArr[betsptName].chipAmt, betspot);
        for (var chip = 0; chip < getarray.length; chip++) {
            this.updateChip(betsptName, getarray[chip]);
        }
    };

    private getBetChipOrder = (mValue): any=> {
        var mTempArray = [];
        var count = 0;
        for (var i = this.betlimit.length - 1; i >= 0; i--) {
            var mChipValue = Math.floor(mValue / this.betlimit[i]);
            if (mChipValue >= 1) {
                mValue %= this.betlimit[i];
                for (var j = 0; j < mChipValue; j++) {
                    mTempArray[count++] = this.betlimit[i];
                }
            }
        }

        return mTempArray;
    };

    private creatingContainer = (betsptName, amount, totalAmt, betspot): void=> {

        if(this.betPlacedArr.indexOf(betsptName)==-1)
        {
            this.betPlacedArr.push(betsptName);

        }
        this.betSptArr[betsptName] = [];
        this.betSptArr[betsptName].chipAmt = totalAmt;
        this.betSptArr[betsptName].amount = amount;
        this.betSptArr[betsptName].container = new createjs.Container();
        this.betSptArr[betsptName].container.x = betspot.x;
        this.betSptArr[betsptName].container.y = betspot.y;
        this.betPlmtContainer.addChild(this.betSptArr[betsptName].container);
    };
    private updateChip = (betsptName, amount): void=>
    {
        var chipmc = new this.commonDesign.BetspotChip;
        chipmc.gotoAndStop("zero");
        chipmc.gotoAndStop(0);
        chipmc.chipVal.gotoAndStop(0);
        chipmc.chipVal.counter0.gotoAndStop(0);
        var scale = this.chipScale / chipmc.nominalBounds.width;//0.3
        chipmc.scaleX = chipmc.scaleY = scale;
        this.betSptArr[betsptName].totalAmt = amount;
        var getColor = this.mapColor[amount];
        this.dictionary.applyValue(chipmc, amount);
        chipmc.colorChip.gotoAndStop(getColor);
        chipmc.x = 0;
        var percent=this.chipScale/this.gap;
        var len=this.betSptArr[betsptName].length;
        chipmc.y = (chipmc.y - percent) * len;
        this.betSptArr[betsptName].push(chipmc);
        this.betSptArr[betsptName][len].amount=amount;
        this.betSptArr[betsptName].container.addChild(chipmc);

    };
    public getBetSpotAmt = (betsptname): number=> {

        var chipAMT=0;
        if(this.betSptArr[betsptname]!=undefined)
        {
            chipAMT=this.betSptArr[betsptname].chipAmt;
        }
        return chipAMT;
    };
    public clearBetSpot=(betsptname):void=>
    {

        var len=this.betSptArr[betsptname].length;
        this.removeChipStack(betsptname,0,len);
        this.betSptArr[betsptname]=[];

    };
    public clearAllBetSpot=(event):void=>
    {
        for(var k=0;k<this.betPlacedArr.length;k++)
        {
            var betSptName=this.betPlacedArr[k];

            while(this.betSptArr[betSptName].container.numChildren > 0){
                this.betSptArr[betSptName].container.removeChildAt(0);
            }
            this.betSptArr[betSptName]=[];
            this.betSptArr[betSptName]=undefined;

        }
        this.betPlacedArr=[];
    };
    private removeChipStack = (betsptname, st, end): void=> {

           for (var rm = st; rm < end; rm++) {

            this.betSptArr[betsptname].container.removeChild(this.betSptArr[betsptname][rm]);
        }
    };
}//end
export = ChipPlacement;

