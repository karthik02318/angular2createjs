/**
 * Created by sahila.r on 10/17/2016.
 */
/// <reference path="..\..\def\greensock\greensock.d.ts" />
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>

class Dictionary extends createjs.MovieClip {

    constructor() {
        super();
    }
    public applyValue = (chip: any, value: number): void=> {

        var str = value.toString();
        if (value >= 1000) {
            value = value / 1000;
            str = value.toString() + "K";
        }
        var len = str.length - 1;
        var res = str.split("");
        chip.chipVal.gotoAndStop(len.toString());

        for (var st = 0; st < str.length; st++) {
            var gt = res[st];
            chip.chipVal["counter" + st].gotoAndStop(gt);
        }

    };
}
export = Dictionary;