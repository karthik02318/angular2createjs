/// <reference path="..\..\def\greensock\greensock.d.ts" />


class HorizontalScrollBar extends createjs.Container
{
    private _content;
    private _contentMask;
    private _slider;
    private _track;
    private _scrollSpeed:number = .5;
    private _scrollWheelSpeed:number = 10;
    private _root;
    private offset;
    constructor() {
        super();
    }
    public init=($content, $contentMask, $track, $slider, $scrollSpeed:number = .5,stage,xval,yval):void=>
    {
        this._content = $content;
        this._contentMask = $contentMask;
        this._slider = $slider;
        this._track = $track;
        this._scrollSpeed = $scrollSpeed;

        this._content.mask = this._contentMask;
        this._root = stage;
        this._slider.visible = false;
        this._track.visible = false;

        this._content.x=xval;
        this._contentMask.x=xval;
        this._slider.x=xval;
        this._track.x=xval;
        this._contentMask.y=yval;
        this._content.y=yval;

        this._slider.y=this._contentMask.getBounds().height+yval;
        this._track.y=this._contentMask.getBounds().height+yval;
        this._root.addChild( this._content);
        this._root.addChild( this._contentMask);
        this._root.addChild( this._track);
        this._root.addChild( this._slider);
        this.enable();
    };
    public updateContent=(content):void=>
    {
        this._content = content;
        alert("this-->"+this._content.getBounds().width)
    }
    public enable=():void=>
    {
        this._root.mouseEnabled = true;
        this._root.cursor = "pointer";
        this._root.addEventListener("pressmove", this.onMouseMoveHandler);
        this._slider.addEventListener("mousedown", this.onMouseDownHandler);
        // this._root.addEventListener("mousewheel", onMouseWheelHandler);
        this._root.addEventListener("pressup", this.onMouseUpHandler);
        this.verifyHeight();

    };
    public disable=():void=>
    {
        this._track.mouseEnabled = true;
        this._track.cursor = "default";
        this._track.removeEventListener("pressmove", this.onMouseMoveHandler);
        this._slider.removeEventListener("mousedown", this.onMouseDownHandler);
       // this._slider.removeEventListener("mousedown", this.onMouseMoveHandler);
       //this._root.removeEventListener(MouseEvent.MOUSE_WHEEL, this.onMouseWheelHandler);
       // this._slider.removeEventListener("mouseup", this.onMouseUpHandler);
        this._root.removeEventListener("pressup", this.onMouseUpHandler);
    };

    private onMouseDownHandler=(evt):void=> {

        this.offset = {x: this._slider.x - evt.stageX, y: this._slider.y - evt.stageY};

    };
    private onMouseMoveHandler=(evt):void=>
    {
        console.log("offset--->"+this.offset);
        var end=this._track.nominalBounds.width - this._slider.nominalBounds.width + this._track.x;
        var start=evt.stageX + this.offset.x;
        if(start<end && this._track.x<start) {
            this._slider.x = evt.stageX + this.offset.x;
        }
        this._root.update();
        createjs.Ticker.addEventListener("tick", this.updateContentPosition);

    };
    private onMouseUpHandler=(evt):void=>
    {
        createjs.Ticker.removeEventListener("tick", this.updateContentPosition);
        if (this._root != null)
        {
            createjs.Ticker.removeEventListener("tick", this.updateContentPosition);
        }
    };
    private updateContentPosition=(evt):void=>
    {

        var _scrollPercent:number =  100 / (this._track.nominalBounds.width - this._slider.nominalBounds.width)  * ( this._slider.x - this._track.x);
        var newContentX:number = this._contentMask.x + (this._contentMask.getBounds().width -this._content.getBounds().width) / 100 * _scrollPercent;
        TweenMax.to(this._content,this._scrollSpeed, {x:newContentX,ease: Expo.easeOut});
        createjs.Ticker.addEventListener("tick", this._root);
        this._root.update();
    };
    public updateSliderPosition=():void=>
    {
        var contentPercent:number = Math.abs((this._content.x - this._contentMask.x) / (this._content.width - this._contentMask.width) * 100);
        var newDraggerX:number = (contentPercent / 100 * (this._track.width - this._slider.width)) + this._track.y;
        this._slider.x = newDraggerX;
    };
    public verifyHeight=():void=>
    {
        if ( this._contentMask.width >= this._content.width )
        {
            this._slider.visible = false;
            this._track.visible = false;
        }
        else
        {
            this._slider.visible = true;
            this._track.visible = true;
        }
    };
    public destroy=():void=>
    {
        if (createjs.Ticker.addEventListener("tick", this.updateContentPosition))
        {
           createjs.Ticker.removeEventListener("tick", this.updateContentPosition);
        }
        this.disable();
    }
}//----------end--------
export =HorizontalScrollBar