/**
 * Created by sahila.r on 10/17/2016.
 */
/// <reference path="../../assets/gameAssets/baccaratAssets/gameDesignAssets.d.ts"/>
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Dictionary = require("./Dictionary");
var ChipPlacement = (function (_super) {
    __extends(ChipPlacement, _super);
    function ChipPlacement() {
        var _this = this;
        _super.call(this);
        this.gap = 8;
        this.betlimit = [];
        this.betSptArr = [];
        this.betPlmtContainer = new createjs.Container();
        this.mapColor = { 1: "blue", 5: "red", 25: "green", 100: "black", 500: "white" };
        this.dictionary = new Dictionary();
        this.betPlacedArr = [];
        this.placebet = function (betspot, betsptName, amount, stage) {
            if (_this.betSptArr[betsptName] != undefined) {
                _this.betSptArr[betsptName].chipAmt += amount;
            }
            else {
                _this.creatingContainer(betsptName, amount, amount, betspot);
            }
            _this.createBet(betsptName, amount, betspot);
            stage.addChild(_this.betPlmtContainer);
            stage.update();
        };
        this.createBet = function (betsptName, amount, betspot) {
            var getarray = _this.getBetChipOrder(_this.betSptArr[betsptName].chipAmt);
            _this.removeChipStack(betsptName, 0, _this.betSptArr[betsptName].length);
            _this.creatingContainer(betsptName, amount, _this.betSptArr[betsptName].chipAmt, betspot);
            for (var chip = 0; chip < getarray.length; chip++) {
                _this.updateChip(betsptName, getarray[chip]);
            }
        };
        this.getBetChipOrder = function (mValue) {
            var mTempArray = [];
            var count = 0;
            for (var i = _this.betlimit.length - 1; i >= 0; i--) {
                var mChipValue = Math.floor(mValue / _this.betlimit[i]);
                if (mChipValue >= 1) {
                    mValue %= _this.betlimit[i];
                    for (var j = 0; j < mChipValue; j++) {
                        mTempArray[count++] = _this.betlimit[i];
                    }
                }
            }
            return mTempArray;
        };
        this.creatingContainer = function (betsptName, amount, totalAmt, betspot) {
            if (_this.betPlacedArr.indexOf(betsptName) == -1) {
                _this.betPlacedArr.push(betsptName);
            }
            _this.betSptArr[betsptName] = [];
            _this.betSptArr[betsptName].chipAmt = totalAmt;
            _this.betSptArr[betsptName].amount = amount;
            _this.betSptArr[betsptName].container = new createjs.Container();
            _this.betSptArr[betsptName].container.x = betspot.x;
            _this.betSptArr[betsptName].container.y = betspot.y;
            _this.betPlmtContainer.addChild(_this.betSptArr[betsptName].container);
        };
        this.updateChip = function (betsptName, amount) {
            var chipmc = new _this.commonDesign.BetspotChip;
            chipmc.gotoAndStop("zero");
            chipmc.gotoAndStop(0);
            chipmc.chipVal.gotoAndStop(0);
            chipmc.chipVal.counter0.gotoAndStop(0);
            var scale = _this.chipScale / chipmc.nominalBounds.width; //0.3
            chipmc.scaleX = chipmc.scaleY = scale;
            _this.betSptArr[betsptName].totalAmt = amount;
            var getColor = _this.mapColor[amount];
            _this.dictionary.applyValue(chipmc, amount);
            chipmc.colorChip.gotoAndStop(getColor);
            chipmc.x = 0;
            var percent = _this.chipScale / _this.gap;
            var len = _this.betSptArr[betsptName].length;
            chipmc.y = (chipmc.y - percent) * len;
            _this.betSptArr[betsptName].push(chipmc);
            _this.betSptArr[betsptName][len].amount = amount;
            _this.betSptArr[betsptName].container.addChild(chipmc);
        };
        this.getBetSpotAmt = function (betsptname) {
            var chipAMT = 0;
            if (_this.betSptArr[betsptname] != undefined) {
                chipAMT = _this.betSptArr[betsptname].chipAmt;
            }
            return chipAMT;
        };
        this.clearBetSpot = function (betsptname) {
            var len = _this.betSptArr[betsptname].length;
            _this.removeChipStack(betsptname, 0, len);
            _this.betSptArr[betsptname] = [];
        };
        this.clearAllBetSpot = function (event) {
            for (var k = 0; k < _this.betPlacedArr.length; k++) {
                var betSptName = _this.betPlacedArr[k];
                while (_this.betSptArr[betSptName].container.numChildren > 0) {
                    _this.betSptArr[betSptName].container.removeChildAt(0);
                }
                _this.betSptArr[betSptName] = [];
                _this.betSptArr[betSptName] = undefined;
            }
            _this.betPlacedArr = [];
        };
        this.removeChipStack = function (betsptname, st, end) {
            for (var rm = st; rm < end; rm++) {
                _this.betSptArr[betsptname].container.removeChild(_this.betSptArr[betsptname][rm]);
            }
        };
        this.betPlmtContainer.x = 0;
        this.betPlmtContainer.y = 0;
        this.addEventListener("clearallbetspt", this.clearAllBetSpot);
    }
    return ChipPlacement;
}(createjs.Container)); //end
module.exports = ChipPlacement;
//# sourceMappingURL=ChipPlacement.js.map