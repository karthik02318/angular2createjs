
var preloader = new createjs.LoadQueue(true);
var View;
var Baccarat;
var GameConstants;
var language="en";
requirejs.config({
    baseUrl: '',
    paths: ''
});
$(document).ready(function(){
    init();
});
function init(){

    require(["com/views/ui/View","com/views/ui/BaccaratView/BaccaratView","com/models/GameConstants","assets/gameAssets/baccaratAssets/gameAssets","assets/commonAssets/commonAssets"], function(view, baccarat, gameConstants) {
        var manifest = [];
        languageChange(language);
        View=view;
        Baccarat=baccarat;
        GameConstants=gameConstants;
        manifest=gameAssets.properties;
        preloader.on("fileload", handleFileLoad);
        preloader.on("complete", handleComplete);
        preloader.loadManifest(manifest);
        preloader.loadManifest(commonAssets.properties);
    });
}
function handleFileLoad(evt) {

    if (evt.item.type == "image")
    {
        images[evt.item.id] = evt.result;
    }
}
var _view;
function handleComplete(evt) {
    _view=new View();
    GameConstants.COMMONASSETS=commonAssets;
    GameConstants.GAMEASSETS=gameAssets;
    _view.init(Baccarat);
}
function languageChange(language) {

    var path="data/language/language_"+language+".json";
    $.getJSON(path, function(data) {
        GameConstants.DATALANGUAGE=data;
    });
}



