(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1280,
	height: 720,
	fps: 24,
	color: "#000000",
	webfonts: {},
	manifest: []
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.Symbol6copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#544013","#E5BD39","#BD7B0C","#6E460D","#371E00"],[0.141,0.314,0.518,0.729,1],1.1,-42.8,1.1,35.2).beginStroke().moveTo(-70.5,35.3).curveTo(-81.9,35.3,-82,24.5).lineTo(-82,-24.5).curveTo(-81.9,-35.3,-70.5,-35.3).lineTo(70.5,-35.3).curveTo(82,-35.3,81.9,-24.5).lineTo(81.9,24.5).curveTo(82,35.3,70.5,35.3).closePath();
	this.shape.setTransform(4.8,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.2,-35.4,163.9,70.6);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#FFC300","#FCE496","#FFC300","#BD7B0C","#6E460D","#371E00"],[0,0.188,0.373,0.592,0.796,1],1.1,-42.8,1.1,35.2).beginStroke().moveTo(-70.5,35.3).curveTo(-81.9,35.3,-82,24.5).lineTo(-82,-24.5).curveTo(-81.9,-35.3,-70.5,-35.3).lineTo(70.5,-35.3).curveTo(82,-35.3,81.9,-24.5).lineTo(81.9,24.5).curveTo(82,35.3,70.5,35.3).closePath();
	this.shape.setTransform(4.8,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.2,-35.4,163.9,70.6);


(lib.Symbol2copy15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// white
	this.whitebetTxt = new cjs.Text("BET", "bold 22px 'Arial'", "#F2FDBE");
	this.whitebetTxt.name = "whitebetTxt";
	this.whitebetTxt.textAlign = "center";
	this.whitebetTxt.lineHeight = 27;
	this.whitebetTxt.setTransform(-2.5,-14.4);

	this.timeline.addTween(cjs.Tween.get(this.whitebetTxt).wait(1));

	// black
	this.blkbetTxt = new cjs.Text("BET", "bold 22px 'Arial'");
	this.blkbetTxt.name = "blkbetTxt";
	this.blkbetTxt.textAlign = "center";
	this.blkbetTxt.lineHeight = 27;
	this.blkbetTxt.setTransform(-1.5,-13.4);

	this.timeline.addTween(cjs.Tween.get(this.blkbetTxt).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.6,-14.4,49.2,29.6);


(lib.Symbol2copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// whitebetTxt
	this.whitebetTxt = new cjs.Text("REBET", "bold 22px 'Arial'", "#F2FDBE");
	this.whitebetTxt.name = "whitebetTxt";
	this.whitebetTxt.textAlign = "center";
	this.whitebetTxt.lineHeight = 27;
	this.whitebetTxt.setTransform(-2.5,-14.4);

	this.timeline.addTween(cjs.Tween.get(this.whitebetTxt).wait(1));

	// blkbetTxt
	this.blkbetTxt = new cjs.Text("REBET", "bold 22px 'Arial'");
	this.blkbetTxt.name = "blkbetTxt";
	this.blkbetTxt.textAlign = "center";
	this.blkbetTxt.lineHeight = 27;
	this.blkbetTxt.setTransform(-1.5,-13.4);

	this.timeline.addTween(cjs.Tween.get(this.blkbetTxt).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,-14.4,79.7,29.6);


(lib.track = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#666666").beginStroke().moveTo(-125,10.5).lineTo(-125,-10.5).lineTo(125,-10.5).lineTo(125,10.5).closePath();
	this.shape.setTransform(125,10.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250,21);


(lib.slider = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#919191").beginStroke().moveTo(-86.5,9.5).lineTo(-86.5,-9.5).lineTo(86.5,-9.5).lineTo(86.5,9.5).closePath();
	this.shape.setTransform(0,0,0.107,1.079,0,0,0,-86.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.5,20.5);


(lib.contentMask = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#DD00FF").beginStroke().moveTo(-125,81).lineTo(-125,-81).lineTo(125,-81).lineTo(125,81).closePath();
	this.shape.setTransform(125,81);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250,162);


(lib.content = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#33FF00").beginStroke().moveTo(-1.7,125.2).lineTo(-1.7,-125.3).lineTo(1.7,-125.3).lineTo(1.7,125.2).closePath();
	this.shape.setTransform(632.7,125.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#99CC33").beginStroke().moveTo(-18.5,125.2).lineTo(-18.5,-125.3).lineTo(18.5,-125.3).lineTo(18.5,113.8).lineTo(18.5,125.2).closePath();
	this.shape_1.setTransform(18.5,125.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#6600FF").beginStroke().moveTo(-26.8,125.2).lineTo(-26.8,-125.3).lineTo(26.8,-125.3).lineTo(26.8,125.2).closePath();
	this.shape_2.setTransform(604.2,125.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#33FF99").beginStroke().moveTo(-0.3,119.5).lineTo(-0.3,-119.5).lineTo(0.3,-119.5).lineTo(0.3,119.5).closePath();
	this.shape_3.setTransform(37.3,119.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-270.2,125.2).lineTo(-270.2,113.8).lineTo(-269.7,113.8).lineTo(-269.7,-125.3).lineTo(270.2,-125.3).lineTo(270.2,125.2).closePath();
	this.shape_4.setTransform(307.2,125.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,634.5,250.5);


(lib.Path_23_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#1C598C","#2462A0"],[0,1],-76,0,76,0).beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#25442E").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#991F1F").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.5,-67.7).curveTo(43.2,-62.1,53.7,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.7,51.9).curveTo(43.2,62.1,29.5,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,72.9,1,0.987);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,0.4,152,145);


(lib.Path_23_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#5E3682").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#F49ABE").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#4C4C4C").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,98.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,25.4,152,146.9);


(lib.Path_23_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#AD9938").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.5,-67.7).curveTo(43.2,-62.1,53.7,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.7,51.9).curveTo(43.2,62.1,29.5,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#A8693F").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.4,-73.4,0,-73.4).curveTo(15.5,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.3,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.3,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.5,73.4,0,73.4).curveTo(-15.4,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,3.2,152.1,146.9);


(lib.Path_23_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#352725").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#000000").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.Path_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#C1C1C1").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.dummy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#00CCFF").beginStroke().moveTo(-105,66).lineTo(-105,-66).lineTo(105,-66).lineTo(105,66).closePath();
	this.shape.setTransform(105,66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,210.1,132.1);


(lib.rightBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-5.7,5.2).lineTo(-0.4,-0.1).lineTo(-5.6,-5.3).lineTo(-4.1,-6.7).lineTo(-2.6,-8.3).lineTo(-2.4,-8.1).lineTo(-2.4,-8.1).lineTo(-2.3,-8).lineTo(-2.1,-7.8).lineTo(-2,-7.7).lineTo(-2,-7.6).lineTo(-0.5,-6.2).lineTo(0.1,-5.6).lineTo(0.6,-5.1).lineTo(2.4,-3.3).lineTo(2.5,-3.2).lineTo(2.5,-3.2).lineTo(2.6,-3.1).lineTo(2.8,-2.9).lineTo(5.7,-0).lineTo(-2.6,8.3).lineTo(-5.7,5.2).closePath();
	this.shape.setTransform(5.7,8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.4,16.6);


(lib.leftBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-5.7,-0).lineTo(-2.8,-2.9).lineTo(-2.6,-3.1).lineTo(-2.5,-3.2).lineTo(-2.5,-3.2).lineTo(-2.4,-3.3).lineTo(-0.6,-5.1).lineTo(-0.1,-5.6).lineTo(0.5,-6.2).lineTo(2,-7.6).lineTo(2,-7.7).lineTo(2.1,-7.8).lineTo(2.3,-8).lineTo(2.4,-8.1).lineTo(2.4,-8.1).lineTo(2.6,-8.3).lineTo(4.1,-6.7).lineTo(5.6,-5.3).lineTo(0.4,-0.1).lineTo(5.7,5.2).lineTo(2.6,8.3).closePath();
	this.shape.setTransform(5.7,8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.4,16.6);


(lib.dockMaskMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(153,102,153,0.098)").beginStroke().moveTo(-186.1,37).lineTo(-186.1,-37).lineTo(186.1,-37).lineTo(186.1,37).closePath();
	this.shape.setTransform(186.1,37);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,372.2,74);


(lib.dock = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.outline_23_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#1C598C","#2462A0"],[0,1],-76,0,76,0).beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#25442E").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#991F1F").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.5,-67.7).curveTo(43.2,-62.1,53.7,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.7,51.9).curveTo(43.2,62.1,29.5,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#5E3682").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#F49ABE").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#4C4C4C").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,98.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,25.4,152,146.9);


(lib.outline_23_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#AD9938").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.5,-67.7).curveTo(43.2,-62.1,53.7,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.7,51.9).curveTo(43.2,62.1,29.5,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#A8693F").beginStroke().moveTo(-29.6,67.7).curveTo(-43.2,62.1,-53.7,51.9).curveTo(-64.3,41.7,-70,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70,-28.6).curveTo(-64.3,-41.8,-53.7,-51.9).curveTo(-43.2,-62.1,-29.6,-67.7).curveTo(-15.4,-73.4,0,-73.4).curveTo(15.5,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.3,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.3,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.5,73.4,0,73.4).curveTo(-15.4,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.1,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,3.2,152.1,146.9);


(lib.outline_23_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#352725").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline_23_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#000000").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.outline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#C1C1C1").beginStroke().moveTo(-29.6,67.7).curveTo(-43.3,62.1,-53.8,51.9).curveTo(-64.3,41.7,-70.1,28.6).curveTo(-76,14.9,-76,-0).curveTo(-76,-15,-70.1,-28.6).curveTo(-64.3,-41.8,-53.8,-51.9).curveTo(-43.3,-62.1,-29.6,-67.7).curveTo(-15.5,-73.4,-0,-73.4).curveTo(15.4,-73.4,29.6,-67.7).curveTo(43.2,-62.1,53.8,-51.9).curveTo(64.2,-41.8,70,-28.6).curveTo(76,-15,76,-0).curveTo(76,14.9,70,28.6).curveTo(64.2,41.7,53.8,51.9).curveTo(43.2,62.1,29.6,67.7).curveTo(15.4,73.4,-0,73.4).curveTo(-15.5,73.4,-29.6,67.7).closePath();
	this.shape.setTransform(79.2,76.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,3.2,152,146.9);


(lib.boardNum = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"1":0,"2":1,"3":2,"4":3,"5":4,"6":5,"7":6,"8":7,"9":8,"10":9,K:10,".":11});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#000000").beginStroke().moveTo(-3.4,9.5).curveTo(-4.9,8.8,-6.1,7.4).curveTo(-6.9,6.4,-7.5,4.8).curveTo(-8.3,2.6,-8.3,0.2).curveTo(-8.4,-2.9,-7.2,-5.6).curveTo(-6.2,-7.9,-4.2,-9).curveTo(-2.2,-10.2,0,-10.2).curveTo(2.2,-10.2,4.2,-9.1).curveTo(6.2,-7.8,7,-5.9).curveTo(8.3,-3.2,8.3,0).curveTo(8.3,3,7.2,5.5).curveTo(6.6,7,5.5,8).curveTo(4.4,9,3,9.7).curveTo(1.6,10.2,0,10.2).curveTo(-1.9,10.2,-3.4,9.5).closePath().moveTo(-1.3,-8.9).curveTo(-2.1,-8.3,-2.3,-7.1).curveTo(-2.6,-5.8,-2.6,1.8).curveTo(-2.6,6,-2.2,7.4).curveTo(-1.9,8.5,-1.3,8.8).curveTo(-0.8,9.2,0,9.1).curveTo(1,9.2,1.5,8.7).curveTo(2.2,7.9,2.4,6.2).lineTo(2.5,-0.1).lineTo(2.4,-6).curveTo(2.2,-8.1,1.5,-8.8).curveTo(1,-9.2,-0.1,-9.2).curveTo(-0.9,-9.2,-1.3,-8.9).closePath();
	this.shape.setTransform(4.2,5.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#000000").beginStroke().moveTo(-6.6,10).lineTo(-6.6,9.4).lineTo(-5.9,9.4).curveTo(-4.3,9.4,-3.6,9.2).curveTo(-2.9,8.9,-2.6,8.4).curveTo(-2.4,7.9,-2.4,6.1).lineTo(-2.4,-4.2).curveTo(-2.4,-5.5,-2.5,-5.8).curveTo(-2.7,-6.2,-3.2,-6.4).curveTo(-3.6,-6.7,-4.2,-6.7).curveTo(-5.2,-6.7,-6.6,-6.2).lineTo(-7,-6.7).lineTo(2.6,-10).lineTo(3.2,-10).lineTo(3.2,6.1).curveTo(3.2,7.9,3.4,8.3).curveTo(3.6,8.8,4.3,9.1).curveTo(4.9,9.4,6.4,9.4).lineTo(7,9.4).lineTo(7,10).closePath();
	this.shape_1.setTransform(4,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#000000").beginStroke().moveTo(-8.3,10).lineTo(-8.3,9.7).curveTo(-1.3,3.3,0.2,1.2).curveTo(1.7,-1,1.7,-3.1).curveTo(1.7,-4.6,0.4,-5.6).curveTo(-0.8,-6.6,-2.6,-6.6).curveTo(-5.5,-6.6,-7.2,-4.4).lineTo(-7.9,-4.5).curveTo(-6.8,-7.3,-4.7,-8.7).curveTo(-2.6,-10,0.1,-10).curveTo(2.1,-10,3.7,-9.3).curveTo(5.3,-8.6,6.2,-7.4).curveTo(7.1,-6.2,7.1,-5.2).curveTo(7.1,-3.2,5.7,-1.3).curveTo(3.8,1.5,-2.7,6.2).lineTo(2.9,6.2).curveTo(5,6.2,5.6,6.1).curveTo(6.2,5.9,6.6,5.6).curveTo(7,5.3,7.6,4.4).lineTo(8.3,4.4).lineTo(6.9,10).closePath();
	this.shape_2.setTransform(3.7,5.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#000000").beginStroke().moveTo(-7.3,9.4).curveTo(-8.3,8.8,-8.3,7.9).curveTo(-8.3,7.2,-7.7,6.8).curveTo(-7,6.3,-6.3,6.3).curveTo(-5.6,6.3,-5,6.5).lineTo(-2.9,7.8).curveTo(-1.1,8.9,0.6,8.9).curveTo(2,8.9,3,8.1).curveTo(4,7.3,4,6).curveTo(4,3.9,2.2,2.3).curveTo(0.4,0.6,-3.2,-0.1).lineTo(-3.2,-0.6).curveTo(-1,-1,-0.2,-1.4).curveTo(0.7,-1.8,1.3,-2.7).curveTo(1.9,-3.5,1.9,-4.4).curveTo(1.9,-5.6,0.7,-6.4).curveTo(-0.4,-7.3,-2.1,-7.3).curveTo(-4.8,-7.3,-6.6,-5.2).lineTo(-7.4,-5.4).curveTo(-6,-7.8,-3.9,-9).curveTo(-1.7,-10.2,0.9,-10.2).curveTo(3.6,-10.2,5.3,-9).curveTo(7.1,-7.7,7.1,-6.1).curveTo(7.1,-5,6.3,-3.9).curveTo(5.5,-3,3.7,-2.2).curveTo(5.9,-1.3,7.1,-0.1).curveTo(8.3,1.1,8.3,2.8).curveTo(8.3,6,5.4,8.1).curveTo(2.4,10.2,-2.4,10.2).curveTo(-5.8,10.2,-7.3,9.4).closePath();
	this.shape_3.setTransform(3.4,5.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#000000").beginStroke().moveTo(0.9,10).lineTo(0.9,5.6).lineTo(-8.5,5.6).lineTo(-8.5,2.6).lineTo(3.8,-10).lineTo(6.1,-10).lineTo(6.1,2.6).lineTo(8.5,2.6).lineTo(8.5,5.6).lineTo(6.1,5.6).lineTo(6.1,10).closePath().moveTo(-6.7,2.6).lineTo(0.9,2.6).lineTo(0.9,-5.1).closePath();
	this.shape_4.setTransform(3.9,5.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#000000").beginStroke().moveTo(-7.1,9.1).curveTo(-8.3,8.4,-8.3,7.7).curveTo(-8.3,7,-7.6,6.6).curveTo(-7,6.1,-6.2,6.1).curveTo(-5.5,6.1,-4.7,6.3).curveTo(-3.9,6.5,-2.1,7.6).curveTo(-0.9,8.1,-0.1,8.4).curveTo(0.5,8.6,1.2,8.6).curveTo(2.8,8.6,3.9,7.7).curveTo(5,6.8,5,5.6).curveTo(5,3,1.6,1.5).curveTo(-1.7,-0.1,-6.8,-0.1).lineTo(-8.4,-0.1).lineTo(-3.7,-10).lineTo(8.4,-10).lineTo(6.4,-6.3).lineTo(-3.7,-6.3).lineTo(-4.7,-4.3).curveTo(1.9,-4.1,5.4,-1.9).curveTo(8.3,0.1,8.3,2.9).curveTo(8.3,4.7,7,6.4).curveTo(5.6,8.1,3.2,9.1).curveTo(0.7,10,-2.2,10).curveTo(-5.4,10,-7.1,9.1).closePath();
	this.shape_5.setTransform(4.1,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#000000").beginStroke().moveTo(-4.2,9.2).curveTo(-6.2,8.2,-7.3,6.3).curveTo(-8.5,4.4,-8.5,2.1).curveTo(-8.5,-1.1,-6.3,-3.9).curveTo(-4.3,-6.8,-0.5,-8.5).curveTo(3.4,-10.2,8.4,-10.2).lineTo(8.4,-9.8).curveTo(5,-9.2,2.9,-8.1).curveTo(0.8,-7,-0.4,-5.5).curveTo(-1.6,-4.1,-2.3,-1.9).lineTo(-0.9,-2.4).curveTo(0.3,-2.7,1.6,-2.7).curveTo(4.5,-2.7,6.5,-1.1).curveTo(8.3,0.5,8.3,3.3).curveTo(8.3,5.2,7.3,6.8).curveTo(6.3,8.4,4.4,9.3).curveTo(2.4,10.2,0.2,10.2).curveTo(-2.1,10.2,-4.2,9.2).closePath().moveTo(-2.6,-0.7).lineTo(-2.7,2.3).curveTo(-2.7,4.2,-2.2,6.1).curveTo(-1.6,8,-0.8,8.8).curveTo(-0.2,9.2,0.7,9.2).curveTo(1.6,9.3,2.2,8.5).curveTo(3,7.7,2.9,5.3).curveTo(3,1.3,1.7,-0.1).curveTo(0.8,-1.2,-0.6,-1.1).curveTo(-1.3,-1.1,-2.6,-0.7).closePath();
	this.shape_6.setTransform(4.4,5.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#000000").beginStroke().moveTo(-3,10).lineTo(4,-6.2).lineTo(-1.3,-6.2).curveTo(-4.5,-6.1,-6.1,-5.6).curveTo(-7.2,-5.1,-7.9,-3.9).lineTo(-8.6,-3.9).lineTo(-6.7,-10).lineTo(8.7,-10).lineTo(-0.1,10).closePath();
	this.shape_7.setTransform(4.4,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#000000").beginStroke().moveTo(-6.3,8.7).curveTo(-8.4,7.3,-8.4,5.2).curveTo(-8.4,3.6,-7.2,2.4).curveTo(-5.9,1.3,-3.1,0.3).curveTo(-6.2,-1.5,-7.1,-2.6).curveTo(-7.9,-3.8,-8,-5.2).curveTo(-8,-7.2,-5.7,-8.7).curveTo(-3.6,-10.2,0.3,-10.2).curveTo(4,-10.2,6,-8.8).curveTo(8,-7.6,7.9,-5.7).curveTo(7.9,-4.3,6.9,-3.2).curveTo(5.8,-2.2,3.5,-1.3).curveTo(6.3,0.2,7.3,1.5).curveTo(8.4,2.8,8.4,4.5).curveTo(8.4,6.8,6.1,8.5).curveTo(3.7,10.2,-0.3,10.2).curveTo(-4.2,10.2,-6.3,8.7).closePath().moveTo(-2.6,1.8).curveTo(-2.9,2.2,-3.2,3.2).curveTo(-3.6,4.2,-3.6,5.2).curveTo(-3.5,6.6,-3.1,7.5).curveTo(-2.6,8.4,-1.8,8.8).curveTo(-1,9.3,-0.1,9.3).curveTo(1.4,9.3,2.3,8.4).curveTo(3.3,7.7,3.3,6.4).curveTo(3.2,3.6,-1.7,1).curveTo(-2.3,1.4,-2.6,1.8).closePath().moveTo(-1.9,-8.6).curveTo(-2.9,-7.9,-2.8,-6.9).curveTo(-2.9,-5.8,-1.9,-4.7).curveTo(-0.8,-3.5,2.1,-2.1).curveTo(2.8,-2.8,3.2,-3.6).curveTo(3.5,-4.6,3.5,-5.7).curveTo(3.5,-7.5,2.5,-8.5).curveTo(1.6,-9.3,0.2,-9.3).curveTo(-1,-9.3,-1.9,-8.6).closePath();
	this.shape_8.setTransform(4.2,6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#000000").beginStroke().moveTo(-8.4,9.8).curveTo(-5.3,9.2,-3.1,8.2).curveTo(-0.9,7.1,0.4,5.5).curveTo(1.7,3.9,2.2,1.9).lineTo(0.2,2.6).curveTo(-0.7,2.7,-1.6,2.7).curveTo(-4.5,2.8,-6.4,1.1).curveTo(-8.4,-0.4,-8.4,-3.3).curveTo(-8.4,-5.2,-7.3,-6.8).curveTo(-6.3,-8.4,-4.3,-9.3).curveTo(-2.4,-10.2,-0.2,-10.2).curveTo(2,-10.2,4.1,-9.2).curveTo(6,-8.2,7.2,-6.4).curveTo(8.4,-4.5,8.4,-2.1).curveTo(8.5,0.9,6.5,3.8).curveTo(4.6,6.7,0.7,8.3).curveTo(-3.2,10.1,-8.4,10.2).closePath().moveTo(-2.2,-8.6).curveTo(-2.9,-7.7,-2.9,-5.4).curveTo(-2.9,-1.3,-1.7,0.2).curveTo(-0.9,1.1,0.5,1.1).curveTo(1.3,1.2,2.5,0.7).curveTo(2.7,-0.9,2.7,-2.1).curveTo(2.7,-4.8,1.9,-7.1).curveTo(1.4,-8.3,0.5,-8.9).curveTo(0,-9.2,-0.7,-9.2).curveTo(-1.6,-9.2,-2.2,-8.6).closePath();
	this.shape_9.setTransform(4.1,5.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#000000").beginStroke().moveTo(0.9,9.5).lineTo(0.9,9).curveTo(1.5,9,1.7,8.7).curveTo(1.9,8.5,1.9,8.2).curveTo(1.9,7.6,1.1,6).lineTo(-1.8,0.5).lineTo(-2.2,1.1).lineTo(-2.2,6.3).curveTo(-2.2,7.8,-2.1,8.1).curveTo(-2,8.5,-1.7,8.7).curveTo(-1.4,9,-0.7,9).lineTo(-0.7,9.5).lineTo(-7.4,9.5).lineTo(-7.4,9).lineTo(-7,9).curveTo(-6.5,9,-6.1,8.7).curveTo(-5.9,8.5,-5.8,8).curveTo(-5.7,7.7,-5.7,6.3).lineTo(-5.7,-6.3).curveTo(-5.7,-7.7,-5.8,-8.1).curveTo(-5.9,-8.4,-6.2,-8.7).curveTo(-6.5,-9,-7,-9).lineTo(-7.4,-9).lineTo(-7.4,-9.5).lineTo(-0.8,-9.5).lineTo(-0.8,-9).curveTo(-1.4,-9,-1.8,-8.7).curveTo(-2,-8.5,-2.1,-8.1).curveTo(-2.2,-7.7,-2.2,-6.3).lineTo(-2.2,-0.3).lineTo(2.4,-6).curveTo(3.3,-7.2,3.3,-8).curveTo(3.3,-8.5,2.9,-8.8).lineTo(1.9,-9).lineTo(1.9,-9.5).lineTo(6.8,-9.5).lineTo(6.8,-9).curveTo(6.2,-8.9,5.9,-8.6).lineTo(5.7,-8.5).lineTo(0.9,-1.3).lineTo(4.8,6.1).curveTo(5.7,7.9,6.4,8.6).curveTo(6.9,9,7.4,9).lineTo(7.4,9.5).closePath();
	this.shape_10.setTransform(3.5,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#000000").beginStroke().moveTo(-0.6,0.6).curveTo(-0.8,0.4,-0.8,-0).curveTo(-0.8,-0.4,-0.6,-0.6).curveTo(-0.3,-0.8,0,-0.8).curveTo(0.3,-0.8,0.6,-0.6).curveTo(0.8,-0.4,0.8,0).curveTo(0.8,0.4,0.6,0.6).curveTo(0.3,0.8,0,0.8).curveTo(-0.3,0.8,-0.6,0.6).closePath();
	this.shape_11.setTransform(4.8,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.1,-4.3,16.7,20.4);


(lib.betTextMc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// whiteTxt
	this.whitebetTxt = new cjs.Text("CLEAR", "bold 10px 'Arial'", "#FFFFFF");
	this.whitebetTxt.name = "whitebetTxt";
	this.whitebetTxt.textAlign = "center";
	this.whitebetTxt.lineHeight = 13;
	this.whitebetTxt.lineWidth = 81;
	this.whitebetTxt.setTransform(-1.7,-4.8);

	this.timeline.addTween(cjs.Tween.get(this.whitebetTxt).wait(1));

	// blackTxt
	this.blkbetTxt = new cjs.Text("CLEAR", "bold 10px 'Arial'");
	this.blkbetTxt.name = "blkbetTxt";
	this.blkbetTxt.textAlign = "center";
	this.blkbetTxt.lineHeight = 13;
	this.blkbetTxt.lineWidth = 81;
	this.blkbetTxt.setTransform(-1.6,-4.6);

	this.timeline.addTween(cjs.Tween.get(this.blkbetTxt).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,-4.8,85,15.6);


(lib.numbers = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"1":0,"2":1,"3":2,"4":3,"5":4,"6":5,"7":6,"8":7,"9":8,"10":9,"K":10,".":11});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#000000").beginStroke().moveTo(-3.4,9.5).curveTo(-4.9,8.8,-6.1,7.4).curveTo(-6.9,6.4,-7.5,4.8).curveTo(-8.3,2.6,-8.3,0.2).curveTo(-8.4,-2.9,-7.2,-5.6).curveTo(-6.2,-7.9,-4.2,-9).curveTo(-2.2,-10.2,0,-10.2).curveTo(2.2,-10.2,4.2,-9.1).curveTo(6.2,-7.8,7,-5.9).curveTo(8.3,-3.2,8.3,0).curveTo(8.3,3,7.2,5.5).curveTo(6.6,7,5.5,8).curveTo(4.4,9,3,9.7).curveTo(1.6,10.2,0,10.2).curveTo(-1.9,10.2,-3.4,9.5).closePath().moveTo(-1.3,-8.9).curveTo(-2.1,-8.3,-2.3,-7.1).curveTo(-2.6,-5.8,-2.6,1.8).curveTo(-2.6,6,-2.2,7.4).curveTo(-1.9,8.5,-1.3,8.8).curveTo(-0.8,9.2,0,9.1).curveTo(1,9.2,1.5,8.7).curveTo(2.2,7.9,2.4,6.2).lineTo(2.5,-0.1).lineTo(2.4,-6).curveTo(2.2,-8.1,1.5,-8.8).curveTo(1,-9.2,-0.1,-9.2).curveTo(-0.9,-9.2,-1.3,-8.9).closePath();
	this.shape.setTransform(4.2,5.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#000000").beginStroke().moveTo(-6.6,10).lineTo(-6.6,9.4).lineTo(-5.9,9.4).curveTo(-4.3,9.4,-3.6,9.2).curveTo(-2.9,8.9,-2.6,8.4).curveTo(-2.4,7.9,-2.4,6.1).lineTo(-2.4,-4.2).curveTo(-2.4,-5.5,-2.5,-5.8).curveTo(-2.7,-6.2,-3.2,-6.4).curveTo(-3.6,-6.7,-4.2,-6.7).curveTo(-5.2,-6.7,-6.6,-6.2).lineTo(-7,-6.7).lineTo(2.6,-10).lineTo(3.2,-10).lineTo(3.2,6.1).curveTo(3.2,7.9,3.4,8.3).curveTo(3.6,8.8,4.3,9.1).curveTo(4.9,9.4,6.4,9.4).lineTo(7,9.4).lineTo(7,10).closePath();
	this.shape_1.setTransform(4,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#000000").beginStroke().moveTo(-8.3,10).lineTo(-8.3,9.7).curveTo(-1.3,3.3,0.2,1.2).curveTo(1.7,-1,1.7,-3.1).curveTo(1.7,-4.6,0.4,-5.6).curveTo(-0.8,-6.6,-2.6,-6.6).curveTo(-5.5,-6.6,-7.2,-4.4).lineTo(-7.9,-4.5).curveTo(-6.8,-7.3,-4.7,-8.7).curveTo(-2.6,-10,0.1,-10).curveTo(2.1,-10,3.7,-9.3).curveTo(5.3,-8.6,6.2,-7.4).curveTo(7.1,-6.2,7.1,-5.2).curveTo(7.1,-3.2,5.7,-1.3).curveTo(3.8,1.5,-2.7,6.2).lineTo(2.9,6.2).curveTo(5,6.2,5.6,6.1).curveTo(6.2,5.9,6.6,5.6).curveTo(7,5.3,7.6,4.4).lineTo(8.3,4.4).lineTo(6.9,10).closePath();
	this.shape_2.setTransform(3.7,5.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#000000").beginStroke().moveTo(-7.3,9.4).curveTo(-8.3,8.8,-8.3,7.9).curveTo(-8.3,7.2,-7.7,6.8).curveTo(-7,6.3,-6.3,6.3).curveTo(-5.6,6.3,-5,6.5).lineTo(-2.9,7.8).curveTo(-1.1,8.9,0.6,8.9).curveTo(2,8.9,3,8.1).curveTo(4,7.3,4,6).curveTo(4,3.9,2.2,2.3).curveTo(0.4,0.6,-3.2,-0.1).lineTo(-3.2,-0.6).curveTo(-1,-1,-0.2,-1.4).curveTo(0.7,-1.8,1.3,-2.7).curveTo(1.9,-3.5,1.9,-4.4).curveTo(1.9,-5.6,0.7,-6.4).curveTo(-0.4,-7.3,-2.1,-7.3).curveTo(-4.8,-7.3,-6.6,-5.2).lineTo(-7.4,-5.4).curveTo(-6,-7.8,-3.9,-9).curveTo(-1.7,-10.2,0.9,-10.2).curveTo(3.6,-10.2,5.3,-9).curveTo(7.1,-7.7,7.1,-6.1).curveTo(7.1,-5,6.3,-3.9).curveTo(5.5,-3,3.7,-2.2).curveTo(5.9,-1.3,7.1,-0.1).curveTo(8.3,1.1,8.3,2.8).curveTo(8.3,6,5.4,8.1).curveTo(2.4,10.2,-2.4,10.2).curveTo(-5.8,10.2,-7.3,9.4).closePath();
	this.shape_3.setTransform(3.4,5.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#000000").beginStroke().moveTo(0.9,10).lineTo(0.9,5.6).lineTo(-8.5,5.6).lineTo(-8.5,2.6).lineTo(3.8,-10).lineTo(6.1,-10).lineTo(6.1,2.6).lineTo(8.5,2.6).lineTo(8.5,5.6).lineTo(6.1,5.6).lineTo(6.1,10).closePath().moveTo(-6.7,2.6).lineTo(0.9,2.6).lineTo(0.9,-5.1).closePath();
	this.shape_4.setTransform(3.9,5.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#000000").beginStroke().moveTo(-7.1,9.1).curveTo(-8.3,8.4,-8.3,7.7).curveTo(-8.3,7,-7.6,6.6).curveTo(-7,6.1,-6.2,6.1).curveTo(-5.5,6.1,-4.7,6.3).curveTo(-3.9,6.5,-2.1,7.6).curveTo(-0.9,8.1,-0.1,8.4).curveTo(0.5,8.6,1.2,8.6).curveTo(2.8,8.6,3.9,7.7).curveTo(5,6.8,5,5.6).curveTo(5,3,1.6,1.5).curveTo(-1.7,-0.1,-6.8,-0.1).lineTo(-8.4,-0.1).lineTo(-3.7,-10).lineTo(8.4,-10).lineTo(6.4,-6.3).lineTo(-3.7,-6.3).lineTo(-4.7,-4.3).curveTo(1.9,-4.1,5.4,-1.9).curveTo(8.3,0.1,8.3,2.9).curveTo(8.3,4.7,7,6.4).curveTo(5.6,8.1,3.2,9.1).curveTo(0.7,10,-2.2,10).curveTo(-5.4,10,-7.1,9.1).closePath();
	this.shape_5.setTransform(4.1,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#000000").beginStroke().moveTo(-4.2,9.2).curveTo(-6.2,8.2,-7.3,6.3).curveTo(-8.5,4.4,-8.5,2.1).curveTo(-8.5,-1.1,-6.3,-3.9).curveTo(-4.3,-6.8,-0.5,-8.5).curveTo(3.4,-10.2,8.4,-10.2).lineTo(8.4,-9.8).curveTo(5,-9.2,2.9,-8.1).curveTo(0.8,-7,-0.4,-5.5).curveTo(-1.6,-4.1,-2.3,-1.9).lineTo(-0.9,-2.4).curveTo(0.3,-2.7,1.6,-2.7).curveTo(4.5,-2.7,6.5,-1.1).curveTo(8.3,0.5,8.3,3.3).curveTo(8.3,5.2,7.3,6.8).curveTo(6.3,8.4,4.4,9.3).curveTo(2.4,10.2,0.2,10.2).curveTo(-2.1,10.2,-4.2,9.2).closePath().moveTo(-2.6,-0.7).lineTo(-2.7,2.3).curveTo(-2.7,4.2,-2.2,6.1).curveTo(-1.6,8,-0.8,8.8).curveTo(-0.2,9.2,0.7,9.2).curveTo(1.6,9.3,2.2,8.5).curveTo(3,7.7,2.9,5.3).curveTo(3,1.3,1.7,-0.1).curveTo(0.8,-1.2,-0.6,-1.1).curveTo(-1.3,-1.1,-2.6,-0.7).closePath();
	this.shape_6.setTransform(4.4,5.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#000000").beginStroke().moveTo(-3,10).lineTo(4,-6.2).lineTo(-1.3,-6.2).curveTo(-4.5,-6.1,-6.1,-5.6).curveTo(-7.2,-5.1,-7.9,-3.9).lineTo(-8.6,-3.9).lineTo(-6.7,-10).lineTo(8.7,-10).lineTo(-0.1,10).closePath();
	this.shape_7.setTransform(4.4,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#000000").beginStroke().moveTo(-6.3,8.7).curveTo(-8.4,7.3,-8.4,5.2).curveTo(-8.4,3.6,-7.2,2.4).curveTo(-5.9,1.3,-3.1,0.3).curveTo(-6.2,-1.5,-7.1,-2.6).curveTo(-7.9,-3.8,-8,-5.2).curveTo(-8,-7.2,-5.7,-8.7).curveTo(-3.6,-10.2,0.3,-10.2).curveTo(4,-10.2,6,-8.8).curveTo(8,-7.6,7.9,-5.7).curveTo(7.9,-4.3,6.9,-3.2).curveTo(5.8,-2.2,3.5,-1.3).curveTo(6.3,0.2,7.3,1.5).curveTo(8.4,2.8,8.4,4.5).curveTo(8.4,6.8,6.1,8.5).curveTo(3.7,10.2,-0.3,10.2).curveTo(-4.2,10.2,-6.3,8.7).closePath().moveTo(-2.6,1.8).curveTo(-2.9,2.2,-3.2,3.2).curveTo(-3.6,4.2,-3.6,5.2).curveTo(-3.5,6.6,-3.1,7.5).curveTo(-2.6,8.4,-1.8,8.8).curveTo(-1,9.3,-0.1,9.3).curveTo(1.4,9.3,2.3,8.4).curveTo(3.3,7.7,3.3,6.4).curveTo(3.2,3.6,-1.7,1).curveTo(-2.3,1.4,-2.6,1.8).closePath().moveTo(-1.9,-8.6).curveTo(-2.9,-7.9,-2.8,-6.9).curveTo(-2.9,-5.8,-1.9,-4.7).curveTo(-0.8,-3.5,2.1,-2.1).curveTo(2.8,-2.8,3.2,-3.6).curveTo(3.5,-4.6,3.5,-5.7).curveTo(3.5,-7.5,2.5,-8.5).curveTo(1.6,-9.3,0.2,-9.3).curveTo(-1,-9.3,-1.9,-8.6).closePath();
	this.shape_8.setTransform(4.2,6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#000000").beginStroke().moveTo(-8.4,9.8).curveTo(-5.3,9.2,-3.1,8.2).curveTo(-0.9,7.1,0.4,5.5).curveTo(1.7,3.9,2.2,1.9).lineTo(0.2,2.6).curveTo(-0.7,2.7,-1.6,2.7).curveTo(-4.5,2.8,-6.4,1.1).curveTo(-8.4,-0.4,-8.4,-3.3).curveTo(-8.4,-5.2,-7.3,-6.8).curveTo(-6.3,-8.4,-4.3,-9.3).curveTo(-2.4,-10.2,-0.2,-10.2).curveTo(2,-10.2,4.1,-9.2).curveTo(6,-8.2,7.2,-6.4).curveTo(8.4,-4.5,8.4,-2.1).curveTo(8.5,0.9,6.5,3.8).curveTo(4.6,6.7,0.7,8.3).curveTo(-3.2,10.1,-8.4,10.2).closePath().moveTo(-2.2,-8.6).curveTo(-2.9,-7.7,-2.9,-5.4).curveTo(-2.9,-1.3,-1.7,0.2).curveTo(-0.9,1.1,0.5,1.1).curveTo(1.3,1.2,2.5,0.7).curveTo(2.7,-0.9,2.7,-2.1).curveTo(2.7,-4.8,1.9,-7.1).curveTo(1.4,-8.3,0.5,-8.9).curveTo(0,-9.2,-0.7,-9.2).curveTo(-1.6,-9.2,-2.2,-8.6).closePath();
	this.shape_9.setTransform(4.1,5.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#000000").beginStroke().moveTo(0.9,9.5).lineTo(0.9,9).curveTo(1.5,9,1.7,8.7).curveTo(1.9,8.5,1.9,8.2).curveTo(1.9,7.6,1.1,6).lineTo(-1.8,0.5).lineTo(-2.2,1.1).lineTo(-2.2,6.3).curveTo(-2.2,7.8,-2.1,8.1).curveTo(-2,8.5,-1.7,8.7).curveTo(-1.4,9,-0.7,9).lineTo(-0.7,9.5).lineTo(-7.4,9.5).lineTo(-7.4,9).lineTo(-7,9).curveTo(-6.5,9,-6.1,8.7).curveTo(-5.9,8.5,-5.8,8).curveTo(-5.7,7.7,-5.7,6.3).lineTo(-5.7,-6.3).curveTo(-5.7,-7.7,-5.8,-8.1).curveTo(-5.9,-8.4,-6.2,-8.7).curveTo(-6.5,-9,-7,-9).lineTo(-7.4,-9).lineTo(-7.4,-9.5).lineTo(-0.8,-9.5).lineTo(-0.8,-9).curveTo(-1.4,-9,-1.8,-8.7).curveTo(-2,-8.5,-2.1,-8.1).curveTo(-2.2,-7.7,-2.2,-6.3).lineTo(-2.2,-0.3).lineTo(2.4,-6).curveTo(3.3,-7.2,3.3,-8).curveTo(3.3,-8.5,2.9,-8.8).lineTo(1.9,-9).lineTo(1.9,-9.5).lineTo(6.8,-9.5).lineTo(6.8,-9).curveTo(6.2,-8.9,5.9,-8.6).lineTo(5.7,-8.5).lineTo(0.9,-1.3).lineTo(4.8,6.1).curveTo(5.7,7.9,6.4,8.6).curveTo(6.9,9,7.4,9).lineTo(7.4,9.5).closePath();
	this.shape_10.setTransform(3.5,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#000000").beginStroke().moveTo(-0.6,0.6).curveTo(-0.8,0.4,-0.8,-0).curveTo(-0.8,-0.4,-0.6,-0.6).curveTo(-0.3,-0.8,0,-0.8).curveTo(0.3,-0.8,0.6,-0.6).curveTo(0.8,-0.4,0.8,0).curveTo(0.8,0.4,0.6,0.6).curveTo(0.3,0.8,0,0.8).curveTo(-0.3,0.8,-0.6,0.6).closePath();
	this.shape_11.setTransform(4.8,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.1,-4.3,16.7,20.4);


(lib.Betcopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#2E2511").setStrokeStyle(1.5,1,1).moveTo(-1.1,-19.3).lineTo(9.6,-21.4).curveTo(12.5,-22.1,13.4,-21.9).curveTo(14.5,-21.5,15.1,-19.4).lineTo(22.4,9.5).curveTo(23.2,12.1,19.7,13).lineTo(6.2,15.9).lineTo(6.2,16.8).lineTo(6.2,20.4).curveTo(-5.7,25.5,-14.6,20.4).lineTo(-14.6,16.8).lineTo(-14.6,12.4).lineTo(-14.6,7.9).lineTo(-14.6,3.3).curveTo(-14.1,2.9,-13.5,2.6).curveTo(-9.5,0.1,-4.9,0.1).curveTo(0,0,5.5,2.9).curveTo(6.1,3.4,6.2,4.1).lineTo(6.2,7.9).lineTo(6.2,12.4).lineTo(6.2,15.9).moveTo(-13.5,2.6).lineTo(-21.4,-6.9).curveTo(-22.5,-8.4,-22.5,-9.2).curveTo(-22.4,-10.2,-20.9,-11.7).lineTo(-7.7,-22.1).curveTo(-5.3,-23.8,-3.8,-22.2).lineTo(-1.1,-19.3).lineTo(-4.9,-18.5).curveTo(-9.2,-17.7,-8.2,-13.7).lineTo(-4.9,0.1).moveTo(-14.6,16.8).curveTo(-6.5,20.5,6.2,16.8).moveTo(-14.6,12.4).curveTo(-5.9,16.5,6.2,12.4).moveTo(-14.6,7.9).curveTo(-6.1,12.4,6.2,7.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],10,1.9,-10.1,-3.8).beginStroke().moveTo(-10.4,0.5).lineTo(-10.4,-3.1).curveTo(-2.3,0.6,10.4,-3.1).lineTo(10.4,0.5).curveTo(4.4,3.1,-0.8,3.1).curveTo(-6,3.1,-10.4,0.5).closePath();
	this.shape_1.setTransform(-4.2,19.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],0.1,4.4,0.1,-1.9).beginStroke().moveTo(-10.4,1.3).lineTo(-10.4,-3.1).curveTo(-1.7,1,10.4,-3.1).lineTo(10.4,0.4).lineTo(10.4,1.3).curveTo(4,3.1,-1.2,3.1).curveTo(-6.3,3.1,-10.4,1.3).closePath();
	this.shape_2.setTransform(-4.2,15.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],0,4.5,0,-2.1).beginStroke().moveTo(-10.4,1.2).lineTo(-10.4,-3.3).curveTo(-1.9,1.2,10.4,-3.3).lineTo(10.4,1.2).curveTo(4.3,3.3,-0.8,3.3).curveTo(-6,3.3,-10.4,1.2).closePath();
	this.shape_3.setTransform(-4.2,11.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],10.3,3.1,-10.1,-2.6).beginStroke().moveTo(-10.4,2.8).lineTo(-10.4,-1.8).lineTo(-9.3,-2.5).curveTo(-5.3,-5,-0.7,-5).curveTo(4.2,-5.1,9.7,-2.2).curveTo(10.3,-1.7,10.4,-1).lineTo(10.4,2.8).curveTo(4.2,5,-0.9,5).curveTo(-6.1,5,-10.4,2.8).closePath();
	this.shape_4.setTransform(-4.2,5.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],9.3,2,-9.4,-3.3).beginStroke().moveTo(-9.6,3.2).curveTo(-10.7,1.7,-10.7,0.9).curveTo(-10.6,-0.1,-9.1,-1.6).lineTo(4.1,-12).curveTo(6.5,-13.6,8,-12).lineTo(10.7,-9.2).lineTo(6.9,-8.3).curveTo(2.6,-7.6,3.6,-3.5).lineTo(6.9,10.2).curveTo(2.3,10.2,-1.7,12.8).closePath();
	this.shape_5.setTransform(-11.8,-10.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],14.9,4.2,-14.8,-4.2).beginStroke().moveTo(-0.9,15.4).lineTo(-0.9,10.9).lineTo(-0.9,7.2).curveTo(-1,6.5,-1.6,6).curveTo(-7.1,3.1,-12,3.1).lineTo(-15.3,-10.6).curveTo(-16.3,-14.7,-12,-15.4).lineTo(-8.2,-16.3).lineTo(2.5,-18.4).curveTo(5.4,-19.1,6.3,-18.8).curveTo(7.4,-18.5,8,-16.4).lineTo(15.3,12.6).curveTo(16.1,15.2,12.6,16).lineTo(-0.9,18.9).closePath();
	this.shape_6.setTransform(7.1,-3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.5,-23.9,47,47.9);


(lib.Betcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#2E2511").setStrokeStyle(1.5,1,1).moveTo(-10.4,-3.6).lineTo(-10.4,-8.2).curveTo(-9.9,-8.6,-9.3,-8.9).curveTo(-5.3,-11.4,-0.7,-11.4).curveTo(4.2,-11.5,9.7,-8.6).curveTo(10.3,-8.1,10.4,-7.4).lineTo(10.4,-3.6).lineTo(10.4,0.9).lineTo(10.4,5.3).lineTo(10.4,8.9).curveTo(-1.5,14,-10.4,8.9).lineTo(-10.4,5.3).lineTo(-10.4,0.9).lineTo(-10.4,-3.6).curveTo(-1.9,0.9,10.4,-3.6).moveTo(-10.4,5.3).curveTo(-2.3,9,10.4,5.3).moveTo(-10.4,0.9).curveTo(-1.7,5,10.4,0.9);
	this.shape.setTransform(-4.4,11.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],10.3,3.1,-10.1,-2.6).beginStroke().moveTo(-10.4,2.8).lineTo(-10.4,-1.8).lineTo(-9.3,-2.5).curveTo(-5.3,-5,-0.7,-5).curveTo(4.2,-5.1,9.7,-2.2).curveTo(10.3,-1.7,10.4,-1).lineTo(10.4,2.8).curveTo(4.3,5,-0.9,5).curveTo(-6.1,5,-10.4,2.8).closePath();
	this.shape_1.setTransform(-4.4,5.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],0,4.5,0,-2.1).beginStroke().moveTo(-10.4,1.2).lineTo(-10.4,-3.3).curveTo(-1.9,1.2,10.4,-3.3).lineTo(10.4,1.2).curveTo(4.4,3.3,-0.8,3.3).curveTo(-6,3.3,-10.4,1.2).closePath();
	this.shape_2.setTransform(-4.4,11.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],0.1,4.4,0.1,-1.9).beginStroke().moveTo(-10.4,1.3).lineTo(-10.4,-3.1).curveTo(-1.7,1,10.4,-3.1).lineTo(10.4,1.3).curveTo(4,3.1,-1.2,3.1).curveTo(-6.4,3.1,-10.4,1.3).closePath();
	this.shape_3.setTransform(-4.4,15.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],10,1.9,-10.1,-3.8).beginStroke().moveTo(-10.4,0.5).lineTo(-10.4,-3.1).curveTo(-2.3,0.6,10.4,-3.1).lineTo(10.4,0.5).curveTo(4.4,3.1,-0.8,3.1).curveTo(-5.9,3.1,-10.4,0.5).closePath();
	this.shape_4.setTransform(-4.4,19.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill().beginStroke("#2E2511").setStrokeStyle(1.5,1,1).moveTo(-1.1,-15.8).lineTo(9.6,-17.9).curveTo(12.5,-18.6,13.4,-18.3).curveTo(14.5,-18,15.1,-15.9).lineTo(22.4,13.1).curveTo(23.2,15.7,19.7,16.5).lineTo(6.2,19.4).moveTo(-1.1,-15.8).lineTo(-4.9,-14.9).curveTo(-9.2,-14.2,-8.2,-10.1).lineTo(-4.9,3.6).moveTo(-13.5,6.2).lineTo(-21.4,-3.4).curveTo(-22.5,-4.9,-22.5,-5.7).curveTo(-22.4,-6.7,-20.9,-8.2).lineTo(-7.7,-18.6).curveTo(-5.3,-20.2,-3.8,-18.6).lineTo(-1.1,-15.8);
	this.shape_5.setTransform(0,-3.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],9.3,2,-9.4,-3.3).beginStroke().moveTo(-9.6,3.2).curveTo(-10.7,1.7,-10.7,0.9).curveTo(-10.6,-0.1,-9.1,-1.6).lineTo(4.1,-12).curveTo(6.5,-13.6,8,-12).lineTo(10.7,-9.2).lineTo(6.9,-8.3).curveTo(2.6,-7.6,3.6,-3.5).lineTo(6.9,10.2).curveTo(2.3,10.2,-1.7,12.8).closePath();
	this.shape_6.setTransform(-11.8,-10.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginLinearGradientFill(["#E5E5E5","#FFFFFF"],[0,1],14.9,4.2,-14.8,-4.2).beginStroke().moveTo(-0.9,7.2).curveTo(-1,6.5,-1.6,6).curveTo(-7.1,3.1,-12,3.1).lineTo(-15.3,-10.6).curveTo(-16.3,-14.7,-12,-15.4).lineTo(-8.2,-16.3).lineTo(2.5,-18.4).curveTo(5.4,-19.1,6.3,-18.8).curveTo(7.4,-18.5,8,-16.4).lineTo(15.3,12.6).curveTo(16.1,15.2,12.6,16).lineTo(-0.9,18.9).closePath();
	this.shape_7.setTransform(7.1,-3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.5,-23.9,47,47.9);


(lib.Symbol3copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFCC").setStrokeStyle(1,1,1).moveTo(-2.8,-1.6).curveTo(4.5,-4.6,7.3,-8.3).curveTo(10.7,-4.4,11.6,0.9).curveTo(5.3,5.6,-1.8,4.7).lineTo(-1.2,8.3).lineTo(-11.6,3.1).lineTo(-3.4,-5.7).closePath();
	this.shape.setTransform(8.4,-10.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#6A3E00").beginStroke().moveTo(-11.6,3.1).lineTo(-3.4,-5.7).lineTo(-2.7,-1.6).curveTo(4.5,-4.6,7.3,-8.3).curveTo(10.7,-4.4,11.6,0.9).curveTo(5.3,5.6,-1.7,4.7).lineTo(-1.1,8.3).closePath();
	this.shape_1.setTransform(8.4,-10.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 3
	this.instance = new lib.Betcopy2();
	this.instance.setTransform(-3.5,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#935602","#6E460B"],[0,1],-13,20.3,-12.1,-20.7).beginStroke().moveTo(-17,17).curveTo(-24,9.9,-24,0).curveTo(-24,-9.9,-17,-16.9).curveTo(-10,-24,-0,-24).curveTo(10,-24,17,-16.9).curveTo(24,-9.9,24,0).curveTo(24,9.9,17,17).curveTo(10,24,-0,24).curveTo(-10,24,-17,17).closePath();
	this.shape_2.setTransform(-3.6,-1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.6,-25.9,48.7,48);


(lib.Symbol1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{rout:0,rover:1});

	// text
	this.betTxtMC = new lib.Symbol2copy5();
	this.betTxtMC.setTransform(29.5,3);

	this.instance = new lib.Symbol3copy5();
	this.instance.setTransform(-38.7,1.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.betTxtMC}]}).to({state:[{t:this.instance},{t:this.betTxtMC}]},1).wait(1));

	// mc
	this.instance_1 = new lib.Symbol6copy6();

	this.instance_2 = new lib.Symbol6copy2();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#755720").setStrokeStyle(1.5,1,1).moveTo(72.8,-38.5).lineTo(-72.8,-38.5).curveTo(-85.5,-38.5,-85.5,-26.5).lineTo(-85.5,26.5).curveTo(-85.5,38.5,-72.8,38.5).lineTo(72.8,38.5).curveTo(85.5,38.5,85.5,26.5).lineTo(85.5,-26.5).curveTo(85.5,-38.5,72.8,-38.5).closePath();
	this.shape.setTransform(5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#B6A153","#FFD76D","#BF994D"],[0,0.506,1],-85.5,0,85.5,0).beginStroke().moveTo(-72.8,38.5).curveTo(-85.5,38.5,-85.5,26.5).lineTo(-85.5,-26.5).curveTo(-85.5,-38.5,-72.8,-38.5).lineTo(72.8,-38.5).curveTo(85.5,-38.5,85.5,-26.5).lineTo(85.5,26.5).curveTo(85.5,38.5,72.8,38.5).closePath();
	this.shape_1.setTransform(5,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("#F8C929").setStrokeStyle(1.5,1,1).moveTo(72.8,-38.5).lineTo(-72.8,-38.5).curveTo(-85.5,-38.5,-85.5,-26.5).lineTo(-85.5,26.5).curveTo(-85.5,38.5,-72.8,38.5).lineTo(72.8,38.5).curveTo(85.5,38.5,85.5,26.5).lineTo(85.5,-26.5).curveTo(85.5,-38.5,72.8,-38.5).closePath();
	this.shape_2.setTransform(5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,-39.5,173,79);


(lib.ddd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Betcopy3();
	this.instance.setTransform(-3.5,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#935602","#6E460B"],[0,1],-13,20.3,-12.1,-20.7).beginStroke().moveTo(-17,17).curveTo(-24,9.9,-24,0).curveTo(-24,-9.9,-17,-16.9).curveTo(-10,-24,-0,-24).curveTo(10,-24,17,-16.9).curveTo(24,-9.9,24,0).curveTo(24,9.9,17,17).curveTo(10,24,-0,24).curveTo(-10,24,-17,17).closePath();
	this.shape.setTransform(-3.6,-1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.6,-25.9,48,48);


(lib.Clear = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// text
	this.betTxtMC = new lib.betTextMc();
	this.betTxtMC.setTransform(42.3,27.4);

	this.timeline.addTween(cjs.Tween.get(this.betTxtMC).wait(2));

	// design
	this.shape = new cjs.Shape();
	this.shape.graphics.beginLinearGradientFill(["#946522","#DBA13E","#977430","#AB9C8A"],[0.18,0.478,0.651,1],9.3,6.6,9.3,-6.6).beginStroke().moveTo(-6.3,4.3).lineTo(-2.4,0.1).lineTo(-6.4,-4.3).lineTo(-4.1,-6.7).lineTo(-0.1,-2.5).lineTo(2,-4.7).lineTo(4,-6.8).lineTo(5.3,-5.6).lineTo(6.4,-4.4).curveTo(4.4,-2.4,2.3,-0.2).lineTo(6.5,4.3).lineTo(4.3,6.6).lineTo(4.2,6.7).lineTo(4.1,6.8).lineTo(4,6.7).lineTo(3.9,6.6).lineTo(0.1,2.5).lineTo(-4.1,6.8).closePath();
	this.shape.setTransform(43.1,12.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill().beginLinearGradientStroke(["#B1AFAB","#8A7555","#A49170","#5B4429"],[0,0.333,0.667,1],0,-19.5,0,19.5).setStrokeStyle(1,1,1).moveTo(-39.6,-19.5).lineTo(39.6,-19.5).curveTo(42.6,-19.5,42.6,-16.5).lineTo(42.6,16.5).curveTo(42.6,19.5,39.6,19.5).lineTo(-39.6,19.5).curveTo(-42.6,19.5,-42.6,16.5).lineTo(-42.6,-16.5).curveTo(-42.6,-19.5,-39.6,-19.5).closePath();
	this.shape_1.setTransform(42.6,19.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#1D1F20","#555555"],[0,1],20.1,19.5,20.1,-19.5).beginStroke().moveTo(-39.6,19.5).curveTo(-42.6,19.5,-42.6,16.5).lineTo(-42.6,-16.5).curveTo(-42.6,-19.5,-39.6,-19.5).lineTo(39.6,-19.5).curveTo(42.6,-19.5,42.6,-16.5).lineTo(42.6,16.5).curveTo(42.6,19.5,39.6,19.5).closePath();
	this.shape_2.setTransform(42.6,19.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#1D1F20","#555555"],[0,1],-20,-19.5,-20,19.5).beginStroke().moveTo(-39.6,19.5).curveTo(-42.6,19.5,-42.6,16.5).lineTo(-42.6,-16.5).curveTo(-42.6,-19.5,-39.6,-19.5).lineTo(39.6,-19.5).curveTo(42.6,-19.5,42.6,-16.5).lineTo(42.6,16.5).curveTo(42.6,19.5,39.6,19.5).closePath();
	this.shape_3.setTransform(42.6,19.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_3},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,87.3,41);


(lib.chipTray = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// RightArrow
	this.rightBtn = new lib.rightBtn();
	this.rightBtn.setTransform(402.4,33.3,1,1,0,0,0,5.7,8.3);

	this.timeline.addTween(cjs.Tween.get(this.rightBtn).wait(1));

	// LeftArrow
	this.leftBtn = new lib.leftBtn();
	this.leftBtn.setTransform(13.8,33.3,1,1,0,0,0,5.7,8.3);

	this.timeline.addTween(cjs.Tween.get(this.leftBtn).wait(1));

	// mask
	this.dockMask = new lib.dockMaskMC();
	this.dockMask.setTransform(23.6,-0.3,1,1,0,0,0,-1,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.dockMask).wait(1));

	// dock_mc
	this.dock_mc = new lib.dock();
	this.dock_mc.setTransform(25.8,0);

	this.timeline.addTween(cjs.Tween.get(this.dock_mc).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8.1,0,400,74);


(lib.boardchipVal = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"1":0,"2":1,"3":2,"4":3,"5":4});

	// Layer 6
	this.counter4 = new lib.boardNum();
	this.counter4.setTransform(12.4,1.4,0.325,0.328,0,-1.7,-4.7,6.7,13.4);
	this.counter4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter4).wait(4).to({_off:false},0).wait(1));

	// Layer 5
	this.counter3 = new lib.boardNum();
	this.counter3.setTransform(12.3,2.2,0.433,0.438,0,-1.4,-4.5,7,13.2);
	this.counter3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter3).wait(3).to({_off:false},0).wait(1).to({regY:13.3,scaleX:0.33,scaleY:0.33,skewX:-1.9,skewY:-5,x:6.8,y:1.4},0).wait(1));

	// Layer 4
	this.counter2 = new lib.boardNum();
	this.counter2.setTransform(11.4,3.5,0.578,0.584,0,-1.6,-4.7,6.9,13.4);
	this.counter2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter2).wait(2).to({_off:false},0).wait(1).to({regX:6.8,regY:13.3,scaleX:0.43,scaleY:0.44,skewX:-0.3,skewY:-3.4,x:4.8,y:2.2},0).wait(1).to({regY:13.2,scaleX:0.33,scaleY:0.33,skewX:-0.1,skewY:-3.2,x:1.2,y:1.4},0).wait(1));

	// Layer 2
	this.counter1 = new lib.boardNum();
	this.counter1.setTransform(6.4,3.4,0.578,0.584,0,-1.9,-5,7,13.4);
	this.counter1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter1).wait(1).to({_off:false},0).wait(1).to({regX:6.8,regY:13.3,skewX:0.1,skewY:-3,x:1.4},0).wait(1).to({regX:6.9,regY:13.2,scaleX:0.43,scaleY:0.44,skewX:0.6,skewY:-2.5,x:-2.5,y:2.2},0).wait(1).to({regY:13.3,scaleX:0.33,scaleY:0.33,skewX:-1.1,skewY:-4.2,x:-4.5,y:1.3},0).wait(1));

	// Layer 9
	this.counter0 = new lib.boardNum();
	this.counter0.setTransform(1.4,3.2,0.618,0.589,0,0,0,6.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.counter0).wait(1).to({x:-3.1},0).wait(1).to({x:-8},0).wait(1).to({scaleX:0.46,scaleY:0.44,x:-10,y:2.1},0).wait(1).to({scaleX:0.35,scaleY:0.33,x:-10.2,y:1.3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.4,-7.2,10.3,12.1);


(lib.boardChip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{red:0,blue:1,white:2,yellow:3,brown:4,purple:5,gold:6,black:7,gray:8,pink:9,green:10});

	// coloredchip
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#991F1F").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape.setTransform(75.5,35,0.994,0.71);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_1.setTransform(19.6,77.2,0.994,0.71);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_2.setTransform(102.1,10.1,0.994,0.71);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_3.setTransform(115.5,15.6,0.994,0.71);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_4.setTransform(115.3,85.7,0.994,0.71);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_5.setTransform(126.8,76.8,0.994,0.71);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_6.setTransform(46.7,90.6,0.994,0.71);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_7.setTransform(32.2,82.8,0.994,0.71);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],6.5,-8.7,-5.9,12.9).beginStroke().moveTo(-8,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.1,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-8,11.7).closePath();
	this.shape_8.setTransform(127.9,23,0.994,0.71);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(2.5,-10.1,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_9.setTransform(135.3,68.6,0.994,0.71);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.7).lineTo(3.8,-18.4).lineTo(3.8,-1.4).curveTo(1.1,9.9,-3.8,18.4).closePath();
	this.shape_10.setTransform(144.2,77.7,0.994,0.71);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#2F7C62").beginStroke().moveTo(-5.3,-4.9).lineTo(5.4,-17.9).lineTo(5.4,2.3).curveTo(0.7,11,-5.3,17.9).closePath();
	this.shape_11.setTransform(135.1,89.2,0.994,0.71);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],1,-14.2,-2.3,-8.5).beginStroke().moveTo(-10.1,7.6).lineTo(-10.1,-17.4).lineTo(10,-9).lineTo(10,17.4).curveTo(-0.5,14.2,-10.1,7.6).closePath();
	this.shape_12.setTransform(45.1,105.8,0.994,0.71);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#2F7C62").beginStroke().moveTo(-7.2,4.8).lineTo(-7.2,-18).lineTo(7.2,-7).lineTo(7.2,18).curveTo(-0.4,12.7,-7.2,4.8).closePath();
	this.shape_13.setTransform(27.9,98.4,0.994,0.71);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFF4F3").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,-0).curveTo(-48,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.5,48,-0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_14.setTransform(75.4,50.8,0.994,0.71);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],4.9,-5.4,-3.6,9.3).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_15.setTransform(15.7,31.8,0.994,0.71);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],-6.1,-9.2,6,11.7).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_16.setTransform(24.3,22.9,0.994,0.71);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_17.setTransform(35.5,14.2,0.994,0.71);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginLinearGradientFill(["#BC3835","#CE5F51"],[0,1],0,71.1,0,-71).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_18.setTransform(75.5,50.6,0.994,0.71);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],-2.1,-9.5,0.4,-11.4).beginStroke().moveTo(-6.1,0.4).lineTo(-5.9,-19.1).lineTo(6.1,-3.7).lineTo(6,19.1).curveTo(-1.3,10.3,-6.1,0.4).closePath();
	this.shape_19.setTransform(14.8,88.3,0.994,0.71);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],3.1,-9.4,0.5,-13.1).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.4).lineTo(9.4,3.5).curveTo(-1,14.9,-9.4,19.4).closePath();
	this.shape_20.setTransform(120.4,99.6,0.994,0.71);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_21.setTransform(75.5,50.6,0.994,0.71);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_22.setTransform(75.5,50.6,0.994,0.71);

	this.instance = new lib.outline_23_7();
	this.instance.setTransform(75.5,60.4,0.994,0.818,0,0,0,79.1,77);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-7.3,1.9).curveTo(-10.8,-0.8,-10.1,-4.3).curveTo(-9.7,-6.3,-8.9,-7.2).curveTo(-7.3,-8.9,-3.1,-9.5).lineTo(9.9,-9.5).curveTo(10.9,0.1,9.2,9.5).curveTo(-4.3,4.2,-7.3,1.9).closePath();
	this.shape_23.setTransform(140.7,52.3,0.993,0.71);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-6.9,-8.1,5.3,13.1).beginStroke().moveTo(4.5,11.5).lineTo(-12.9,5.1).curveTo(-8.1,-4.2,-0.8,-11.7).lineTo(2.7,-7.9).curveTo(6.6,-3.9,8.7,-2.3).curveTo(11.7,-0.2,12.6,2.8).curveTo(13.6,6.3,10.8,9.4).curveTo(8.8,11.7,6,11.7).curveTo(5.3,11.7,4.5,11.5).closePath();
	this.shape_24.setTransform(20.3,25,0.993,0.71);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(2.4,9.4).lineTo(-12.3,5.3).curveTo(-10.4,-2.8,-6.6,-10.1).lineTo(-6.3,-10.2).lineTo(-0.2,-8).curveTo(6.2,-5.6,8,-4.8).curveTo(10.2,-3.7,11.5,-1.8).curveTo(12.8,0.2,11.9,1.4).curveTo(11.1,2.3,11.1,3.6).lineTo(11.3,4.6).curveTo(10.8,7.6,9.5,8.7).curveTo(8.8,9.4,7.3,9.9).curveTo(6.8,10.2,6,10.2).curveTo(4.6,10.2,2.4,9.4).closePath();
	this.shape_25.setTransform(14,35.8,0.993,0.71);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,9.9).curveTo(-9.2,-4,-8,-6.6).curveTo(-6.7,-9.3,-4.9,-10.4).curveTo(-1.9,-12,3.8,-11.3).curveTo(9.3,-10.5,10.9,-7.5).curveTo(11.6,-6,11.3,-4.6).lineTo(11.8,11.1).curveTo(7.9,11.5,4,11.5).curveTo(-4,11.5,-11.8,9.9).closePath();
	this.shape_26.setTransform(71.3,92.8,0.993,0.71);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-10.8,7.8).curveTo(-5.1,-6.4,-3,-10.6).curveTo(-1.6,-13.5,2.4,-13.1).curveTo(5.7,-12.8,8.7,-10.7).curveTo(11.9,-8.4,10.3,-2.4).curveTo(9.5,0.6,8,3.1).lineTo(5.8,13.1).curveTo(-2.7,11.4,-10.8,7.8).closePath();
	this.shape_27.setTransform(53.8,90.6,0.993,0.71);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-8,5.3).curveTo(-11.8,1.8,-12.2,-1.6).curveTo(-12.8,-5.2,-9.8,-9.4).curveTo(-7.2,-13,-3.6,-12.4).curveTo(-1.7,-12.2,-0.4,-11.2).lineTo(12.3,-4.9).curveTo(8,4.5,0.7,12.5).curveTo(-3.1,10,-8,5.3).closePath();
	this.shape_28.setTransform(132.3,74.4,0.993,0.71);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-5.8,6.4).curveTo(-8.9,4.3,-9.6,3.6).curveTo(-10.8,2.2,-12.1,-1.1).curveTo(-13.3,-4.3,-11.4,-8.7).curveTo(-9.7,-12.4,-8.3,-12.9).curveTo(-7.5,-13.2,-4.4,-11.6).lineTo(-1.4,-9.8).lineTo(12.6,-3.7).curveTo(11,5,7.3,12.9).curveTo(-2.2,8.9,-5.8,6.4).closePath();
	this.shape_29.setTransform(137.3,61.7,0.993,0.71);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-5.4,10.2).lineTo(-11.5,9.9).curveTo(-12.2,-0.5,-9.8,-10.2).lineTo(-3.9,-8.5).curveTo(2.5,-6.6,5.2,-6).curveTo(9.5,-5.1,11.2,-1.5).curveTo(11.5,-0.8,11.6,1.6).curveTo(11.7,4.5,11,6.2).curveTo(10.2,8.1,8.6,8.9).curveTo(7.3,9.5,3.9,10).curveTo(2,10.2,-1.8,10.2).lineTo(-5.4,10.2).closePath();
	this.shape_30.setTransform(11.5,46.8,0.993,0.71);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-12,2.5).lineTo(-8.6,-2.5).curveTo(-4.6,-7.9,-2.2,-10).curveTo(0.7,-12.4,2.7,-12.2).curveTo(4.4,-12,10,-9.1).curveTo(12.6,-7.7,11.9,-5.2).curveTo(11.6,-4,10.7,-3).lineTo(4.3,12.2).curveTo(-4.6,8.3,-12,2.5).closePath();
	this.shape_31.setTransform(38.9,87.5,0.993,0.71);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-6.9,-10.4,4.2,8.9).beginStroke().moveTo(-10.1,7.8).curveTo(-11.6,6.5,-10.4,2.4).lineTo(-4.4,-11.9).curveTo(3.8,-8.4,11,-3.2).curveTo(6.3,4.5,5.4,5.8).curveTo(1.3,11.5,-1.7,11.9).lineTo(-2.4,11.9).curveTo(-5.4,11.9,-10.1,7.8).closePath();
	this.shape_32.setTransform(110.9,13.1,0.993,0.71);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],-10.4,-5.4,7.1,4.7).beginStroke().moveTo(-4.4,11).curveTo(-6.4,10.4,-7.9,9.7).lineTo(-8.9,9).curveTo(-11.2,7.6,-11.2,4.3).lineTo(-10.8,1.2).lineTo(-6.8,-11.8).curveTo(2.5,-10.2,11.2,-6.6).lineTo(9.1,-1.8).curveTo(6.9,3.1,6.6,4).curveTo(5.7,7.3,4.1,9.7).curveTo(2.9,11.6,0.4,11.7).lineTo(0.3,11.8).curveTo(-1.4,11.8,-4.4,11).closePath();
	this.shape_33.setTransform(95.5,9.2,0.993,0.71);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-5.8,-12.1,5.4,7.3).beginStroke().moveTo(-3,10).curveTo(-5.3,9.9,-7.8,7.9).curveTo(-9.9,6.1,-10.1,5).curveTo(-10.4,3.7,-10.1,-9.7).curveTo(0,-10.6,10.3,-8.9).curveTo(7.1,2.1,6.4,3.8).lineTo(5.4,6.2).curveTo(4.8,7.4,3.9,8).curveTo(1.2,10,-2.4,10).lineTo(-3,10).closePath();
	this.shape_34.setTransform(78.5,7.2,0.993,0.71);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],0.9,-7.3,-0.4,-14.8).beginStroke().moveTo(-11.8,12.2).lineTo(-11.8,-14.2).lineTo(11.8,-13).lineTo(11.8,13.7).curveTo(11.2,13.9,4.3,14.2).lineTo(2.9,14.2).curveTo(-3.5,14.2,-11.8,12.2).closePath();
	this.shape_35.setTransform(71.3,110,0.993,0.71);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.beginLinearGradientFill(["#1C598C","#2462A0"],[0,1],0.6,-8.1,-0.8,-13.4).beginStroke().moveTo(-8.3,9.6).lineTo(-8.3,-15.8).lineTo(8.3,-10.5).lineTo(8.3,15.8).curveTo(1.9,14.7,-8.3,9.6).closePath();
	this.shape_36.setTransform(51.4,107.4,0.993,0.71);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.beginFill("#0E4366").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_37.setTransform(75.5,34.9,0.993,0.71);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.beginFill("#F8FDFF").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_38.setTransform(75.5,50.6,0.993,0.71);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.beginLinearGradientFill(["#3E75C6","#3067AA"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60.1,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_39.setTransform(75.5,50.5,0.993,0.71);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],0.5,-8.6,-1.8,-12.6).beginStroke().moveTo(-8.2,6).lineTo(-8.2,-17.6).lineTo(8.1,-7.8).lineTo(8.1,17.6).curveTo(1.3,14.6,-8.2,6).closePath();
	this.shape_40.setTransform(35,101.7,0.993,0.71);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.beginLinearGradientFill(["#8E7573","#705453"],[0,1],3.5,-12.7,-1.1,-8.1).beginStroke().moveTo(-5.8,-2.2).lineTo(5.8,-19.7).lineTo(5.8,-0.9).curveTo(0.8,11.4,-5.8,19.7).closePath();
	this.shape_41.setTransform(138.7,84.9,0.993,0.71);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.beginFill("#063D5B").beginStroke().moveTo(-2.7,-1.1).lineTo(2.7,-17.7).lineTo(2.7,-1.9).curveTo(0.6,9,-2.7,17.7).closePath();
	this.shape_42.setTransform(147.2,71.7,0.993,0.71);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.beginFill("#5B4342").beginStroke().moveTo(-0.6,-3.1).lineTo(0.5,-12.6).curveTo(1,4.8,-0.6,12.7).closePath();
	this.shape_43.setTransform(150.4,61.3,0.993,0.71);

	this.instance_1 = new lib.outline_23_9();
	this.instance_1.setTransform(75.5,60.1,0.993,0.817,0,0,0,79.1,76.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.4,-8.9,9,-7.3).curveTo(9.8,-6.4,10.2,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(4.3,4.2,-9.1,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_44.setTransform(10.3,52.7,0.992,0.712);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-6.6,-3.9,-2.7,-7.9).lineTo(0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_45.setTransform(130.7,25.3,0.992,0.712);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-6.2,-5.6,0.2,-8).lineTo(6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_46.setTransform(137,36.1,0.992,0.712);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.7).curveTo(-11.6,-6,-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.7).curveTo(9.2,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_47.setTransform(79.7,93.3,0.992,0.712);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-8,3.1).curveTo(-9.4,0.6,-10.3,-2.4).curveTo(-11.9,-8.3,-8.7,-10.6).curveTo(-5.7,-12.7,-2.4,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_48.setTransform(97.2,91,0.992,0.712);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.4).curveTo(3.1,10,-0.7,12.5).curveTo(-7.9,4.5,-12.3,-4.9).closePath();
	this.shape_49.setTransform(18.8,74.8,0.992,0.712);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.2,5.8,6.5).curveTo(2.2,8.9,-7.3,13).curveTo(-11.1,4.9,-12.6,-3.6).closePath();
	this.shape_50.setTransform(13.8,62.1,0.992,0.712);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.8,-10.2).curveTo(12.2,-0.4,11.5,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.7,10.2,-3.9,10).closePath();
	this.shape_51.setTransform(139.5,47.1,0.992,0.712);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.4,-12,-2.7,-12.2).curveTo(-0.7,-12.4,2.2,-10).curveTo(6.1,-6.7,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_52.setTransform(112.2,87.9,0.992,0.712);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.9,-8.4,4.4,-12).lineTo(10.4,2.3).curveTo(11.6,6.4,10.1,7.7).curveTo(7.9,9.7,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_53.setTransform(40.1,13.4,0.992,0.712);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],-4.2,-10.5,7.6,9.9).beginStroke().moveTo(-0.4,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.6,4).curveTo(-6.9,3.1,-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.5,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.2,7.6,8.9,9).curveTo(7.6,10.1,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.4,11.7).closePath();
	this.shape_54.setTransform(55.6,9.5,0.992,0.712);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.8,7.5,-5.4,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.2,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_55.setTransform(72.5,7.4,0.992,0.712);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-0.9,-14.7,0.4,-7.3).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-12.9).lineTo(11.8,-14.1).lineTo(11.8,12.4).curveTo(5.7,13.8,-0.3,14).lineTo(-4.1,14.1).curveTo(-8.1,14.1,-11.8,13.8).closePath();
	this.shape_56.setTransform(79.7,108.9,0.992,0.712);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.beginLinearGradientFill(["#C9803F","#E09F5F"],[0,1],-0.5,-13.5,0.9,-8.2).beginStroke().moveTo(-8.3,-10.6).lineTo(8.3,-15.9).lineTo(8.2,9.7).curveTo(0.1,13.9,-8.3,15.9).closePath();
	this.shape_57.setTransform(99.7,106.5,0.992,0.712);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.beginFill("#3C3C3F").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_58.setTransform(75.6,35.3,0.992,0.712);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.beginFill("#F2F2F2").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_59.setTransform(75.6,50.9,0.992,0.712);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.beginLinearGradientFill(["#F9F9F9","#D4D4D4"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_60.setTransform(75.6,50.9,0.992,0.712);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6).curveTo(-0.8,14.1,-8.2,17.7).closePath();
	this.shape_61.setTransform(116,100.8,0.992,0.712);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-3.5,-8.2,1.1,-12.8).beginStroke().moveTo(-5.8,-0.7).lineTo(-5.8,-19.7).lineTo(5.8,-2.3).lineTo(5.7,19.7).curveTo(-0.8,11.2,-5.8,-0.7).closePath();
	this.shape_62.setTransform(12.4,83.9,0.992,0.712);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.beginFill("#C9803F").beginStroke().moveTo(-2.7,-1.5).lineTo(-2.7,-17.8).lineTo(2.7,-1.2).lineTo(2.7,17.8).curveTo(-0.7,9,-2.7,-1.5).closePath();
	this.shape_63.setTransform(3.9,70.7,0.992,0.712);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.6).lineTo(0.6,-2.9).lineTo(0.6,12.6).curveTo(-1.2,0.8,-0.5,-12.6).closePath();
	this.shape_64.setTransform(0.6,60.1,0.992,0.712);

	this.instance_2 = new lib.outline();
	this.instance_2.setTransform(75.7,61.3,0.992,0.817,0,0,0,79.2,78.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-7.3,1.9).curveTo(-10.8,-0.8,-10.2,-4.3).curveTo(-9.8,-6.4,-9,-7.3).curveTo(-7.4,-8.9,-3.1,-9.5).lineTo(9.9,-9.5).curveTo(10.9,0.1,9.1,9.5).curveTo(-4.3,4.2,-7.3,1.9).closePath();
	this.shape_65.setTransform(140.6,52.4,0.992,0.71);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-6.9,-8.1,5.3,13.1).beginStroke().moveTo(4.5,11.5).lineTo(-12.9,5.1).curveTo(-8.1,-4.2,-0.8,-11.7).lineTo(2.7,-7.9).curveTo(6.6,-3.9,8.7,-2.4).curveTo(11.7,-0.2,12.6,2.8).curveTo(13.6,6.3,10.8,9.4).curveTo(8.8,11.7,6.1,11.7).curveTo(5.3,11.7,4.5,11.5).closePath();
	this.shape_66.setTransform(20.2,25.1,0.992,0.71);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,10.2,0,-10.2).beginStroke().moveTo(2.4,9.4).lineTo(-12.3,5.2).curveTo(-10.4,-2.8,-6.6,-10.1).lineTo(-6.3,-10.2).lineTo(-0.2,-8).curveTo(6.2,-5.6,8,-4.8).curveTo(10.2,-3.7,11.5,-1.8).curveTo(12.8,0.2,11.9,1.4).curveTo(11.1,2.3,11.1,3.6).lineTo(11.3,4.6).curveTo(10.8,7.6,9.5,8.7).curveTo(8.8,9.4,7.3,9.9).curveTo(6.8,10.2,6,10.2).curveTo(4.6,10.2,2.4,9.4).closePath();
	this.shape_67.setTransform(14,35.8,0.992,0.71);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,9.9).curveTo(-9.3,-4.1,-8,-6.7).curveTo(-6.7,-9.3,-4.8,-10.4).curveTo(-1.9,-12,3.8,-11.3).curveTo(9.2,-10.6,10.8,-7.5).curveTo(11.7,-6,11.4,-4.7).lineTo(11.8,11.1).curveTo(8,11.5,4.3,11.5).curveTo(-3.8,11.5,-11.8,9.9).closePath();
	this.shape_68.setTransform(71.3,92.9,0.992,0.71);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-10.8,7.8).curveTo(-5.1,-6.3,-3,-10.6).curveTo(-1.6,-13.4,2.4,-13.1).curveTo(5.7,-12.7,8.7,-10.6).curveTo(11.9,-8.3,10.3,-2.4).curveTo(9.5,0.6,8,3.1).lineTo(5.8,13.1).curveTo(-2.9,11.3,-10.8,7.8).closePath();
	this.shape_69.setTransform(53.8,90.6,0.992,0.71);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-8,5.4).curveTo(-11.8,1.8,-12.2,-1.6).curveTo(-12.8,-5.1,-9.8,-9.4).curveTo(-7.2,-13,-3.6,-12.4).curveTo(-1.7,-12.2,-0.4,-11.2).lineTo(12.3,-4.9).curveTo(7.9,4.6,0.7,12.5).curveTo(-3.1,10,-8,5.4).closePath();
	this.shape_70.setTransform(132.2,74.4,0.992,0.71);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],-9.9,-11.4,10.9,9.4).beginStroke().moveTo(-5.8,6.5).curveTo(-9,4.3,-9.6,3.6).curveTo(-10.9,2.3,-12.1,-1.1).curveTo(-13.3,-4.3,-11.4,-8.6).curveTo(-9.7,-12.4,-8.3,-12.9).curveTo(-7.5,-13.2,-4.4,-11.5).lineTo(-1.4,-9.8).lineTo(12.6,-3.6).curveTo(11.1,4.9,7.3,13).curveTo(-2.2,8.9,-5.8,6.5).closePath();
	this.shape_71.setTransform(137.2,61.7,0.992,0.71);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-5.4,10.2).lineTo(-11.4,10).curveTo(-12.1,-0.3,-9.8,-10.2).lineTo(-3.9,-8.5).curveTo(2.5,-6.6,5.2,-6).curveTo(9.4,-5.2,11.2,-1.5).curveTo(11.5,-0.7,11.6,1.6).curveTo(11.7,4.5,11,6.3).curveTo(10.2,8.2,8.6,8.9).curveTo(7.3,9.5,3.9,10).curveTo(1.9,10.2,-2.1,10.2).lineTo(-5.4,10.2).closePath();
	this.shape_72.setTransform(11.5,46.8,0.992,0.71);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-12,2.4).lineTo(-8.6,-2.5).curveTo(-4.6,-7.9,-2.2,-10).curveTo(0.7,-12.4,2.7,-12.2).curveTo(4.4,-12,10,-9.1).curveTo(12.6,-7.7,11.9,-5.3).curveTo(11.6,-4,10.7,-3.1).lineTo(4.3,12.2).curveTo(-4.7,8.2,-12,2.4).closePath();
	this.shape_73.setTransform(38.8,87.5,0.992,0.71);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-6.9,-10.5,4.2,8.8).beginStroke().moveTo(-5.9,10.8).curveTo(-7.9,9.7,-10.1,7.7).curveTo(-11.6,6.4,-10.4,2.3).lineTo(-4.4,-12).curveTo(3.8,-8.5,11,-3.3).lineTo(5.4,5.7).curveTo(3.8,8,2.1,9.6).curveTo(-0.1,11.6,-1.7,11.9).lineTo(-2.3,12).curveTo(-3.8,12,-5.9,10.8).closePath();
	this.shape_74.setTransform(110.8,13.1,0.992,0.71);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,-11.7,0,11.7).beginStroke().moveTo(-4.4,11).curveTo(-6.4,10.5,-7.9,9.7).lineTo(-8.9,9).curveTo(-11.1,7.6,-11.2,4.3).lineTo(-10.8,1.2).lineTo(-6.8,-11.7).curveTo(2.6,-10.2,11.2,-6.5).lineTo(9.1,-1.8).curveTo(6.9,3.2,6.6,4).curveTo(5.7,7.4,4.2,9.7).curveTo(2.9,11.6,0.5,11.7).lineTo(0.1,11.7).curveTo(-1.6,11.7,-4.4,11).closePath();
	this.shape_75.setTransform(95.4,9.3,0.992,0.71);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-5.8,-12.1,5.4,7.3).beginStroke().moveTo(-3,9.9).curveTo(-5.3,9.8,-7.8,7.8).curveTo(-9.9,6.1,-10.1,4.9).curveTo(-10.4,3.7,-10.1,-9.7).curveTo(0.3,-10.6,10.3,-8.9).lineTo(8.6,-3.2).curveTo(6.8,2.7,6.4,3.8).lineTo(5.4,6.2).curveTo(4.8,7.4,3.9,8).curveTo(1.2,10,-2.2,10).lineTo(-3,9.9).closePath();
	this.shape_76.setTransform(78.4,7.2,0.992,0.71);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],0.9,-7.3,-0.4,-14.7).beginStroke().moveTo(-2.2,13.8).curveTo(-8.1,13.2,-11.8,12.4).lineTo(-11.8,-14.1).lineTo(11.8,-12.9).lineTo(11.8,13.9).curveTo(7.9,14.1,4.5,14.1).curveTo(0.9,14.1,-2.2,13.8).closePath();
	this.shape_77.setTransform(71.3,110,0.992,0.71);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.beginLinearGradientFill(["#DD879F","#FBC8D5"],[0,1],0.6,-8.2,-0.8,-13.5).beginStroke().moveTo(-8.3,9.5).lineTo(-8.3,-15.9).lineTo(8.3,-10.7).lineTo(8.3,15.9).curveTo(-0.7,13.7,-8.3,9.5).closePath();
	this.shape_78.setTransform(51.3,107.6,0.992,0.71);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.beginFill("#897828").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_79.setTransform(75.4,34.9,0.992,0.71);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.beginFill("#FFFDEB").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_80.setTransform(75.4,50.6,0.992,0.71);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.beginLinearGradientFill(["#F7E943","#E5D53E"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_81.setTransform(75.4,50.6,0.992,0.71);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],0.5,-8.6,-1.8,-12.6).beginStroke().moveTo(-8.2,5.9).lineTo(-8.2,-17.6).lineTo(8.1,-7.8).lineTo(8.1,17.6).curveTo(-1.3,12.4,-8.2,5.9).closePath();
	this.shape_82.setTransform(35,101.8,0.992,0.71);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],3.5,-12.9,-1.1,-8.3).beginStroke().moveTo(-5.8,-2.4).lineTo(5.8,-19.8).lineTo(5.8,-0.6).curveTo(1.6,9.2,-5.8,19.8).closePath();
	this.shape_83.setTransform(138.6,85.1,0.992,0.71);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.beginFill("#DD879F").beginStroke().moveTo(-2.7,-1.4).lineTo(2.7,-18).lineTo(2.7,-1.8).curveTo(0.6,8.7,-2.7,18).closePath();
	this.shape_84.setTransform(147.1,72,0.992,0.71);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.beginFill("#5B4342").beginStroke().moveTo(-0.6,-2.9).lineTo(0.5,-12.6).curveTo(1.1,0.9,-0.6,12.6).closePath();
	this.shape_85.setTransform(150.4,61.3,0.992,0.71);

	this.instance_3 = new lib.outline_23_3();
	this.instance_3.setTransform(75.4,59.9,0.992,0.816,0,0,0,79.1,76.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.beginFill("#000000").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_86.setTransform(75.5,34.8,0.993,0.711);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_87.setTransform(19.7,77,0.993,0.711);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7.7,-12.3,4.3,8.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_88.setTransform(102.2,9.9,0.993,0.711);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_89.setTransform(115.5,15.4,0.993,0.711);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_90.setTransform(115.3,85.6,0.993,0.711);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_91.setTransform(126.8,76.7,0.993,0.711);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_92.setTransform(46.8,90.5,0.993,0.711);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_93.setTransform(32.3,82.6,0.993,0.711);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7.5,-8.8,3.1,9.5).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.8,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4.1,9.3,0.2,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_94.setTransform(128,22.8,0.993,0.711);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_95.setTransform(135.4,68.4,0.993,0.711);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-0.7,-10.6,2.3,-8.9).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.5).lineTo(3.8,-1.1).curveTo(1.2,8.4,-3.8,18.5).closePath();
	this.shape_96.setTransform(144.3,77.6,0.993,0.711);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.beginFill("#C1AE3E").beginStroke().moveTo(-5.4,-4.9).lineTo(5.3,-18).lineTo(5.4,2.1).curveTo(0.6,11,-5.4,17.9).closePath();
	this.shape_97.setTransform(135.2,89.1,0.993,0.711);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-2.3,-8.4,1,-14.1).beginStroke().moveTo(-10,7.4).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(-1.9,13.7,-10,7.4).closePath();
	this.shape_98.setTransform(45.1,105.6,0.993,0.711);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.beginFill("#C1AE3E").beginStroke().moveTo(-7.1,4.9).lineTo(-7.2,-17.9).lineTo(7.2,-6.9).lineTo(7.2,17.9).curveTo(-0.6,12.4,-7.1,4.9).closePath();
	this.shape_99.setTransform(28,98.1,0.993,0.711);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.beginFill("#EAEAEA").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_100.setTransform(75.5,50.5,0.993,0.711);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7,-9.3,5.2,11.8).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_101.setTransform(15.7,31.6,0.993,0.711);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],-3.4,-11.3,2.9,12.5).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_102.setTransform(24.3,22.7,0.993,0.711);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-4.3,-6.5,5.9,11.2).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_103.setTransform(35.6,14,0.993,0.711);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_104.setTransform(75.5,50.5,0.993,0.711);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-2.2,-9.4,0.3,-11.3).beginStroke().moveTo(-5.9,0.9).lineTo(-6,-19).lineTo(6,-3.7).lineTo(6,19).curveTo(-0.8,11.2,-5.9,0.9).closePath();
	this.shape_105.setTransform(14.9,88,0.993,0.711);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],3.1,-9.3,0.5,-13).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.3).lineTo(9.4,3.4).curveTo(2.2,12.2,-9.4,19.3).closePath();
	this.shape_106.setTransform(120.5,99.3,0.993,0.711);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_107.setTransform(75.5,50.5,0.993,0.711);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_108.setTransform(75.5,50.5,0.993,0.711);

	this.instance_4 = new lib.outline_23_1();
	this.instance_4.setTransform(75.6,60.1,0.993,0.818,0,0,0,79.2,76.7);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.beginFill("#3B1C63").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-48,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,-0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_109.setTransform(75.5,34.9,0.993,0.711);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_110.setTransform(19.7,77.1,0.993,0.711);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(2.8,7.3).curveTo(2.3,8.8,0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_111.setTransform(102.2,10,0.993,0.711);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.beginFill("#4C9377").beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_112.setTransform(115.5,15.4,0.993,0.711);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_113.setTransform(115.3,85.6,0.993,0.711);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.beginFill("#4C9377").beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_114.setTransform(126.8,76.7,0.993,0.711);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_115.setTransform(46.8,90.5,0.993,0.711);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.beginFill("#4C9377").beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_116.setTransform(32.2,82.7,0.993,0.711);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-9.6,-3.6,10.2,7.8).beginStroke().moveTo(-7.9,11.7).curveTo(-9.6,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.8,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-7.5,-4.5,-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.2,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_117.setTransform(127.9,22.9,0.993,0.711);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_118.setTransform(135.3,68.5,0.993,0.711);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.4).lineTo(3.8,-1.2).curveTo(1,9.2,-3.8,18.4).closePath();
	this.shape_119.setTransform(144.2,77.5,0.993,0.711);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],-0.2,-12.3,2.9,-9.1).beginStroke().moveTo(-5.4,-4.9).lineTo(5.3,-18).lineTo(5.3,2.3).curveTo(2.3,8.7,-5.4,17.9).closePath();
	this.shape_120.setTransform(135.1,89.1,0.993,0.711);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10.1,7.4).lineTo(-10.1,-17.3).lineTo(10.1,-8.9).lineTo(9.9,17.3).curveTo(0.8,14.9,-10.1,7.4).closePath();
	this.shape_121.setTransform(45.2,105.6,0.993,0.711);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],0.3,-13.5,-2.7,-8.3).beginStroke().moveTo(-2.1,10.2).curveTo(-4.7,7.6,-7.2,4.8).lineTo(-7.2,-17.9).lineTo(7.2,-6.9).lineTo(7.2,17.9).curveTo(2.3,14.4,-2.1,10.2).closePath();
	this.shape_122.setTransform(28.1,98.2,0.993,0.711);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.beginFill("#F9F3FF").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_123.setTransform(75.5,50.5,0.993,0.711);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-8.9,-3.5,10.2,7.5).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_124.setTransform(15.7,31.7,0.993,0.711);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.beginFill("#4C9377").beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_125.setTransform(24.3,22.7,0.993,0.711);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_126.setTransform(35.6,14,0.993,0.711);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.beginLinearGradientFill(["#AA6AE2","#7745A3"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_127.setTransform(75.5,50.5,0.993,0.711);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],-2.2,-9.5,0.3,-11.4).beginStroke().moveTo(-6,0.7).lineTo(-6,-19.1).lineTo(6,-3.7).lineTo(6,19.1).curveTo(-0,12,-6,0.7).closePath();
	this.shape_128.setTransform(15,88.1,0.993,0.711);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],3.1,-9.4,0.5,-13.1).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.4).lineTo(9.4,3.4).curveTo(-1,14.7,-9.5,19.4).closePath();
	this.shape_129.setTransform(120.4,99.4,0.993,0.711);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_130.setTransform(75.5,50.5,0.993,0.711);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_131.setTransform(75.5,50.5,0.993,0.711);

	this.instance_5 = new lib.outline_23_6();
	this.instance_5.setTransform(75.6,60.1,0.993,0.818,0,0,0,79.2,76.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.3,-8.9,8.9,-7.3).curveTo(9.7,-6.4,10.2,-4.3).curveTo(10.8,-0.9,7.3,1.9).curveTo(5.4,3.3,-2,6.6).lineTo(-9.1,9.5).curveTo(-10.9,-0.2,-9.9,-9.5).closePath();
	this.shape_132.setTransform(10.4,52.5,0.991,0.711);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-5.3,-4.8,0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_133.setTransform(130.7,25,0.991,0.711);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(-7.3,9.9).curveTo(-8.7,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.2,-3.7,-8,-4.8).curveTo(-5.1,-6.2,6.4,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.7,12.3,5.2).lineTo(-2.3,9.4).curveTo(-4.6,10.2,-5.9,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_134.setTransform(136.9,35.8,0.991,0.711);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.3,-4.7).lineTo(-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.6,-9.3,8,-6.7).curveTo(9.3,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_135.setTransform(79.7,92.9,0.991,0.711);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-7.9,3.1).curveTo(-9.4,0.6,-10.2,-2.4).curveTo(-11.9,-8.3,-8.6,-10.6).curveTo(-5.7,-12.7,-2.3,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_136.setTransform(97.1,90.6,0.991,0.711);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.3,-13,9.8,-9.4).curveTo(12.8,-5.2,12.3,-1.6).curveTo(11.8,1.8,8,5.4).curveTo(3.1,10,-0.6,12.5).curveTo(-7.8,4.7,-12.3,-4.9).closePath();
	this.shape_137.setTransform(18.8,74.4,0.991,0.711);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.6,-13.2,8.4,-12.9).curveTo(9.8,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.7,3.6).curveTo(9,4.3,5.8,6.5).curveTo(3.6,8,-2.1,10.6).lineTo(-7.3,13).curveTo(-11,5.1,-12.6,-3.6).closePath();
	this.shape_138.setTransform(13.8,61.7,0.991,0.711);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.4,9.5,-8.7,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.7,-10.2).curveTo(12.2,-0.1,11.4,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.8,10.2,-3.9,10).closePath();
	this.shape_139.setTransform(139.4,46.7,0.991,0.711);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-9.9,-9.1).curveTo(-4.3,-12,-2.6,-12.2).curveTo(-0.6,-12.4,2.2,-10).curveTo(4.7,-7.9,8.6,-2.5).curveTo(10.6,0.2,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_140.setTransform(112.1,87.5,0.991,0.711);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.7,-8.5,4.4,-12).lineTo(10.5,2.3).curveTo(11.7,6.4,10.1,7.7).curveTo(8,9.6,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_141.setTransform(40.1,13,0.991,0.711);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],-4.2,-10.5,7.6,9.9).beginStroke().moveTo(-0.5,11.7).curveTo(-2.9,11.6,-4.1,9.7).curveTo(-5.6,7.4,-6.7,4).lineTo(-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.6,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.1,7.6,8.8,9).curveTo(7.6,10.1,4.3,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.5,11.7).closePath();
	this.shape_142.setTransform(55.6,9.2,0.991,0.711);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.7,7.5,-5.3,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.9,6.2,7.8,7.9).curveTo(5.4,9.9,3.1,10).lineTo(2.3,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_143.setTransform(72.5,7.1,0.991,0.711);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.1,-14.1,-0.1,-7.8).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-13).lineTo(11.8,-14.2).lineTo(11.7,12.4).curveTo(7.7,13.4,1.1,14).curveTo(-1.5,14.2,-4.2,14.2).curveTo(-8,14.2,-11.8,13.8).closePath();
	this.shape_144.setTransform(79.7,110,0.991,0.711);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.beginLinearGradientFill(["#543E3B","#705550"],[0,1],-0.5,-13.5,0.9,-8.2).beginStroke().moveTo(-8.3,-10.7).lineTo(8.3,-15.9).lineTo(8.3,9.6).curveTo(0.1,13.8,-8.3,15.9).closePath();
	this.shape_145.setTransform(99.6,107.4,0.991,0.711);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.beginFill("#894D24").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_146.setTransform(75.6,34.9,0.991,0.711);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.beginFill("#FFF8F3").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_147.setTransform(75.6,50.5,0.991,0.711);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.beginFill().beginStroke("#F89C1C").setStrokeStyle(0.2,0,0,4).moveTo(-76,-0).curveTo(-76,14.4,-70,27.6).curveTo(-64.3,40.4,-53.7,50.2).curveTo(-43.2,60,-29.6,65.4).curveTo(-15.4,71,0,71).curveTo(15.5,71,29.6,65.4).curveTo(43.2,60,53.8,50.2).curveTo(64.3,40.4,70,27.6).curveTo(76,14.4,76,-0).curveTo(76,-14.5,70,-27.7).curveTo(64.3,-40.4,53.8,-50.2).curveTo(43.2,-60.1,29.6,-65.4).curveTo(15.5,-71,0,-71).curveTo(-15.4,-71,-29.6,-65.4).curveTo(-43.2,-60.1,-53.7,-50.2).curveTo(-64.3,-40.4,-70,-27.7).curveTo(-76,-14.5,-76,-0).closePath();
	this.shape_148.setTransform(75.6,50.5,0.991,0.711);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.beginLinearGradientFill(["#F89C1C","#E5891C"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_149.setTransform(75.6,50.5,0.991,0.711);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.4,-12.7,1.9,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6).curveTo(0.4,13.5,-8.2,17.7).closePath();
	this.shape_150.setTransform(115.9,101.7,0.991,0.711);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],5.9,-10.5,-7.2,-10.5).beginStroke().moveTo(-5.9,-1.2).lineTo(-5.9,-19.7).lineTo(5.8,-2.3).lineTo(5.7,19.7).curveTo(-4.7,4.2,-5.9,-1.2).closePath();
	this.shape_151.setTransform(12.4,84.8,0.991,0.711);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.beginFill("#16281A").beginStroke().moveTo(-2.7,-1.1).lineTo(-2.7,-17.6).lineTo(2.6,-1.1).lineTo(2.6,17.6).curveTo(-0.1,12.4,-2.7,-1.1).closePath();
	this.shape_152.setTransform(4,71.6,0.991,0.711);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.8).lineTo(0.7,-3.1).lineTo(0.7,12.8).curveTo(-1.2,0.9,-0.5,-12.8).closePath();
	this.shape_153.setTransform(0.7,61.2,0.991,0.711);

	this.instance_6 = new lib.outline_23_2();
	this.instance_6.setTransform(75.6,60,0.991,0.817,0,0,0,79.1,76.5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.beginFill("#000000").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_154.setTransform(75.5,35.4,0.993,0.711);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_155.setTransform(19.7,77.6,0.993,0.711);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7.7,-12.3,4.3,8.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_156.setTransform(102.2,10.5,0.993,0.711);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_157.setTransform(115.5,15.9,0.993,0.711);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_158.setTransform(115.4,86.1,0.993,0.711);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_159.setTransform(126.8,77.2,0.993,0.711);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_160.setTransform(46.8,91,0.993,0.711);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_161.setTransform(32.3,83.2,0.993,0.711);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7.5,-8.8,3.1,9.5).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.1,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_162.setTransform(128,23.4,0.993,0.711);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_163.setTransform(135.4,69,0.993,0.711);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.4).lineTo(3.8,-1.4).curveTo(0.9,9.6,-3.8,18.4).closePath();
	this.shape_164.setTransform(144.3,78.2,0.993,0.711);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.beginLinearGradientFill(["#508C74","#61A28A"],[0,1],-0.2,-12.2,2.9,-9).beginStroke().moveTo(-5.3,-4.8).lineTo(5.3,-17.9).lineTo(5.3,2.2).curveTo(0.8,11,-5.3,17.9).closePath();
	this.shape_165.setTransform(135.2,89.7,0.993,0.711);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10,7.5).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(2.1,15.6,-10,7.5).closePath();
	this.shape_166.setTransform(45.1,106.2,0.993,0.711);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.beginLinearGradientFill(["#508C74","#61A28A"],[0,1],0.4,-13.5,-2.6,-8.2).beginStroke().moveTo(-7.2,4.6).lineTo(-7.1,-17.9).lineTo(7.3,-6.9).lineTo(7.3,17.9).curveTo(0.1,13,-7.2,4.6).closePath();
	this.shape_167.setTransform(28,98.8,0.993,0.711);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_168.setTransform(75.5,51,0.993,0.711);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7,-9.3,5.2,11.8).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_169.setTransform(15.7,32.1,0.993,0.711);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],-6.1,-9.2,6,11.7).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_170.setTransform(24.3,23.2,0.993,0.711);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-4.3,-6.5,5.9,11.2).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_171.setTransform(35.6,14.5,0.993,0.711);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.beginFill("#000000").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_172.setTransform(75.5,51,0.993,0.711);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-2.1,-9.5,0.4,-11.4).beginStroke().moveTo(-6.1,0.3).lineTo(-5.9,-19.1).lineTo(6.1,-3.7).lineTo(6.1,19.1).curveTo(-2.7,8.3,-6.1,0.3).closePath();
	this.shape_173.setTransform(14.9,88.7,0.993,0.711);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],3.1,-9.3,0.5,-12.9).beginStroke().moveTo(-9.4,-5.9).lineTo(9.4,-19.3).lineTo(9.4,3.5).curveTo(0.7,13.5,-9.4,19.3).closePath();
	this.shape_174.setTransform(120.5,99.9,0.993,0.711);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_175.setTransform(75.5,51,0.993,0.711);

	this.instance_7 = new lib.outline_23_0();
	this.instance_7.setTransform(75.6,60.5,0.993,0.817,0,0,0,79.2,77.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.3,-8.9,8.9,-7.2).curveTo(9.7,-6.3,10.1,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(4.2,4.2,-9.2,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_176.setTransform(10.2,52.2,0.993,0.71);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.3).curveTo(-6.6,-3.9,-2.7,-7.9).lineTo(0.8,-11.7).curveTo(8.2,-4,12.9,5.1).lineTo(-1.2,10.2).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_177.setTransform(130.7,24.9,0.993,0.71);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.beginFill("#7575A3").beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-6.2,-5.6,0.2,-8).lineTo(6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_178.setTransform(137,35.7,0.993,0.71);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.6).curveTo(-11.6,-6,-10.8,-7.5).curveTo(-9.2,-10.5,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.6).curveTo(9.2,-4,11.8,9.9).curveTo(3.8,11.5,-4.2,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_179.setTransform(79.6,92.7,0.993,0.71);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.beginFill("#7575A3").beginStroke().moveTo(-8,3).curveTo(-9.4,0.5,-10.3,-2.4).curveTo(-11.9,-8.4,-8.7,-10.7).curveTo(-5.7,-12.8,-2.4,-13.1).curveTo(1.6,-13.5,3,-10.6).curveTo(5.1,-6.4,10.8,7.8).curveTo(2.7,11.4,-5.8,13.1).closePath();
	this.shape_180.setTransform(97.1,90.5,0.993,0.71);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.3).curveTo(3.1,10,-0.7,12.5).curveTo(-8,4.5,-12.3,-4.9).closePath();
	this.shape_181.setTransform(18.7,74.3,0.993,0.71);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.beginFill("#7575A3").beginStroke().moveTo(-12.6,-3.7).lineTo(1.4,-9.8).lineTo(4.4,-11.6).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.7).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.3,5.8,6.4).curveTo(2.2,8.9,-7.3,12.9).curveTo(-11,5,-12.6,-3.7).closePath();
	this.shape_182.setTransform(13.6,61.6,0.993,0.71);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.1,-11,6.2).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.8,-11.2,-1.5).curveTo(-9.5,-5.1,-5.2,-6).curveTo(-0.9,-7,9.8,-10.3).curveTo(12.2,-0.4,11.5,9.9).curveTo(5.7,10.3,1.8,10.3).curveTo(-1.8,10.3,-3.9,10).closePath();
	this.shape_183.setTransform(139.5,46.7,0.993,0.71);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3).curveTo(-11.5,-4,-11.9,-5.2).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.3,-12,-2.7,-12.2).curveTo(-0.6,-12.4,2.2,-10).curveTo(6.1,-6.6,12,2.5).curveTo(4.4,8.4,-4.3,12.2).closePath();
	this.shape_184.setTransform(112.1,87.4,0.993,0.71);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-3.5,-8,7,10.2).beginStroke().moveTo(1.7,11.9).curveTo(-1.3,11.5,-5.4,5.8).lineTo(-11,-3.2).curveTo(-4,-8.3,4.4,-11.9).lineTo(10.4,2.4).curveTo(11.6,6.5,10.1,7.8).curveTo(5.4,11.9,2.4,11.9).lineTo(1.7,11.9).closePath();
	this.shape_185.setTransform(40,13,0.993,0.71);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.beginFill("#7575A3").beginStroke().moveTo(-0.4,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.6,4.1).curveTo(-6.9,3.2,-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.5,-10.1,6.8,-11.7).lineTo(10.8,1.3).lineTo(11.2,4.3).curveTo(11.2,7.6,8.9,9).curveTo(7.6,10.2,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.4,11.7).closePath();
	this.shape_186.setTransform(55.5,9.1,0.993,0.71);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8).curveTo(-4.8,7.5,-5.4,6.2).lineTo(-6.4,3.8).curveTo(-6.8,2.7,-8.6,-3.2).lineTo(-10.3,-8.9).curveTo(0,-10.6,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.5,10).curveTo(-1.1,10,-3.9,8).closePath();
	this.shape_187.setTransform(72.4,7.1,0.993,0.71);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-1.3,-14.8,0,-7.3).beginStroke().moveTo(-12.3,14).lineTo(-12.3,-13).lineTo(11.3,-14.2).lineTo(12.3,12.3).curveTo(8.2,13.2,2.7,13.8).curveTo(-0.4,14.2,-4.8,14.2).curveTo(-8.2,14.2,-12.3,14).closePath();
	this.shape_188.setTransform(80.1,109.9,0.993,0.71);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.5,-13.4,0.9,-8.1).beginStroke().moveTo(-8.3,-10.6).lineTo(8.3,-15.9).lineTo(8.3,9.7).curveTo(2.3,13.2,-7.4,15.9).closePath();
	this.shape_189.setTransform(99.6,107.3,0.993,0.71);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.beginFill("#F4F4F4").beginStroke().moveTo(-33.9,31.6).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.6).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.6).closePath();
	this.shape_190.setTransform(75.5,50.5,0.993,0.71);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.beginLinearGradientFill(["#BFBFBF","#BFBFBF"],[0,1],0,71.1,0,-71).beginStroke().moveTo(-14.3,69.8).curveTo(-22.1,68.4,-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70,-27.6).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60.1,29.6,65.4).curveTo(19.7,69.3,9.2,70.5).curveTo(4.7,71,-0,71).curveTo(-7.3,71,-14.3,69.8).closePath();
	this.shape_191.setTransform(75.5,50.5,0.993,0.71);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.1,-7.9).lineTo(8.2,-17.7).lineTo(8.1,6.1).curveTo(0.5,13.1,-8.1,17.7).closePath();
	this.shape_192.setTransform(116,101.7,0.993,0.71);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.beginLinearGradientFill(["#666666","#3C3C3F"],[0,1],-3.5,-8.3,1.1,-12.9).beginStroke().moveTo(-5.8,-1.1).lineTo(-5.8,-19.8).lineTo(5.8,-2.4).lineTo(5.8,19.9).curveTo(-4.4,5.3,-5.8,-1.1).closePath();
	this.shape_193.setTransform(12.2,84.9,0.993,0.71);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-3,-9.4,2.7,-9.4).beginStroke().moveTo(-1.4,4.7).lineTo(-2.7,-17.8).lineTo(2.7,-1.2).lineTo(2.7,17.8).curveTo(0.4,12.1,-1.4,4.7).closePath();
	this.shape_194.setTransform(3.8,71.6,0.993,0.71);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.beginFill("#000000").beginStroke().moveTo(0.1,4.8).curveTo(-0.5,0.3,-0.6,-4.8).lineTo(0.5,4.8).closePath();
	this.shape_195.setTransform(0.6,55.6,0.993,0.71);

	this.instance_8 = new lib.outline_23_4();
	this.instance_8.setTransform(75.6,41.9,0.993,0.818,0,0,0,79.2,76.5);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.beginFill("#F48CB1").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_196.setTransform(75.5,35.3,0.993,0.711);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.4).curveTo(3.9,-12.1,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.2,10.3,-3.2).curveTo(9.2,0.4,1.2,11.7).curveTo(-6,4.7,-10.8,-3.7).closePath();
	this.shape_197.setTransform(19.7,77.5,0.993,0.711);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.6).curveTo(-9.8,10.5,-11,7).curveTo(-12.1,4.1,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2.3,-9.4,11.5,-4.3).lineTo(0.9,10).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.6).closePath();
	this.shape_198.setTransform(102.2,10.4,0.993,0.711);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.6,-11.9,4.3).curveTo(-12,2,-10.8,-0).curveTo(-9.9,-1.7,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.7,-7.9,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_199.setTransform(115.5,15.9,0.993,0.711);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0).curveTo(-14.3,-1,-14.5,-2.7).curveTo(-15,-6,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.2).curveTo(-1.1,-13.3,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0).curveTo(6.4,8,-4.2,13.3).closePath();
	this.shape_200.setTransform(115.4,86,0.993,0.711);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,1.9).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.4,13.7,-0.6).curveTo(9,6.7,3,12.5).closePath();
	this.shape_201.setTransform(126.8,77.1,0.993,0.711);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.6,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.1).curveTo(-2.2,9.4,-11.7,3.8).closePath();
	this.shape_202.setTransform(46.8,90.9,0.993,0.711);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-11.4,3.8).lineTo(-3.5,-8.6).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-7).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.9,10.2,-11.4,3.8).closePath();
	this.shape_203.setTransform(32.3,83.1,0.993,0.711);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-9.6,-3.6,10.2,7.8).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.4,0.1,11.1).curveTo(-2.9,12.6,-4.4,12.7).lineTo(-4.9,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_204.setTransform(128,23.3,0.993,0.711);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.3,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).lineTo(12.8,-5.6).curveTo(10.2,3,5.2,11).closePath();
	this.shape_205.setTransform(135.4,68.9,0.993,0.711);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],-0.7,-10.6,2.3,-8.9).beginStroke().moveTo(-3.9,-1.9).lineTo(3.8,-18.5).lineTo(3.8,-1.2).curveTo(1.1,8.6,-3.8,18.5).closePath();
	this.shape_206.setTransform(144.3,77.7,0.993,0.711);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.beginLinearGradientFill(["#D9D9D9","#EDEDED"],[0,1],-0.3,-12.1,2.9,-9).beginStroke().moveTo(-5.4,-4.8).lineTo(5.3,-17.9).lineTo(5.4,2.3).curveTo(0.9,10.6,-5.4,17.9).closePath();
	this.shape_207.setTransform(135.2,89,0.993,0.711);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10,7.6).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(0.9,15,-10,7.6).closePath();
	this.shape_208.setTransform(45.1,105.6,0.993,0.711);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.beginLinearGradientFill(["#D9D9D9","#EDEDED"],[0,1],0.3,-13.6,-2.7,-8.3).beginStroke().moveTo(-7.2,4.6).lineTo(-7.2,-18).lineTo(7.2,-7).lineTo(7.2,18).curveTo(-3.3,10.3,-7.2,4.6).closePath();
	this.shape_209.setTransform(28,98.2,0.993,0.711);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.beginFill("#FFF5F7").beginStroke().moveTo(-33.9,31.6).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.5,47.9,0).curveTo(48,18.5,33.9,31.6).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.6).closePath();
	this.shape_210.setTransform(75.5,50.9,0.993,0.711);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.9,-3.5,10.2,7.5).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.6,-4.5,-10.8).lineTo(9.1,-2).curveTo(12.5,0.7,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_211.setTransform(15.7,32.1,0.993,0.711);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.beginFill("#EFEFEF").beginStroke().moveTo(2.4,11.6).curveTo(-0.3,10.4,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.1,-5.8,-1.3,-11.9).lineTo(9.7,-3.3).lineTo(11.9,-0.9).curveTo(13.9,1.9,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.7,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,11.9,4.3,11.9).curveTo(3.3,11.9,2.4,11.6).closePath();
	this.shape_212.setTransform(24.3,23.2,0.993,0.711);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,10.9,0.4,10.2).lineTo(-1.9,8.8).curveTo(-2.9,8.1,-7.9,4.1).lineTo(-12.7,0.3).curveTo(-5.4,-6.4,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.7).curveTo(11.5,7.6,9.6,8.9).curveTo(6.7,11,3.3,11).lineTo(2.7,11).closePath();
	this.shape_213.setTransform(35.6,14.5,0.993,0.711);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.beginLinearGradientFill(["#F9BED2","#FDAFDB"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60.1,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_214.setTransform(75.5,50.9,0.993,0.711);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],-2.2,-9.4,0.3,-11.3).beginStroke().moveTo(-6,0.5).lineTo(-6,-19).lineTo(6,-3.7).lineTo(6,19).curveTo(-0,12.9,-6,0.5).closePath();
	this.shape_215.setTransform(15,88.1,0.993,0.711);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.beginLinearGradientFill(["#D8EBEF","#ABD0D6"],[0,1],3.1,-9.2,0.5,-12.9).beginStroke().moveTo(-9.4,-5.9).lineTo(9.4,-19.2).lineTo(9.4,3.3).curveTo(1.5,12.8,-9.4,19.2).closePath();
	this.shape_216.setTransform(120.5,99.3,0.993,0.711);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.6).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.5,47.9,0).curveTo(48,18.5,33.9,31.6).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.6).closePath();
	this.shape_217.setTransform(75.5,50.9,0.993,0.711);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60.1,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_218.setTransform(75.5,50.9,0.993,0.711);

	this.instance_9 = new lib.outline_23_5();
	this.instance_9.setTransform(75.6,59.6,0.993,0.817,0,0,0,79.2,76);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.4,-8.9,9,-7.3).curveTo(9.8,-6.4,10.2,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(5.4,3.3,-2,6.6).lineTo(-9.1,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_219.setTransform(10.3,52.4,0.992,0.711);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-5.3,-4.8,0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_220.setTransform(130.7,24.9,0.992,0.711);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.beginFill("#4C9377").beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-5.1,-6.2,6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_221.setTransform(136.9,35.7,0.992,0.711);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.7).lineTo(-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.7).curveTo(9.3,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_222.setTransform(79.6,92.8,0.992,0.711);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.beginFill("#4C9377").beginStroke().moveTo(-8,3.1).curveTo(-9.4,0.6,-10.3,-2.4).curveTo(-11.9,-8.3,-8.7,-10.6).curveTo(-5.7,-12.7,-2.4,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_223.setTransform(97.1,90.5,0.992,0.711);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.4).curveTo(3.1,10,-0.7,12.5).curveTo(-7.9,4.5,-12.3,-4.9).closePath();
	this.shape_224.setTransform(18.8,74.3,0.992,0.711);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.beginFill("#4C9377").beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.2,5.8,6.5).curveTo(3.6,8,-2.1,10.6).lineTo(-7.3,13).curveTo(-11.1,4.9,-12.6,-3.6).closePath();
	this.shape_225.setTransform(13.7,61.6,0.992,0.711);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.8,-10.2).curveTo(12.2,-0.4,11.5,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.7,10.2,-3.9,10).closePath();
	this.shape_226.setTransform(139.4,46.7,0.992,0.711);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.4,-12,-2.7,-12.2).curveTo(-0.7,-12.4,2.2,-10).curveTo(6.1,-6.7,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_227.setTransform(112.1,87.4,0.992,0.711);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.9,-8.4,4.4,-12).lineTo(10.4,2.3).curveTo(11.6,6.4,10.1,7.7).curveTo(7.9,9.7,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_228.setTransform(40.1,13,0.992,0.711);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.beginFill("#4C9377").beginStroke().moveTo(-0.5,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.7,4).curveTo(-6.9,3.1,-9,-1.8).lineTo(-11.2,-6.5).curveTo(-2.6,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.1,7.6,8.9,9).curveTo(7.6,10.1,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.5,11.7).closePath();
	this.shape_229.setTransform(55.5,9.1,0.992,0.711);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.8,7.5,-5.4,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.2,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_230.setTransform(72.5,7.1,0.992,0.711);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.9,-14.8,0.4,-7.4).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-13).lineTo(11.8,-14.2).lineTo(11.6,12.4).curveTo(5.4,14.1,-1.7,14.2).lineTo(-4.1,14.2).curveTo(-9.3,14.2,-11.8,13.8).closePath();
	this.shape_231.setTransform(79.7,109.9,0.992,0.711);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],-0.2,-13.6,1.2,-8.3).beginStroke().moveTo(-8.1,-10.8).lineTo(8.6,-16).lineTo(8.6,9.5).curveTo(0.6,13.7,-8.6,16).closePath();
	this.shape_232.setTransform(99.4,107.4,0.992,0.711);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.beginFill("#25442E").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-48,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,-0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_233.setTransform(75.5,34.8,0.992,0.711);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.beginFill("#F7F9F8").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_234.setTransform(75.5,50.5,0.992,0.711);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.beginLinearGradientFill(["#007C38","#345B41"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_235.setTransform(75.5,50.5,0.992,0.711);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6.1).curveTo(-1.8,14.6,-8.2,17.7).closePath();
	this.shape_236.setTransform(116,101.7,0.992,0.711);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.beginLinearGradientFill(["#666666","#3C3C3F"],[0,1],-3.5,-8.3,1.1,-12.9).beginStroke().moveTo(-5.8,-1.1).lineTo(-5.8,-19.8).lineTo(5.8,-2.5).lineTo(5.8,19.8).curveTo(-2,9.1,-5.8,-1.1).closePath();
	this.shape_237.setTransform(12.3,84.9,0.992,0.711);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.beginFill("#16281A").beginStroke().moveTo(-2.7,-2.1).lineTo(-2.7,-17.7).lineTo(2.7,-1.1).lineTo(2.7,17.7).curveTo(-1.7,5.8,-2.7,-2.1).closePath();
	this.shape_238.setTransform(3.9,71.6,0.992,0.711);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.4).lineTo(0.6,-2.7).lineTo(0.6,12.4).curveTo(-1.1,-0.5,-0.5,-12.4).closePath();
	this.shape_239.setTransform(0.6,60.9,0.992,0.711);

	this.instance_10 = new lib.outline_23_8();
	this.instance_10.setTransform(75.6,60,0.992,0.817,0,0,0,79.2,76.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_22},{t:this.shape_21,p:{scaleX:0.994,scaleY:0.71,y:50.6}},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance_1},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.instance_2},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{scaleX:0.992,scaleY:0.712,x:75.6,y:35.3}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.instance_3},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65}]},1).to({state:[{t:this.instance_4},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86}]},1).to({state:[{t:this.instance_5},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109}]},1).to({state:[{t:this.instance_6},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132}]},1).to({state:[{t:this.instance_7},{t:this.shape_175},{t:this.shape_21,p:{scaleX:0.993,scaleY:0.711,y:51}},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154}]},1).to({state:[{t:this.instance_8},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_58,p:{scaleX:0.993,scaleY:0.71,x:75.5,y:34.8}},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176}]},1).to({state:[{t:this.instance_9},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196}]},1).to({state:[{t:this.instance_10},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,151,120.1);


(lib.BetspotChip = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{zero:0});

	// chipvalue
	this.chipVal = new lib.boardchipVal();
	this.chipVal.setTransform(5,4.2,2.306,2.637,0,-1.2,0);

	this.timeline.addTween(cjs.Tween.get(this.chipVal).wait(1));

	// chipBG
	this.colorChip = new lib.boardChip();
	this.colorChip.setTransform(5,0.4,0.882,0.808,0,0,0,79.4,50);

	this.timeline.addTween(cjs.Tween.get(this.colorChip).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65,-40,133.1,97.1);


(lib.chipVal = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"1":0,"2":1,"3":2,"4":3,"5":4});

	// Layer 6
	this.counter4 = new lib.numbers();
	this.counter4.setTransform(12.4,1.4,0.325,0.328,0,-1.7,-4.7,6.7,13.4);
	this.counter4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter4).wait(4).to({_off:false},0).wait(1));

	// Layer 5
	this.counter3 = new lib.numbers();
	this.counter3.setTransform(12.3,2.2,0.433,0.438,0,-1.4,-4.5,7,13.2);
	this.counter3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter3).wait(3).to({_off:false},0).wait(1).to({regY:13.3,scaleX:0.33,scaleY:0.33,skewX:-1.9,skewY:-5,x:6.8,y:1.4},0).wait(1));

	// Layer 4
	this.counter2 = new lib.numbers();
	this.counter2.setTransform(11.4,3.5,0.578,0.584,0,-1.6,-4.7,6.9,13.4);
	this.counter2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter2).wait(2).to({_off:false},0).wait(1).to({regX:6.8,regY:13.3,scaleX:0.43,scaleY:0.44,skewX:-0.3,skewY:-3.4,x:4.8,y:2.2},0).wait(1).to({regY:13.2,scaleX:0.33,scaleY:0.33,skewX:-0.1,skewY:-3.2,x:1.2,y:1.4},0).wait(1));

	// Layer 2
	this.counter1 = new lib.numbers();
	this.counter1.setTransform(6.4,3.4,0.578,0.584,0,-1.9,-5,7,13.4);
	this.counter1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.counter1).wait(1).to({_off:false},0).wait(1).to({regX:6.8,regY:13.3,skewX:0.1,skewY:-3,x:1.4},0).wait(1).to({regX:6.9,regY:13.2,scaleX:0.43,scaleY:0.44,skewX:0.6,skewY:-2.5,x:-2.5,y:2.2},0).wait(1).to({regY:13.3,scaleX:0.33,scaleY:0.33,skewX:-1.1,skewY:-4.2,x:-4.5,y:1.3},0).wait(1));

	// Layer 9
	this.counter0 = new lib.numbers();
	this.counter0.setTransform(1.4,3.2,0.618,0.589,0,0,0,6.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.counter0).wait(1).to({x:-3.1},0).wait(1).to({x:-8},0).wait(1).to({scaleX:0.46,scaleY:0.44,x:-10,y:2.1},0).wait(1).to({scaleX:0.35,scaleY:0.33,x:-10.2,y:1.3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.4,-7.2,10.3,12.1);


(lib.chipBg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"red":0,"blue":1,"white":2,"yellow":3,"brown":4,"purple":5,"gold":6,"black":7,"gray":8,"pink":9,"green":10});

	// coloredchip
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#991F1F").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape.setTransform(75.5,35,0.994,0.71);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_1.setTransform(19.6,77.2,0.994,0.71);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_2.setTransform(102.1,10.1,0.994,0.71);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_3.setTransform(115.5,15.6,0.994,0.71);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_4.setTransform(115.3,85.7,0.994,0.71);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_5.setTransform(126.8,76.8,0.994,0.71);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_6.setTransform(46.7,90.6,0.994,0.71);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_7.setTransform(32.2,82.8,0.994,0.71);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],6.5,-8.7,-5.9,12.9).beginStroke().moveTo(-8,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.1,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-8,11.7).closePath();
	this.shape_8.setTransform(127.9,23,0.994,0.71);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(2.5,-10.1,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_9.setTransform(135.3,68.6,0.994,0.71);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.7).lineTo(3.8,-18.4).lineTo(3.8,-1.4).curveTo(1.1,9.9,-3.8,18.4).closePath();
	this.shape_10.setTransform(144.2,75.6,0.994,0.71);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#2F7C62").beginStroke().moveTo(-5.3,-4.9).lineTo(5.4,-17.9).lineTo(5.4,2.3).curveTo(0.7,11,-5.3,17.9).closePath();
	this.shape_11.setTransform(135.1,87.1,0.994,0.71);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],1,-14.2,-2.3,-8.5).beginStroke().moveTo(-10.1,7.6).lineTo(-10.1,-17.4).lineTo(10,-9).lineTo(10,17.4).curveTo(-0.5,14.2,-10.1,7.6).closePath();
	this.shape_12.setTransform(45.1,102.7,0.994,0.71);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#2F7C62").beginStroke().moveTo(-7.2,4.8).lineTo(-7.2,-18).lineTo(7.2,-7).lineTo(7.2,18).curveTo(-0.4,12.7,-7.2,4.8).closePath();
	this.shape_13.setTransform(27.9,95.3,0.994,0.71);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFF4F3").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,-0).curveTo(-48,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.5,48,-0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_14.setTransform(75.4,50.8,0.994,0.71);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],4.9,-5.4,-3.6,9.3).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_15.setTransform(15.7,31.8,0.994,0.71);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginLinearGradientFill(["#3D8F75","#367F67"],[0,1],-6.1,-9.2,6,11.7).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_16.setTransform(24.3,22.9,0.994,0.71);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_17.setTransform(35.5,14.2,0.994,0.71);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginLinearGradientFill(["#BC3835","#CE5F51"],[0,1],0,71.1,0,-71).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_18.setTransform(75.5,50.6,0.994,0.71);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],-2.1,-9.5,0.4,-11.4).beginStroke().moveTo(-6.1,0.4).lineTo(-5.9,-19.1).lineTo(6.1,-3.7).lineTo(6,19.1).curveTo(-1.3,10.3,-6.1,0.4).closePath();
	this.shape_19.setTransform(14.8,85.1,0.994,0.71);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginLinearGradientFill(["#9FD3DD","#84B9C1"],[0,1],3.1,-9.4,0.5,-13.1).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.4).lineTo(9.4,3.5).curveTo(-1,14.9,-9.4,19.4).closePath();
	this.shape_20.setTransform(120.4,96.4,0.994,0.71);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_21.setTransform(75.5,50.6,0.994,0.71);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_22.setTransform(75.5,50.6,0.994,0.71);

	this.instance = new lib.Path_23_7();
	this.instance.setTransform(76.1,62.2,0.994,0.807,0,0,0,79.1,77);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-7.3,1.9).curveTo(-10.8,-0.8,-10.1,-4.3).curveTo(-9.7,-6.3,-8.9,-7.2).curveTo(-7.3,-8.9,-3.1,-9.5).lineTo(9.9,-9.5).curveTo(10.9,0.1,9.2,9.5).curveTo(-4.3,4.2,-7.3,1.9).closePath();
	this.shape_23.setTransform(140.7,52.3,0.993,0.71);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-6.9,-8.1,5.3,13.1).beginStroke().moveTo(4.5,11.5).lineTo(-12.9,5.1).curveTo(-8.1,-4.2,-0.8,-11.7).lineTo(2.7,-7.9).curveTo(6.6,-3.9,8.7,-2.3).curveTo(11.7,-0.2,12.6,2.8).curveTo(13.6,6.3,10.8,9.4).curveTo(8.8,11.7,6,11.7).curveTo(5.3,11.7,4.5,11.5).closePath();
	this.shape_24.setTransform(20.3,25,0.993,0.71);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(2.4,9.4).lineTo(-12.3,5.3).curveTo(-10.4,-2.8,-6.6,-10.1).lineTo(-6.3,-10.2).lineTo(-0.2,-8).curveTo(6.2,-5.6,8,-4.8).curveTo(10.2,-3.7,11.5,-1.8).curveTo(12.8,0.2,11.9,1.4).curveTo(11.1,2.3,11.1,3.6).lineTo(11.3,4.6).curveTo(10.8,7.6,9.5,8.7).curveTo(8.8,9.4,7.3,9.9).curveTo(6.8,10.2,6,10.2).curveTo(4.6,10.2,2.4,9.4).closePath();
	this.shape_25.setTransform(14,35.8,0.993,0.71);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,9.9).curveTo(-9.2,-4,-8,-6.6).curveTo(-6.7,-9.3,-4.9,-10.4).curveTo(-1.9,-12,3.8,-11.3).curveTo(9.3,-10.5,10.9,-7.5).curveTo(11.6,-6,11.3,-4.6).lineTo(11.8,11.1).curveTo(7.9,11.5,4,11.5).curveTo(-4,11.5,-11.8,9.9).closePath();
	this.shape_26.setTransform(71.3,92.8,0.993,0.71);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-10.8,7.8).curveTo(-5.1,-6.4,-3,-10.6).curveTo(-1.6,-13.5,2.4,-13.1).curveTo(5.7,-12.8,8.7,-10.7).curveTo(11.9,-8.4,10.3,-2.4).curveTo(9.5,0.6,8,3.1).lineTo(5.8,13.1).curveTo(-2.7,11.4,-10.8,7.8).closePath();
	this.shape_27.setTransform(53.8,90.6,0.993,0.71);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-8,5.3).curveTo(-11.8,1.8,-12.2,-1.6).curveTo(-12.8,-5.2,-9.8,-9.4).curveTo(-7.2,-13,-3.6,-12.4).curveTo(-1.7,-12.2,-0.4,-11.2).lineTo(12.3,-4.9).curveTo(8,4.5,0.7,12.5).curveTo(-3.1,10,-8,5.3).closePath();
	this.shape_28.setTransform(132.3,74.4,0.993,0.71);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-5.8,6.4).curveTo(-8.9,4.3,-9.6,3.6).curveTo(-10.8,2.2,-12.1,-1.1).curveTo(-13.3,-4.3,-11.4,-8.7).curveTo(-9.7,-12.4,-8.3,-12.9).curveTo(-7.5,-13.2,-4.4,-11.6).lineTo(-1.4,-9.8).lineTo(12.6,-3.7).curveTo(11,5,7.3,12.9).curveTo(-2.2,8.9,-5.8,6.4).closePath();
	this.shape_29.setTransform(137.3,61.7,0.993,0.71);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-5.4,10.2).lineTo(-11.5,9.9).curveTo(-12.2,-0.5,-9.8,-10.2).lineTo(-3.9,-8.5).curveTo(2.5,-6.6,5.2,-6).curveTo(9.5,-5.1,11.2,-1.5).curveTo(11.5,-0.8,11.6,1.6).curveTo(11.7,4.5,11,6.2).curveTo(10.2,8.1,8.6,8.9).curveTo(7.3,9.5,3.9,10).curveTo(2,10.2,-1.8,10.2).lineTo(-5.4,10.2).closePath();
	this.shape_30.setTransform(11.5,46.8,0.993,0.71);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-12,2.5).lineTo(-8.6,-2.5).curveTo(-4.6,-7.9,-2.2,-10).curveTo(0.7,-12.4,2.7,-12.2).curveTo(4.4,-12,10,-9.1).curveTo(12.6,-7.7,11.9,-5.2).curveTo(11.6,-4,10.7,-3).lineTo(4.3,12.2).curveTo(-4.6,8.3,-12,2.5).closePath();
	this.shape_31.setTransform(38.9,87.5,0.993,0.71);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-6.9,-10.4,4.2,8.9).beginStroke().moveTo(-10.1,7.8).curveTo(-11.6,6.5,-10.4,2.4).lineTo(-4.4,-11.9).curveTo(3.8,-8.4,11,-3.2).curveTo(6.3,4.5,5.4,5.8).curveTo(1.3,11.5,-1.7,11.9).lineTo(-2.4,11.9).curveTo(-5.4,11.9,-10.1,7.8).closePath();
	this.shape_32.setTransform(110.9,13.1,0.993,0.71);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginLinearGradientFill(["#105482","#0E4868"],[0,1],-10.4,-5.4,7.1,4.7).beginStroke().moveTo(-4.4,11).curveTo(-6.4,10.4,-7.9,9.7).lineTo(-8.9,9).curveTo(-11.2,7.6,-11.2,4.3).lineTo(-10.8,1.2).lineTo(-6.8,-11.8).curveTo(2.5,-10.2,11.2,-6.6).lineTo(9.1,-1.8).curveTo(6.9,3.1,6.6,4).curveTo(5.7,7.3,4.1,9.7).curveTo(2.9,11.6,0.4,11.7).lineTo(0.3,11.8).curveTo(-1.4,11.8,-4.4,11).closePath();
	this.shape_33.setTransform(95.5,9.2,0.993,0.71);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-5.8,-12.1,5.4,7.3).beginStroke().moveTo(-3,10).curveTo(-5.3,9.9,-7.8,7.9).curveTo(-9.9,6.1,-10.1,5).curveTo(-10.4,3.7,-10.1,-9.7).curveTo(0,-10.6,10.3,-8.9).curveTo(7.1,2.1,6.4,3.8).lineTo(5.4,6.2).curveTo(4.8,7.4,3.9,8).curveTo(1.2,10,-2.4,10).lineTo(-3,10).closePath();
	this.shape_34.setTransform(78.5,7.2,0.993,0.71);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],0.9,-7.3,-0.4,-14.8).beginStroke().moveTo(-11.8,12.2).lineTo(-11.8,-14.2).lineTo(11.8,-13).lineTo(11.8,13.7).curveTo(11.2,13.9,4.3,14.2).lineTo(2.9,14.2).curveTo(-3.5,14.2,-11.8,12.2).closePath();
	this.shape_35.setTransform(71.3,110,0.993,0.71);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.beginLinearGradientFill(["#1C598C","#2462A0"],[0,1],0.6,-8.1,-0.8,-13.4).beginStroke().moveTo(-8.3,9.6).lineTo(-8.3,-15.8).lineTo(8.3,-10.5).lineTo(8.3,15.8).curveTo(1.9,14.7,-8.3,9.6).closePath();
	this.shape_36.setTransform(51.4,107.4,0.993,0.71);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.beginFill("#0E4366").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_37.setTransform(75.5,34.9,0.993,0.71);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.beginFill("#F8FDFF").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_38.setTransform(75.5,50.6,0.993,0.71);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.beginLinearGradientFill(["#3E75C6","#3067AA"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60.1,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_39.setTransform(75.5,50.5,0.993,0.71);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],0.5,-8.6,-1.8,-12.6).beginStroke().moveTo(-8.2,6).lineTo(-8.2,-17.6).lineTo(8.1,-7.8).lineTo(8.1,17.6).curveTo(1.3,14.6,-8.2,6).closePath();
	this.shape_40.setTransform(35,101.7,0.993,0.71);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.beginLinearGradientFill(["#8E7573","#705453"],[0,1],3.5,-12.7,-1.1,-8.1).beginStroke().moveTo(-5.8,-2.2).lineTo(5.8,-19.7).lineTo(5.8,-0.9).curveTo(0.8,11.4,-5.8,19.7).closePath();
	this.shape_41.setTransform(138.7,84.9,0.993,0.71);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.beginFill("#063D5B").beginStroke().moveTo(-2.7,-1.1).lineTo(2.7,-17.7).lineTo(2.7,-1.9).curveTo(0.6,9,-2.7,17.7).closePath();
	this.shape_42.setTransform(147.2,71.7,0.993,0.71);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.beginFill("#5B4342").beginStroke().moveTo(-0.6,-3.1).lineTo(0.5,-12.6).curveTo(1,4.8,-0.6,12.7).closePath();
	this.shape_43.setTransform(150.4,61.3,0.993,0.71);

	this.instance_1 = new lib.Path_23_9();
	this.instance_1.setTransform(75.5,60.1,0.993,0.817,0,0,0,79.1,76.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.4,-8.9,9,-7.3).curveTo(9.8,-6.4,10.2,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(4.3,4.2,-9.1,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_44.setTransform(10.3,52.7,0.992,0.712);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-6.6,-3.9,-2.7,-7.9).lineTo(0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_45.setTransform(130.7,25.3,0.992,0.712);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-6.2,-5.6,0.2,-8).lineTo(6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_46.setTransform(137,36.1,0.992,0.712);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.7).curveTo(-11.6,-6,-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.7).curveTo(9.2,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_47.setTransform(79.7,93.3,0.992,0.712);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-8,3.1).curveTo(-9.4,0.6,-10.3,-2.4).curveTo(-11.9,-8.3,-8.7,-10.6).curveTo(-5.7,-12.7,-2.4,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_48.setTransform(97.2,91,0.992,0.712);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.4).curveTo(3.1,10,-0.7,12.5).curveTo(-7.9,4.5,-12.3,-4.9).closePath();
	this.shape_49.setTransform(18.8,74.8,0.992,0.712);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.2,5.8,6.5).curveTo(2.2,8.9,-7.3,13).curveTo(-11.1,4.9,-12.6,-3.6).closePath();
	this.shape_50.setTransform(13.8,62.1,0.992,0.712);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.8,-10.2).curveTo(12.2,-0.4,11.5,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.7,10.2,-3.9,10).closePath();
	this.shape_51.setTransform(139.5,47.1,0.992,0.712);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.4,-12,-2.7,-12.2).curveTo(-0.7,-12.4,2.2,-10).curveTo(6.1,-6.7,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_52.setTransform(112.2,87.9,0.992,0.712);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.9,-8.4,4.4,-12).lineTo(10.4,2.3).curveTo(11.6,6.4,10.1,7.7).curveTo(7.9,9.7,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_53.setTransform(40.1,13.4,0.992,0.712);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.beginLinearGradientFill(["#E5A367","#DD9458"],[0,1],-4.2,-10.5,7.6,9.9).beginStroke().moveTo(-0.4,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.6,4).curveTo(-6.9,3.1,-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.5,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.2,7.6,8.9,9).curveTo(7.6,10.1,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.4,11.7).closePath();
	this.shape_54.setTransform(55.6,9.5,0.992,0.712);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.beginLinearGradientFill(["#B95749","#9B4840"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.8,7.5,-5.4,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.2,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_55.setTransform(72.5,7.4,0.992,0.712);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-0.9,-14.7,0.4,-7.3).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-12.9).lineTo(11.8,-14.1).lineTo(11.8,12.4).curveTo(5.7,13.8,-0.3,14).lineTo(-4.1,14.1).curveTo(-8.1,14.1,-11.8,13.8).closePath();
	this.shape_56.setTransform(79.7,108.9,0.992,0.712);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.beginLinearGradientFill(["#C9803F","#E09F5F"],[0,1],-0.5,-13.5,0.9,-8.2).beginStroke().moveTo(-8.3,-10.6).lineTo(8.3,-15.9).lineTo(8.2,9.7).curveTo(0.1,13.9,-8.3,15.9).closePath();
	this.shape_57.setTransform(99.7,106.5,0.992,0.712);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.beginFill("#3C3C3F").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_58.setTransform(75.6,35.3,0.992,0.712);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.beginFill("#F2F2F2").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_59.setTransform(75.6,50.9,0.992,0.712);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.beginLinearGradientFill(["#F9F9F9","#D4D4D4"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_60.setTransform(75.6,50.9,0.992,0.712);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6).curveTo(-0.8,14.1,-8.2,17.7).closePath();
	this.shape_61.setTransform(116,100.8,0.992,0.712);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.beginLinearGradientFill(["#B25749","#C97451"],[0,1],-3.5,-8.2,1.1,-12.8).beginStroke().moveTo(-5.8,-0.7).lineTo(-5.8,-19.7).lineTo(5.8,-2.3).lineTo(5.7,19.7).curveTo(-0.8,11.2,-5.8,-0.7).closePath();
	this.shape_62.setTransform(12.4,83.9,0.992,0.712);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.beginFill("#C9803F").beginStroke().moveTo(-2.7,-1.5).lineTo(-2.7,-17.8).lineTo(2.7,-1.2).lineTo(2.7,17.8).curveTo(-0.7,9,-2.7,-1.5).closePath();
	this.shape_63.setTransform(3.9,70.7,0.992,0.712);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.6).lineTo(0.6,-2.9).lineTo(0.6,12.6).curveTo(-1.2,0.8,-0.5,-12.6).closePath();
	this.shape_64.setTransform(0.6,60.1,0.992,0.712);

	this.instance_2 = new lib.Path_23();
	this.instance_2.setTransform(75.7,61.3,0.992,0.817,0,0,0,79.2,78.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-7.3,1.9).curveTo(-10.8,-0.8,-10.2,-4.3).curveTo(-9.8,-6.4,-9,-7.3).curveTo(-7.4,-8.9,-3.1,-9.5).lineTo(9.9,-9.5).curveTo(10.9,0.1,9.1,9.5).curveTo(-4.3,4.2,-7.3,1.9).closePath();
	this.shape_65.setTransform(140.6,52.4,0.992,0.71);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-6.9,-8.1,5.3,13.1).beginStroke().moveTo(4.5,11.5).lineTo(-12.9,5.1).curveTo(-8.1,-4.2,-0.8,-11.7).lineTo(2.7,-7.9).curveTo(6.6,-3.9,8.7,-2.4).curveTo(11.7,-0.2,12.6,2.8).curveTo(13.6,6.3,10.8,9.4).curveTo(8.8,11.7,6.1,11.7).curveTo(5.3,11.7,4.5,11.5).closePath();
	this.shape_66.setTransform(20.2,25.1,0.992,0.71);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,10.2,0,-10.2).beginStroke().moveTo(2.4,9.4).lineTo(-12.3,5.2).curveTo(-10.4,-2.8,-6.6,-10.1).lineTo(-6.3,-10.2).lineTo(-0.2,-8).curveTo(6.2,-5.6,8,-4.8).curveTo(10.2,-3.7,11.5,-1.8).curveTo(12.8,0.2,11.9,1.4).curveTo(11.1,2.3,11.1,3.6).lineTo(11.3,4.6).curveTo(10.8,7.6,9.5,8.7).curveTo(8.8,9.4,7.3,9.9).curveTo(6.8,10.2,6,10.2).curveTo(4.6,10.2,2.4,9.4).closePath();
	this.shape_67.setTransform(14,35.8,0.992,0.71);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,9.9).curveTo(-9.3,-4.1,-8,-6.7).curveTo(-6.7,-9.3,-4.8,-10.4).curveTo(-1.9,-12,3.8,-11.3).curveTo(9.2,-10.6,10.8,-7.5).curveTo(11.7,-6,11.4,-4.7).lineTo(11.8,11.1).curveTo(8,11.5,4.3,11.5).curveTo(-3.8,11.5,-11.8,9.9).closePath();
	this.shape_68.setTransform(71.3,92.9,0.992,0.71);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-10.8,7.8).curveTo(-5.1,-6.3,-3,-10.6).curveTo(-1.6,-13.4,2.4,-13.1).curveTo(5.7,-12.7,8.7,-10.6).curveTo(11.9,-8.3,10.3,-2.4).curveTo(9.5,0.6,8,3.1).lineTo(5.8,13.1).curveTo(-2.9,11.3,-10.8,7.8).closePath();
	this.shape_69.setTransform(53.8,90.6,0.992,0.71);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-8,5.4).curveTo(-11.8,1.8,-12.2,-1.6).curveTo(-12.8,-5.1,-9.8,-9.4).curveTo(-7.2,-13,-3.6,-12.4).curveTo(-1.7,-12.2,-0.4,-11.2).lineTo(12.3,-4.9).curveTo(7.9,4.6,0.7,12.5).curveTo(-3.1,10,-8,5.4).closePath();
	this.shape_70.setTransform(132.2,74.4,0.992,0.71);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],-9.9,-11.4,10.9,9.4).beginStroke().moveTo(-5.8,6.5).curveTo(-9,4.3,-9.6,3.6).curveTo(-10.9,2.3,-12.1,-1.1).curveTo(-13.3,-4.3,-11.4,-8.6).curveTo(-9.7,-12.4,-8.3,-12.9).curveTo(-7.5,-13.2,-4.4,-11.5).lineTo(-1.4,-9.8).lineTo(12.6,-3.6).curveTo(11.1,4.9,7.3,13).curveTo(-2.2,8.9,-5.8,6.5).closePath();
	this.shape_71.setTransform(137.2,61.7,0.992,0.71);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-5.4,10.2).lineTo(-11.4,10).curveTo(-12.1,-0.3,-9.8,-10.2).lineTo(-3.9,-8.5).curveTo(2.5,-6.6,5.2,-6).curveTo(9.4,-5.2,11.2,-1.5).curveTo(11.5,-0.7,11.6,1.6).curveTo(11.7,4.5,11,6.3).curveTo(10.2,8.2,8.6,8.9).curveTo(7.3,9.5,3.9,10).curveTo(1.9,10.2,-2.1,10.2).lineTo(-5.4,10.2).closePath();
	this.shape_72.setTransform(11.5,46.8,0.992,0.71);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-12,2.4).lineTo(-8.6,-2.5).curveTo(-4.6,-7.9,-2.2,-10).curveTo(0.7,-12.4,2.7,-12.2).curveTo(4.4,-12,10,-9.1).curveTo(12.6,-7.7,11.9,-5.3).curveTo(11.6,-4,10.7,-3.1).lineTo(4.3,12.2).curveTo(-4.7,8.2,-12,2.4).closePath();
	this.shape_73.setTransform(38.8,87.5,0.992,0.71);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-6.9,-10.5,4.2,8.8).beginStroke().moveTo(-5.9,10.8).curveTo(-7.9,9.7,-10.1,7.7).curveTo(-11.6,6.4,-10.4,2.3).lineTo(-4.4,-12).curveTo(3.8,-8.5,11,-3.3).lineTo(5.4,5.7).curveTo(3.8,8,2.1,9.6).curveTo(-0.1,11.6,-1.7,11.9).lineTo(-2.3,12).curveTo(-3.8,12,-5.9,10.8).closePath();
	this.shape_74.setTransform(110.8,13.1,0.992,0.71);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.beginLinearGradientFill(["#FDDBE1","#F9BED2"],[0,1],0,-11.7,0,11.7).beginStroke().moveTo(-4.4,11).curveTo(-6.4,10.5,-7.9,9.7).lineTo(-8.9,9).curveTo(-11.1,7.6,-11.2,4.3).lineTo(-10.8,1.2).lineTo(-6.8,-11.7).curveTo(2.6,-10.2,11.2,-6.5).lineTo(9.1,-1.8).curveTo(6.9,3.2,6.6,4).curveTo(5.7,7.4,4.2,9.7).curveTo(2.9,11.6,0.5,11.7).lineTo(0.1,11.7).curveTo(-1.6,11.7,-4.4,11).closePath();
	this.shape_75.setTransform(95.4,9.3,0.992,0.71);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.beginLinearGradientFill(["#4B83C4","#427AB2"],[0,1],-5.8,-12.1,5.4,7.3).beginStroke().moveTo(-3,9.9).curveTo(-5.3,9.8,-7.8,7.8).curveTo(-9.9,6.1,-10.1,4.9).curveTo(-10.4,3.7,-10.1,-9.7).curveTo(0.3,-10.6,10.3,-8.9).lineTo(8.6,-3.2).curveTo(6.8,2.7,6.4,3.8).lineTo(5.4,6.2).curveTo(4.8,7.4,3.9,8).curveTo(1.2,10,-2.2,10).lineTo(-3,9.9).closePath();
	this.shape_76.setTransform(78.4,7.2,0.992,0.71);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],0.9,-7.3,-0.4,-14.7).beginStroke().moveTo(-2.2,13.8).curveTo(-8.1,13.2,-11.8,12.4).lineTo(-11.8,-14.1).lineTo(11.8,-12.9).lineTo(11.8,13.9).curveTo(7.9,14.1,4.5,14.1).curveTo(0.9,14.1,-2.2,13.8).closePath();
	this.shape_77.setTransform(71.3,110,0.992,0.71);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.beginLinearGradientFill(["#DD879F","#FBC8D5"],[0,1],0.6,-8.2,-0.8,-13.5).beginStroke().moveTo(-8.3,9.5).lineTo(-8.3,-15.9).lineTo(8.3,-10.7).lineTo(8.3,15.9).curveTo(-0.7,13.7,-8.3,9.5).closePath();
	this.shape_78.setTransform(51.3,107.6,0.992,0.71);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.beginFill("#897828").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_79.setTransform(75.4,34.9,0.992,0.71);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.beginFill("#FFFDEB").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_80.setTransform(75.4,50.6,0.992,0.71);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.beginLinearGradientFill(["#F7E943","#E5D53E"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.5,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.7,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_81.setTransform(75.4,50.6,0.992,0.71);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],0.5,-8.6,-1.8,-12.6).beginStroke().moveTo(-8.2,5.9).lineTo(-8.2,-17.6).lineTo(8.1,-7.8).lineTo(8.1,17.6).curveTo(-1.3,12.4,-8.2,5.9).closePath();
	this.shape_82.setTransform(35,101.8,0.992,0.71);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.beginLinearGradientFill(["#356493","#4B83C4"],[0,1],3.5,-12.9,-1.1,-8.3).beginStroke().moveTo(-5.8,-2.4).lineTo(5.8,-19.8).lineTo(5.8,-0.6).curveTo(1.6,9.2,-5.8,19.8).closePath();
	this.shape_83.setTransform(138.6,85.1,0.992,0.71);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.beginFill("#DD879F").beginStroke().moveTo(-2.7,-1.4).lineTo(2.7,-18).lineTo(2.7,-1.8).curveTo(0.6,8.7,-2.7,18).closePath();
	this.shape_84.setTransform(147.1,72,0.992,0.71);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.beginFill("#5B4342").beginStroke().moveTo(-0.6,-2.9).lineTo(0.5,-12.6).curveTo(1.1,0.9,-0.6,12.6).closePath();
	this.shape_85.setTransform(150.4,61.3,0.992,0.71);

	this.instance_3 = new lib.Path_23_3();
	this.instance_3.setTransform(75.4,59.9,0.992,0.816,0,0,0,79.1,76.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.beginFill("#000000").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.7,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,-0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_86.setTransform(75.5,34.8,0.993,0.711);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_87.setTransform(19.7,77,0.993,0.711);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7.7,-12.3,4.3,8.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_88.setTransform(102.2,9.9,0.993,0.711);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_89.setTransform(115.5,15.4,0.993,0.711);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_90.setTransform(115.3,85.6,0.993,0.711);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_91.setTransform(126.8,76.7,0.993,0.711);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_92.setTransform(46.8,90.5,0.993,0.711);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_93.setTransform(32.3,82.6,0.993,0.711);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7.5,-8.8,3.1,9.5).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.8,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4.1,9.3,0.2,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_94.setTransform(128,22.8,0.993,0.711);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_95.setTransform(135.4,68.4,0.993,0.711);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-0.7,-10.6,2.3,-8.9).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.5).lineTo(3.8,-1.1).curveTo(1.2,8.4,-3.8,18.5).closePath();
	this.shape_96.setTransform(144.3,77.6,0.993,0.711);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.beginFill("#C1AE3E").beginStroke().moveTo(-5.4,-4.9).lineTo(5.3,-18).lineTo(5.4,2.1).curveTo(0.6,11,-5.4,17.9).closePath();
	this.shape_97.setTransform(135.2,89.1,0.993,0.711);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-2.3,-8.4,1,-14.1).beginStroke().moveTo(-10,7.4).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(-1.9,13.7,-10,7.4).closePath();
	this.shape_98.setTransform(45.1,105.6,0.993,0.711);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.beginFill("#C1AE3E").beginStroke().moveTo(-7.1,4.9).lineTo(-7.2,-17.9).lineTo(7.2,-6.9).lineTo(7.2,17.9).curveTo(-0.6,12.4,-7.1,4.9).closePath();
	this.shape_99.setTransform(28,98.1,0.993,0.711);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.beginFill("#EAEAEA").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_100.setTransform(75.5,50.5,0.993,0.711);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-7,-9.3,5.2,11.8).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_101.setTransform(15.7,31.6,0.993,0.711);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.beginLinearGradientFill(["#E5CF6E","#D6C065"],[0,1],-3.4,-11.3,2.9,12.5).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_102.setTransform(24.3,22.7,0.993,0.711);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.beginLinearGradientFill(["#E8E8E8","#D6D6D6"],[0,1],-4.3,-6.5,5.9,11.2).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_103.setTransform(35.6,14,0.993,0.711);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_104.setTransform(75.5,50.5,0.993,0.711);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],-2.2,-9.4,0.3,-11.3).beginStroke().moveTo(-5.9,0.9).lineTo(-6,-19).lineTo(6,-3.7).lineTo(6,19).curveTo(-0.8,11.2,-5.9,0.9).closePath();
	this.shape_105.setTransform(14.9,88,0.993,0.711);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.beginLinearGradientFill(["#DDDDDD","#B7B7B7"],[0,1],3.1,-9.3,0.5,-13).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.3).lineTo(9.4,3.4).curveTo(2.2,12.2,-9.4,19.3).closePath();
	this.shape_106.setTransform(120.5,99.3,0.993,0.711);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_107.setTransform(75.5,50.5,0.993,0.711);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.5,-71,-0,-71).curveTo(15.4,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.4,71,-0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_108.setTransform(75.5,50.5,0.993,0.711);

	this.instance_4 = new lib.Path_23_1();
	this.instance_4.setTransform(75.6,60.1,0.993,0.818,0,0,0,79.2,76.7);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.beginFill("#3B1C63").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-48,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,-0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_109.setTransform(75.5,34.9,0.993,0.711);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_110.setTransform(19.7,77.1,0.993,0.711);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(2.8,7.3).curveTo(2.3,8.8,0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_111.setTransform(102.2,10,0.993,0.711);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.beginFill("#4C9377").beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_112.setTransform(115.5,15.4,0.993,0.711);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_113.setTransform(115.3,85.6,0.993,0.711);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.beginFill("#4C9377").beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_114.setTransform(126.8,76.7,0.993,0.711);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_115.setTransform(46.8,90.5,0.993,0.711);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.beginFill("#4C9377").beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_116.setTransform(32.2,82.7,0.993,0.711);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-9.6,-3.6,10.2,7.8).beginStroke().moveTo(-7.9,11.7).curveTo(-9.6,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.8,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-7.5,-4.5,-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.2,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_117.setTransform(127.9,22.9,0.993,0.711);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_118.setTransform(135.3,68.5,0.993,0.711);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.4).lineTo(3.8,-1.2).curveTo(1,9.2,-3.8,18.4).closePath();
	this.shape_119.setTransform(144.2,77.5,0.993,0.711);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],-0.2,-12.3,2.9,-9.1).beginStroke().moveTo(-5.4,-4.9).lineTo(5.3,-18).lineTo(5.3,2.3).curveTo(2.3,8.7,-5.4,17.9).closePath();
	this.shape_120.setTransform(135.1,89.1,0.993,0.711);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10.1,7.4).lineTo(-10.1,-17.3).lineTo(10.1,-8.9).lineTo(9.9,17.3).curveTo(0.8,14.9,-10.1,7.4).closePath();
	this.shape_121.setTransform(45.2,105.6,0.993,0.711);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],0.3,-13.5,-2.7,-8.3).beginStroke().moveTo(-2.1,10.2).curveTo(-4.7,7.6,-7.2,4.8).lineTo(-7.2,-17.9).lineTo(7.2,-6.9).lineTo(7.2,17.9).curveTo(2.3,14.4,-2.1,10.2).closePath();
	this.shape_122.setTransform(28.1,98.2,0.993,0.711);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.beginFill("#F9F3FF").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_123.setTransform(75.5,50.5,0.993,0.711);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-8.9,-3.5,10.2,7.5).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_124.setTransform(15.7,31.7,0.993,0.711);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.beginFill("#4C9377").beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_125.setTransform(24.3,22.7,0.993,0.711);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.beginLinearGradientFill(["#B5AAA9","#9E9595"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_126.setTransform(35.6,14,0.993,0.711);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.beginLinearGradientFill(["#AA6AE2","#7745A3"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_127.setTransform(75.5,50.5,0.993,0.711);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],-2.2,-9.5,0.3,-11.4).beginStroke().moveTo(-6,0.7).lineTo(-6,-19.1).lineTo(6,-3.7).lineTo(6,19.1).curveTo(-0,12,-6,0.7).closePath();
	this.shape_128.setTransform(15,88.1,0.993,0.711);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.beginLinearGradientFill(["#705453","#8E7573"],[0,1],3.1,-9.4,0.5,-13.1).beginStroke().moveTo(-9.4,-6).lineTo(9.4,-19.4).lineTo(9.4,3.4).curveTo(-1,14.7,-9.5,19.4).closePath();
	this.shape_129.setTransform(120.4,99.4,0.993,0.711);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_130.setTransform(75.5,50.5,0.993,0.711);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_131.setTransform(75.5,50.5,0.993,0.711);

	this.instance_5 = new lib.Path_23_6();
	this.instance_5.setTransform(75.6,60.1,0.993,0.818,0,0,0,79.2,76.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.3,-8.9,8.9,-7.3).curveTo(9.7,-6.4,10.2,-4.3).curveTo(10.8,-0.9,7.3,1.9).curveTo(5.4,3.3,-2,6.6).lineTo(-9.1,9.5).curveTo(-10.9,-0.2,-9.9,-9.5).closePath();
	this.shape_132.setTransform(10.4,52.5,0.991,0.711);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-5.3,-4.8,0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_133.setTransform(130.7,25,0.991,0.711);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-10.2,0,10.2).beginStroke().moveTo(-7.3,9.9).curveTo(-8.7,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.2,-3.7,-8,-4.8).curveTo(-5.1,-6.2,6.4,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.7,12.3,5.2).lineTo(-2.3,9.4).curveTo(-4.6,10.2,-5.9,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_134.setTransform(136.9,35.8,0.991,0.711);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.3,-4.7).lineTo(-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.6,-9.3,8,-6.7).curveTo(9.3,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_135.setTransform(79.7,92.9,0.991,0.711);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-13,0,13.1).beginStroke().moveTo(-7.9,3.1).curveTo(-9.4,0.6,-10.2,-2.4).curveTo(-11.9,-8.3,-8.6,-10.6).curveTo(-5.7,-12.7,-2.3,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_136.setTransform(97.1,90.6,0.991,0.711);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.3,-13,9.8,-9.4).curveTo(12.8,-5.2,12.3,-1.6).curveTo(11.8,1.8,8,5.4).curveTo(3.1,10,-0.6,12.5).curveTo(-7.8,4.7,-12.3,-4.9).closePath();
	this.shape_137.setTransform(18.8,74.4,0.991,0.711);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],0,-12.9,0,13).beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.6,-13.2,8.4,-12.9).curveTo(9.8,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.7,3.6).curveTo(9,4.3,5.8,6.5).curveTo(3.6,8,-2.1,10.6).lineTo(-7.3,13).curveTo(-11,5.1,-12.6,-3.6).closePath();
	this.shape_138.setTransform(13.8,61.7,0.991,0.711);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.4,9.5,-8.7,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.7,-10.2).curveTo(12.2,-0.1,11.4,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.8,10.2,-3.9,10).closePath();
	this.shape_139.setTransform(139.4,46.7,0.991,0.711);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-9.9,-9.1).curveTo(-4.3,-12,-2.6,-12.2).curveTo(-0.6,-12.4,2.2,-10).curveTo(4.7,-7.9,8.6,-2.5).curveTo(10.6,0.2,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_140.setTransform(112.1,87.5,0.991,0.711);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.7,-8.5,4.4,-12).lineTo(10.5,2.3).curveTo(11.7,6.4,10.1,7.7).curveTo(8,9.6,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_141.setTransform(40.1,13,0.991,0.711);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.beginLinearGradientFill(["#705550","#543E3B"],[0,1],-4.2,-10.5,7.6,9.9).beginStroke().moveTo(-0.5,11.7).curveTo(-2.9,11.6,-4.1,9.7).curveTo(-5.6,7.4,-6.7,4).lineTo(-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.6,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.1,7.6,8.8,9).curveTo(7.6,10.1,4.3,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.5,11.7).closePath();
	this.shape_142.setTransform(55.6,9.2,0.991,0.711);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.beginLinearGradientFill(["#8A8AB7","#7878A3"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.7,7.5,-5.3,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.9,6.2,7.8,7.9).curveTo(5.4,9.9,3.1,10).lineTo(2.3,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_143.setTransform(72.5,7.1,0.991,0.711);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.1,-14.1,-0.1,-7.8).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-13).lineTo(11.8,-14.2).lineTo(11.7,12.4).curveTo(7.7,13.4,1.1,14).curveTo(-1.5,14.2,-4.2,14.2).curveTo(-8,14.2,-11.8,13.8).closePath();
	this.shape_144.setTransform(79.7,110,0.991,0.711);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.beginLinearGradientFill(["#543E3B","#705550"],[0,1],-0.5,-13.5,0.9,-8.2).beginStroke().moveTo(-8.3,-10.7).lineTo(8.3,-15.9).lineTo(8.3,9.6).curveTo(0.1,13.8,-8.3,15.9).closePath();
	this.shape_145.setTransform(99.6,107.4,0.991,0.711);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.beginFill("#894D24").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.8,-22.8,0,-22.8).curveTo(19.9,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_146.setTransform(75.6,34.9,0.991,0.711);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.beginFill("#FFF8F3").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.9,44.8,0,44.8).curveTo(-19.8,44.8,-33.9,31.7).closePath();
	this.shape_147.setTransform(75.6,50.5,0.991,0.711);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.beginFill().beginStroke("#F89C1C").setStrokeStyle(0.2,0,0,4).moveTo(-76,-0).curveTo(-76,14.4,-70,27.6).curveTo(-64.3,40.4,-53.7,50.2).curveTo(-43.2,60,-29.6,65.4).curveTo(-15.4,71,0,71).curveTo(15.5,71,29.6,65.4).curveTo(43.2,60,53.8,50.2).curveTo(64.3,40.4,70,27.6).curveTo(76,14.4,76,-0).curveTo(76,-14.5,70,-27.7).curveTo(64.3,-40.4,53.8,-50.2).curveTo(43.2,-60.1,29.6,-65.4).curveTo(15.5,-71,0,-71).curveTo(-15.4,-71,-29.6,-65.4).curveTo(-43.2,-60.1,-53.7,-50.2).curveTo(-64.3,-40.4,-70,-27.7).curveTo(-76,-14.5,-76,-0).closePath();
	this.shape_148.setTransform(75.6,50.5,0.991,0.711);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.beginLinearGradientFill(["#F89C1C","#E5891C"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60,-53.7,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.7,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_149.setTransform(75.6,50.5,0.991,0.711);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.4,-12.7,1.9,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6).curveTo(0.4,13.5,-8.2,17.7).closePath();
	this.shape_150.setTransform(115.9,101.7,0.991,0.711);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],5.9,-10.5,-7.2,-10.5).beginStroke().moveTo(-5.9,-1.2).lineTo(-5.9,-19.7).lineTo(5.8,-2.3).lineTo(5.7,19.7).curveTo(-4.7,4.2,-5.9,-1.2).closePath();
	this.shape_151.setTransform(12.4,84.8,0.991,0.711);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.beginFill("#16281A").beginStroke().moveTo(-2.7,-1.1).lineTo(-2.7,-17.6).lineTo(2.6,-1.1).lineTo(2.6,17.6).curveTo(-0.1,12.4,-2.7,-1.1).closePath();
	this.shape_152.setTransform(4,71.6,0.991,0.711);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.8).lineTo(0.7,-3.1).lineTo(0.7,12.8).curveTo(-1.2,0.9,-0.5,-12.8).closePath();
	this.shape_153.setTransform(0.7,61.2,0.991,0.711);

	this.instance_6 = new lib.Path_23_2();
	this.instance_6.setTransform(75.6,60,0.991,0.817,0,0,0,79.1,76.5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.beginFill("#000000").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_154.setTransform(75.5,35.4,0.993,0.711);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.5).curveTo(3.9,-12.2,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.3,10.3,-3.2).curveTo(9.2,0.3,1.2,11.7).curveTo(-5.9,4.8,-10.8,-3.7).closePath();
	this.shape_155.setTransform(19.7,77.6,0.993,0.711);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7.7,-12.3,4.3,8.5).beginStroke().moveTo(-5.6,11.7).curveTo(-9.8,10.5,-11,7.1).curveTo(-12.1,4.2,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2,-9.5,11.5,-4.3).lineTo(0.9,10.1).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.7).closePath();
	this.shape_156.setTransform(102.2,10.5,0.993,0.711);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],-6.3,-9.5,4.3,8.9).beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9.1,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.7,-11.9,4.3).curveTo(-12,2.1,-10.8,0).curveTo(-9.9,-1.6,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.5,-8,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_157.setTransform(115.5,15.9,0.993,0.711);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0.1).curveTo(-14.3,-1.1,-14.5,-2.7).curveTo(-15,-6.1,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.3).curveTo(-1.1,-13.4,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0.1).curveTo(6.4,7.9,-4.2,13.3).closePath();
	this.shape_158.setTransform(115.4,86.1,0.993,0.711);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],0,-12.4,0,12.5).beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,2).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.3,13.7,-0.6).curveTo(9.1,6.6,3,12.5).closePath();
	this.shape_159.setTransform(126.8,77.2,0.993,0.711);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.5,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.2).curveTo(-2.3,9.4,-11.7,3.8).closePath();
	this.shape_160.setTransform(46.8,91,0.993,0.711);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],0,-14.8,0,14.8).beginStroke().moveTo(-11.4,3.9).lineTo(-3.5,-8.5).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-6.9).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.8,10.3,-11.4,3.9).closePath();
	this.shape_161.setTransform(32.3,83.2,0.993,0.711);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7.5,-8.8,3.1,9.5).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.3,0.1,11.1).curveTo(-3,12.5,-4.4,12.7).lineTo(-4.8,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_162.setTransform(128,23.4,0.993,0.711);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.4,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).curveTo(10.3,-6.8,12.8,-5.7).curveTo(10.2,3.1,5.2,11).closePath();
	this.shape_163.setTransform(135.4,69,0.993,0.711);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-0.7,-10.5,2.3,-8.8).beginStroke().moveTo(-3.8,-1.8).lineTo(3.8,-18.4).lineTo(3.8,-1.4).curveTo(0.9,9.6,-3.8,18.4).closePath();
	this.shape_164.setTransform(144.3,78.2,0.993,0.711);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.beginLinearGradientFill(["#508C74","#61A28A"],[0,1],-0.2,-12.2,2.9,-9).beginStroke().moveTo(-5.3,-4.8).lineTo(5.3,-17.9).lineTo(5.3,2.2).curveTo(0.8,11,-5.3,17.9).closePath();
	this.shape_165.setTransform(135.2,89.7,0.993,0.711);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10,7.5).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(2.1,15.6,-10,7.5).closePath();
	this.shape_166.setTransform(45.1,106.2,0.993,0.711);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.beginLinearGradientFill(["#508C74","#61A28A"],[0,1],0.4,-13.5,-2.6,-8.2).beginStroke().moveTo(-7.2,4.6).lineTo(-7.1,-17.9).lineTo(7.3,-6.9).lineTo(7.3,17.9).curveTo(0.1,13,-7.2,4.6).closePath();
	this.shape_167.setTransform(28,98.8,0.993,0.711);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-33.9,31.7).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.6,47.9,0).curveTo(48,18.5,33.9,31.7).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_168.setTransform(75.5,51,0.993,0.711);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-7,-9.3,5.2,11.8).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.7,-4.5,-10.8).lineTo(9.1,-2.1).curveTo(12.5,0.6,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_169.setTransform(15.7,32.1,0.993,0.711);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.beginLinearGradientFill(["#61A28A","#4E8971"],[0,1],-6.1,-9.2,6,11.7).beginStroke().moveTo(2.4,11.6).curveTo(-0.2,10.5,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.2,-5.8,-1.3,-12).lineTo(9.7,-3.3).lineTo(11.9,-1).curveTo(13.9,1.8,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.6,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,12,4.2,12).curveTo(3.3,12,2.4,11.6).closePath();
	this.shape_170.setTransform(24.3,23.2,0.993,0.711);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-4.3,-6.5,5.9,11.2).beginStroke().moveTo(2.7,11).curveTo(1.6,11,0.4,10.3).lineTo(-1.9,8.8).curveTo(-2.9,8.2,-7.9,4.2).lineTo(-12.7,0.3).curveTo(-5.4,-6.3,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.8).curveTo(11.5,7.7,9.6,9).curveTo(6.6,11,3,11).lineTo(2.7,11).closePath();
	this.shape_171.setTransform(35.6,14.5,0.993,0.711);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.beginFill("#000000").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_172.setTransform(75.5,51,0.993,0.711);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],-2.1,-9.5,0.4,-11.4).beginStroke().moveTo(-6.1,0.3).lineTo(-5.9,-19.1).lineTo(6.1,-3.7).lineTo(6.1,19.1).curveTo(-2.7,8.3,-6.1,0.3).closePath();
	this.shape_173.setTransform(14.9,88.7,0.993,0.711);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.beginLinearGradientFill(["#FBC8D5","#F7A2C8"],[0,1],3.1,-9.3,0.5,-12.9).beginStroke().moveTo(-9.4,-5.9).lineTo(9.4,-19.3).lineTo(9.4,3.5).curveTo(0.7,13.5,-9.4,19.3).closePath();
	this.shape_174.setTransform(120.5,99.9,0.993,0.711);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70.1,-27.7).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_175.setTransform(75.5,51,0.993,0.711);

	this.instance_7 = new lib.Path_23_0();
	this.instance_7.setTransform(75.6,60.5,0.993,0.817,0,0,0,79.2,77.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.3,-8.9,8.9,-7.2).curveTo(9.7,-6.3,10.1,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(4.2,4.2,-9.2,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_176.setTransform(10.2,52.2,0.993,0.71);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.3).curveTo(-6.6,-3.9,-2.7,-7.9).lineTo(0.8,-11.7).curveTo(8.2,-4,12.9,5.1).lineTo(-1.2,10.2).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_177.setTransform(130.7,24.9,0.993,0.71);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.beginFill("#7575A3").beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-6.2,-5.6,0.2,-8).lineTo(6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_178.setTransform(137,35.7,0.993,0.71);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.6).curveTo(-11.6,-6,-10.8,-7.5).curveTo(-9.2,-10.5,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.6).curveTo(9.2,-4,11.8,9.9).curveTo(3.8,11.5,-4.2,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_179.setTransform(79.6,92.7,0.993,0.71);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.beginFill("#7575A3").beginStroke().moveTo(-8,3).curveTo(-9.4,0.5,-10.3,-2.4).curveTo(-11.9,-8.4,-8.7,-10.7).curveTo(-5.7,-12.8,-2.4,-13.1).curveTo(1.6,-13.5,3,-10.6).curveTo(5.1,-6.4,10.8,7.8).curveTo(2.7,11.4,-5.8,13.1).closePath();
	this.shape_180.setTransform(97.1,90.5,0.993,0.71);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.3).curveTo(3.1,10,-0.7,12.5).curveTo(-8,4.5,-12.3,-4.9).closePath();
	this.shape_181.setTransform(18.7,74.3,0.993,0.71);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.beginFill("#7575A3").beginStroke().moveTo(-12.6,-3.7).lineTo(1.4,-9.8).lineTo(4.4,-11.6).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.7).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.3,5.8,6.4).curveTo(2.2,8.9,-7.3,12.9).curveTo(-11,5,-12.6,-3.7).closePath();
	this.shape_182.setTransform(13.6,61.6,0.993,0.71);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.1,-11,6.2).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.8,-11.2,-1.5).curveTo(-9.5,-5.1,-5.2,-6).curveTo(-0.9,-7,9.8,-10.3).curveTo(12.2,-0.4,11.5,9.9).curveTo(5.7,10.3,1.8,10.3).curveTo(-1.8,10.3,-3.9,10).closePath();
	this.shape_183.setTransform(139.5,46.7,0.993,0.71);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3).curveTo(-11.5,-4,-11.9,-5.2).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.3,-12,-2.7,-12.2).curveTo(-0.6,-12.4,2.2,-10).curveTo(6.1,-6.6,12,2.5).curveTo(4.4,8.4,-4.3,12.2).closePath();
	this.shape_184.setTransform(112.1,87.4,0.993,0.71);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-3.5,-8,7,10.2).beginStroke().moveTo(1.7,11.9).curveTo(-1.3,11.5,-5.4,5.8).lineTo(-11,-3.2).curveTo(-4,-8.3,4.4,-11.9).lineTo(10.4,2.4).curveTo(11.6,6.5,10.1,7.8).curveTo(5.4,11.9,2.4,11.9).lineTo(1.7,11.9).closePath();
	this.shape_185.setTransform(40,13,0.993,0.71);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.beginFill("#7575A3").beginStroke().moveTo(-0.4,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.6,4.1).curveTo(-6.9,3.2,-9.1,-1.8).lineTo(-11.2,-6.5).curveTo(-2.5,-10.1,6.8,-11.7).lineTo(10.8,1.3).lineTo(11.2,4.3).curveTo(11.2,7.6,8.9,9).curveTo(7.6,10.2,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.4,11.7).closePath();
	this.shape_186.setTransform(55.5,9.1,0.993,0.71);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.beginLinearGradientFill(["#525254","#353535"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8).curveTo(-4.8,7.5,-5.4,6.2).lineTo(-6.4,3.8).curveTo(-6.8,2.7,-8.6,-3.2).lineTo(-10.3,-8.9).curveTo(0,-10.6,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.5,10).curveTo(-1.1,10,-3.9,8).closePath();
	this.shape_187.setTransform(72.4,7.1,0.993,0.71);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-1.3,-14.8,0,-7.3).beginStroke().moveTo(-12.3,14).lineTo(-12.3,-13).lineTo(11.3,-14.2).lineTo(12.3,12.3).curveTo(8.2,13.2,2.7,13.8).curveTo(-0.4,14.2,-4.8,14.2).curveTo(-8.2,14.2,-12.3,14).closePath();
	this.shape_188.setTransform(80.1,109.9,0.993,0.71);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-0.5,-13.4,0.9,-8.1).beginStroke().moveTo(-8.3,-10.6).lineTo(8.3,-15.9).lineTo(8.3,9.7).curveTo(2.3,13.2,-7.4,15.9).closePath();
	this.shape_189.setTransform(99.6,107.3,0.993,0.71);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.beginFill("#F4F4F4").beginStroke().moveTo(-33.9,31.6).curveTo(-48,18.5,-47.9,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.8,-44.8,-0,-44.8).curveTo(19.9,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.6).curveTo(19.9,44.8,-0,44.8).curveTo(-19.8,44.8,-33.9,31.6).closePath();
	this.shape_190.setTransform(75.5,50.5,0.993,0.71);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.beginLinearGradientFill(["#BFBFBF","#BFBFBF"],[0,1],0,71.1,0,-71).beginStroke().moveTo(-14.3,69.8).curveTo(-22.1,68.4,-29.6,65.4).curveTo(-43.3,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70,-27.6).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.3,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.2,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.2,40.4,53.8,50.2).curveTo(43.2,60.1,29.6,65.4).curveTo(19.7,69.3,9.2,70.5).curveTo(4.7,71,-0,71).curveTo(-7.3,71,-14.3,69.8).closePath();
	this.shape_191.setTransform(75.5,50.5,0.993,0.71);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.1,-7.9).lineTo(8.2,-17.7).lineTo(8.1,6.1).curveTo(0.5,13.1,-8.1,17.7).closePath();
	this.shape_192.setTransform(116,101.7,0.993,0.71);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.beginLinearGradientFill(["#666666","#3C3C3F"],[0,1],-3.5,-8.3,1.1,-12.9).beginStroke().moveTo(-5.8,-1.1).lineTo(-5.8,-19.8).lineTo(5.8,-2.4).lineTo(5.8,19.9).curveTo(-4.4,5.3,-5.8,-1.1).closePath();
	this.shape_193.setTransform(12.2,84.9,0.993,0.71);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.beginLinearGradientFill(["#5E5E8E","#7575A3"],[0,1],-3,-9.4,2.7,-9.4).beginStroke().moveTo(-1.4,4.7).lineTo(-2.7,-17.8).lineTo(2.7,-1.2).lineTo(2.7,17.8).curveTo(0.4,12.1,-1.4,4.7).closePath();
	this.shape_194.setTransform(3.8,71.6,0.993,0.71);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.beginFill("#000000").beginStroke().moveTo(0.1,4.8).curveTo(-0.5,0.3,-0.6,-4.8).lineTo(0.5,4.8).closePath();
	this.shape_195.setTransform(0.6,55.6,0.993,0.71);

	this.instance_8 = new lib.Path_23_4();
	this.instance_8.setTransform(75.6,41.9,0.993,0.818,0,0,0,79.2,76.5);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.beginFill("#F48CB1").beginStroke().moveTo(33.6,-8.4).curveTo(19.7,-21.3,0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-47.9,22).curveTo(-47.9,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(48,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.6,4.5,33.6,-8.4).closePath();
	this.shape_196.setTransform(75.5,35.3,0.993,0.711);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11.7,0,11.8).beginStroke().moveTo(-10.8,-3.7).lineTo(0,-10.4).curveTo(3.9,-12.1,6.2,-11.6).curveTo(7.4,-11.3,9,-9.8).curveTo(11.6,-7.2,10.3,-3.2).curveTo(9.2,0.4,1.2,11.7).curveTo(-6,4.7,-10.8,-3.7).closePath();
	this.shape_197.setTransform(19.7,77.5,0.993,0.711);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-12.5,-5,5.8,5.5).beginStroke().moveTo(-5.6,11.6).curveTo(-9.8,10.5,-11,7).curveTo(-12.1,4.1,-10.9,0.8).curveTo(-10,-1.6,-9.2,-7).lineTo(-8.5,-11.9).curveTo(2.3,-9.4,11.5,-4.3).lineTo(0.9,10).curveTo(-1,11.9,-3.5,11.9).curveTo(-4.5,11.9,-5.6,11.6).closePath();
	this.shape_198.setTransform(102.2,10.4,0.993,0.711);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-4,12).curveTo(-5.7,11.7,-8,9.5).curveTo(-8.1,9,-8.4,8.5).curveTo(-9.1,7.5,-10.4,7.1).curveTo(-11.8,6.6,-11.9,4.3).curveTo(-12,2,-10.8,-0).curveTo(-9.9,-1.7,-5.9,-7).lineTo(-2.2,-12).lineTo(-1.9,-12).curveTo(5.7,-7.9,12,-2.3).lineTo(2.3,8.8).curveTo(0.2,11.8,-1.5,11.8).curveTo(-2.5,12,-3.3,12).lineTo(-4,12).closePath();
	this.shape_199.setTransform(115.5,15.9,0.993,0.711);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-13.2,0,13.3).beginStroke().moveTo(-13.2,-0).curveTo(-14.3,-1,-14.5,-2.7).curveTo(-15,-6,-11,-9.5).curveTo(-6.7,-13.1,-3.3,-13.2).curveTo(-1.1,-13.3,1.6,-11.8).curveTo(4.2,-10.3,14.6,-0).curveTo(6.4,8,-4.2,13.3).closePath();
	this.shape_200.setTransform(115.4,86,0.993,0.711);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-4.7,5.3).curveTo(-7.4,4,-9.9,1.9).curveTo(-14.8,-2.1,-13.5,-5.7).curveTo(-12.3,-9,-9.7,-11).curveTo(-6.6,-13.4,-3.7,-11.8).curveTo(0.5,-9.4,13.7,-0.6).curveTo(9,6.7,3,12.5).closePath();
	this.shape_201.setTransform(126.8,77.1,0.993,0.711);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-12.1,0,12.2).beginStroke().moveTo(-11.7,3.8).lineTo(-4.9,-8.1).curveTo(-4.4,-9.6,-3,-10.8).curveTo(-0.3,-13.1,4,-11.5).curveTo(9,-9.6,10.7,-6.3).curveTo(12.3,-3.2,11.3,1.7).curveTo(10,8.1,8.4,12.1).curveTo(-2.2,9.4,-11.7,3.8).closePath();
	this.shape_202.setTransform(46.8,90.9,0.993,0.711);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.beginFill("#EFEFEF").beginStroke().moveTo(-11.4,3.8).lineTo(-3.5,-8.6).lineTo(-2,-11.6).curveTo(-0.4,-14.6,0.4,-14.8).curveTo(1.9,-15.1,5.5,-12.8).curveTo(9.7,-10.2,10.6,-7).curveTo(11.6,-3.5,11.3,-1.8).curveTo(11.2,-0.8,9.9,2.6).curveTo(8.4,6.5,2.9,14.8).curveTo(-4.9,10.2,-11.4,3.8).closePath();
	this.shape_203.setTransform(32.3,83.1,0.993,0.711);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-9.6,-3.6,10.2,7.8).beginStroke().moveTo(-7.9,11.7).curveTo(-9.5,10.6,-11.2,8.2).curveTo(-12.6,6.2,-12.7,5.4).curveTo(-13.5,1.5,-10.5,-1.5).curveTo(-8.6,-3.3,-4.4,-8.2).lineTo(-0.6,-12.8).curveTo(7.3,-5.8,12.9,3.1).curveTo(4,9.4,0.1,11.1).curveTo(-2.9,12.6,-4.4,12.7).lineTo(-4.9,12.8).curveTo(-6.4,12.8,-7.9,11.7).closePath();
	this.shape_204.setTransform(128,23.3,0.993,0.711);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],0,-11,0,11).beginStroke().moveTo(-9.3,1.6).curveTo(-10.6,1.3,-11.6,0.5).curveTo(-13.6,-1.2,-12.3,-3.7).curveTo(-9.4,-9.1,-8.1,-10.1).curveTo(-6.5,-11.3,-2.7,-10.8).curveTo(0.6,-10.4,7,-8).lineTo(12.8,-5.6).curveTo(10.2,3,5.2,11).closePath();
	this.shape_205.setTransform(135.4,68.9,0.993,0.711);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],-0.7,-10.6,2.3,-8.9).beginStroke().moveTo(-3.9,-1.9).lineTo(3.8,-18.5).lineTo(3.8,-1.2).curveTo(1.1,8.6,-3.8,18.5).closePath();
	this.shape_206.setTransform(144.3,77.7,0.993,0.711);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.beginLinearGradientFill(["#D9D9D9","#EDEDED"],[0,1],-0.3,-12.1,2.9,-9).beginStroke().moveTo(-5.4,-4.8).lineTo(5.3,-17.9).lineTo(5.4,2.3).curveTo(0.9,10.6,-5.4,17.9).closePath();
	this.shape_207.setTransform(135.2,89,0.993,0.711);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],1,-14.1,-2.3,-8.4).beginStroke().moveTo(-10,7.6).lineTo(-10,-17.3).lineTo(10,-8.9).lineTo(10,17.3).curveTo(0.9,15,-10,7.6).closePath();
	this.shape_208.setTransform(45.1,105.6,0.993,0.711);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.beginLinearGradientFill(["#D9D9D9","#EDEDED"],[0,1],0.3,-13.6,-2.7,-8.3).beginStroke().moveTo(-7.2,4.6).lineTo(-7.2,-18).lineTo(7.2,-7).lineTo(7.2,18).curveTo(-3.3,10.3,-7.2,4.6).closePath();
	this.shape_209.setTransform(28,98.2,0.993,0.711);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.beginFill("#FFF5F7").beginStroke().moveTo(-33.9,31.6).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.5,47.9,0).curveTo(48,18.5,33.9,31.6).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.6).closePath();
	this.shape_210.setTransform(75.5,50.9,0.993,0.711);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.9,-3.5,10.2,7.5).beginStroke().moveTo(-2,9).lineTo(-12.1,4.4).curveTo(-9.2,-3.6,-4.5,-10.8).lineTo(9.1,-2).curveTo(12.5,0.7,12,2.6).curveTo(10.4,9.2,7.5,10.4).curveTo(6.6,10.8,5.3,10.8).curveTo(2.6,10.8,-2,9).closePath();
	this.shape_211.setTransform(15.7,32.1,0.993,0.711);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.beginFill("#EFEFEF").beginStroke().moveTo(2.4,11.6).curveTo(-0.3,10.4,-3.1,8.2).curveTo(-3.8,7.6,-8.5,4.6).lineTo(-13.1,1.8).curveTo(-8.1,-5.8,-1.3,-11.9).lineTo(9.7,-3.3).lineTo(11.9,-0.9).curveTo(13.9,1.9,12.7,4.2).lineTo(12.3,5.3).curveTo(11.6,6.7,10.2,8.2).curveTo(8.1,10.5,6.7,11.3).curveTo(5.5,11.9,4.3,11.9).curveTo(3.3,11.9,2.4,11.6).closePath();
	this.shape_212.setTransform(24.3,23.2,0.993,0.711);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.beginLinearGradientFill(["#C5DEE4","#8CD8DD"],[0,1],-8.7,-6.6,12.2,5.5).beginStroke().moveTo(2.7,11).curveTo(1.6,10.9,0.4,10.2).lineTo(-1.9,8.8).curveTo(-2.9,8.1,-7.9,4.1).lineTo(-12.7,0.3).curveTo(-5.4,-6.4,3.7,-11).curveTo(12,-0.1,12.5,1.1).curveTo(13,2.2,12.3,4.7).curveTo(11.5,7.6,9.6,8.9).curveTo(6.7,11,3.3,11).lineTo(2.7,11).closePath();
	this.shape_213.setTransform(35.6,14.5,0.993,0.711);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.beginLinearGradientFill(["#F9BED2","#FDAFDB"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60.1,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_214.setTransform(75.5,50.9,0.993,0.711);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.beginLinearGradientFill(["#ABD0D6","#D8EBEF"],[0,1],-2.2,-9.4,0.3,-11.3).beginStroke().moveTo(-6,0.5).lineTo(-6,-19).lineTo(6,-3.7).lineTo(6,19).curveTo(-0,12.9,-6,0.5).closePath();
	this.shape_215.setTransform(15,88.1,0.993,0.711);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.beginLinearGradientFill(["#D8EBEF","#ABD0D6"],[0,1],3.1,-9.2,0.5,-12.9).beginStroke().moveTo(-9.4,-5.9).lineTo(9.4,-19.2).lineTo(9.4,3.3).curveTo(1.5,12.8,-9.4,19.2).closePath();
	this.shape_216.setTransform(120.5,99.3,0.993,0.711);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.beginFill("#FCEDF0").beginStroke().moveTo(-33.9,31.6).curveTo(-47.9,18.5,-47.9,0).curveTo(-47.9,-18.5,-33.9,-31.7).curveTo(-19.9,-44.8,0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(48,-18.5,47.9,0).curveTo(48,18.5,33.9,31.6).curveTo(19.8,44.8,0,44.8).curveTo(-19.9,44.8,-33.9,31.6).closePath();
	this.shape_217.setTransform(75.5,50.9,0.993,0.711);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.beginFill("#FDDBE1").beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.2,40.4,-70.1,27.7).curveTo(-76,14.5,-76,0).curveTo(-76,-14.4,-70.1,-27.6).curveTo(-64.2,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.5,-71,0,-71).curveTo(15.5,-71,29.5,-65.4).curveTo(43.2,-60.1,53.8,-50.2).curveTo(64.3,-40.4,70,-27.6).curveTo(76,-14.4,76,0).curveTo(76,14.5,70,27.7).curveTo(64.3,40.4,53.8,50.2).curveTo(43.2,60.1,29.5,65.4).curveTo(15.5,71,0,71).curveTo(-15.5,71,-29.6,65.4).closePath();
	this.shape_218.setTransform(75.5,50.9,0.993,0.711);

	this.instance_9 = new lib.Path_23_5();
	this.instance_9.setTransform(75.6,59.6,0.993,0.817,0,0,0,79.2,76);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-9.5,0,9.5).beginStroke().moveTo(-9.9,-9.5).lineTo(3.1,-9.5).curveTo(7.4,-8.9,9,-7.3).curveTo(9.8,-6.4,10.2,-4.3).curveTo(10.8,-0.8,7.3,1.9).curveTo(5.4,3.3,-2,6.6).lineTo(-9.1,9.5).curveTo(-10.9,0.1,-9.9,-9.5).closePath();
	this.shape_219.setTransform(10.3,52.4,0.992,0.711);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-7.2,-7,3.1,10.8).beginStroke().moveTo(-10.8,9.4).curveTo(-13.6,6.3,-12.6,2.8).curveTo(-11.7,-0.2,-8.7,-2.4).curveTo(-5.3,-4.8,0.8,-11.7).curveTo(8.1,-4.2,12.9,5.1).lineTo(-1.2,10.1).curveTo(-2.6,11.1,-4.5,11.5).curveTo(-5.3,11.7,-6.1,11.7).curveTo(-8.8,11.7,-10.8,9.4).closePath();
	this.shape_220.setTransform(130.7,24.9,0.992,0.711);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.beginFill("#4C9377").beginStroke().moveTo(-7.3,9.9).curveTo(-8.8,9.4,-9.5,8.7).curveTo(-10.8,7.6,-11.3,4.6).curveTo(-11.1,4.2,-11.1,3.6).curveTo(-11.1,2.3,-11.9,1.4).curveTo(-12.8,0.2,-11.5,-1.8).curveTo(-10.3,-3.7,-8,-4.8).curveTo(-5.1,-6.2,6.3,-10.2).lineTo(6.6,-10.1).curveTo(10.4,-2.5,12.3,5.2).lineTo(-2.4,9.4).curveTo(-4.6,10.2,-6,10.2).curveTo(-6.8,10.2,-7.3,9.9).closePath();
	this.shape_221.setTransform(136.9,35.7,0.992,0.711);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-11.5,0,11.5).beginStroke().moveTo(-11.8,11.1).lineTo(-11.4,-4.7).lineTo(-10.8,-7.5).curveTo(-9.2,-10.6,-3.8,-11.3).curveTo(1.9,-12,4.8,-10.4).curveTo(6.7,-9.3,8,-6.7).curveTo(9.3,-4.1,11.8,9.9).curveTo(3.8,11.5,-4.3,11.5).curveTo(-8,11.5,-11.8,11.1).closePath();
	this.shape_222.setTransform(79.6,92.8,0.992,0.711);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.beginFill("#4C9377").beginStroke().moveTo(-8,3.1).curveTo(-9.4,0.6,-10.3,-2.4).curveTo(-11.9,-8.3,-8.7,-10.6).curveTo(-5.7,-12.7,-2.4,-13.1).curveTo(1.6,-13.4,3,-10.6).curveTo(5.1,-6.3,10.8,7.8).curveTo(2.9,11.3,-5.8,13.1).closePath();
	this.shape_223.setTransform(97.1,90.5,0.992,0.711);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-12.5,0,12.5).beginStroke().moveTo(-12.3,-4.9).lineTo(0.4,-11.2).lineTo(3.6,-12.4).curveTo(7.2,-13,9.8,-9.4).curveTo(12.7,-5.2,12.2,-1.6).curveTo(11.7,1.8,8,5.4).curveTo(3.1,10,-0.7,12.5).curveTo(-7.9,4.5,-12.3,-4.9).closePath();
	this.shape_224.setTransform(18.8,74.3,0.992,0.711);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.beginFill("#4C9377").beginStroke().moveTo(-12.6,-3.6).lineTo(1.4,-9.8).lineTo(4.4,-11.5).curveTo(7.5,-13.2,8.3,-12.9).curveTo(9.7,-12.4,11.4,-8.6).curveTo(13.3,-4.3,12.1,-1.1).curveTo(10.9,2.2,9.6,3.6).curveTo(9,4.2,5.8,6.5).curveTo(3.6,8,-2.1,10.6).lineTo(-7.3,13).curveTo(-11.1,4.9,-12.6,-3.6).closePath();
	this.shape_225.setTransform(13.7,61.6,0.992,0.711);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-10.2,0,10.3).beginStroke().moveTo(-3.9,10).curveTo(-7.3,9.5,-8.6,8.9).curveTo(-10.2,8.2,-11,6.3).curveTo(-11.7,4.5,-11.6,1.6).curveTo(-11.5,-0.7,-11.2,-1.5).curveTo(-9.4,-5.2,-5.2,-6).curveTo(-0.9,-6.9,9.8,-10.2).curveTo(12.2,-0.4,11.5,10).curveTo(5.9,10.2,2.1,10.2).curveTo(-1.7,10.2,-3.9,10).closePath();
	this.shape_226.setTransform(139.4,46.7,0.992,0.711);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],0,-12.2,0,12.2).beginStroke().moveTo(-10.7,-3.1).curveTo(-11.5,-4,-11.9,-5.3).curveTo(-12.6,-7.7,-10,-9.1).curveTo(-4.4,-12,-2.7,-12.2).curveTo(-0.7,-12.4,2.2,-10).curveTo(6.1,-6.7,12,2.4).curveTo(4.7,8.2,-4.3,12.2).closePath();
	this.shape_227.setTransform(112.1,87.4,0.992,0.711);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-3.5,-8.1,7,10.1).beginStroke().moveTo(1.7,11.9).curveTo(0.1,11.6,-2.1,9.6).curveTo(-3.8,8,-5.4,5.7).lineTo(-11,-3.3).curveTo(-3.9,-8.4,4.4,-12).lineTo(10.4,2.3).curveTo(11.6,6.4,10.1,7.7).curveTo(7.9,9.7,5.9,10.8).curveTo(3.8,12,2.3,12).lineTo(1.7,11.9).closePath();
	this.shape_228.setTransform(40.1,13,0.992,0.711);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.beginFill("#4C9377").beginStroke().moveTo(-0.5,11.7).curveTo(-2.9,11.6,-4.2,9.7).curveTo(-5.7,7.4,-6.7,4).curveTo(-6.9,3.1,-9,-1.8).lineTo(-11.2,-6.5).curveTo(-2.6,-10.2,6.8,-11.7).lineTo(10.8,1.2).lineTo(11.2,4.3).curveTo(11.1,7.6,8.9,9).curveTo(7.6,10.1,4.4,11).curveTo(1.6,11.7,-0.1,11.7).lineTo(-0.5,11.7).closePath();
	this.shape_229.setTransform(55.5,9.1,0.992,0.711);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.beginLinearGradientFill(["#CCCCCC","#A5A5A5"],[0,1],-3.9,-12.5,7.9,8).beginStroke().moveTo(-3.9,8.1).curveTo(-4.8,7.5,-5.4,6.3).lineTo(-6.4,3.9).curveTo(-6.8,2.8,-8.6,-3.1).lineTo(-10.3,-8.8).curveTo(-0.4,-10.5,10.1,-9.7).curveTo(10.4,3.7,10.1,5).curveTo(9.8,6.2,7.7,7.9).curveTo(5.3,9.9,3,10).lineTo(2.2,10).curveTo(-1.2,10,-3.9,8.1).closePath();
	this.shape_230.setTransform(72.5,7.1,0.992,0.711);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.9,-14.8,0.4,-7.4).beginStroke().moveTo(-11.8,13.8).lineTo(-11.8,-13).lineTo(11.8,-14.2).lineTo(11.6,12.4).curveTo(5.4,14.1,-1.7,14.2).lineTo(-4.1,14.2).curveTo(-9.3,14.2,-11.8,13.8).closePath();
	this.shape_231.setTransform(79.7,109.9,0.992,0.711);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.beginLinearGradientFill(["#2F7C62","#3D8F75"],[0.773,1],-0.2,-13.6,1.2,-8.3).beginStroke().moveTo(-8.1,-10.8).lineTo(8.6,-16).lineTo(8.6,9.5).curveTo(0.6,13.7,-8.6,16).closePath();
	this.shape_232.setTransform(99.4,107.4,0.992,0.711);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.beginFill("#25442E").beginStroke().moveTo(33.6,-8.4).curveTo(19.6,-21.3,-0,-21.3).curveTo(-19.6,-21.3,-33.6,-8.4).curveTo(-47.6,4.5,-47.9,22.8).lineTo(-48,22).curveTo(-48,3.5,-33.9,-9.7).curveTo(-19.9,-22.8,-0,-22.8).curveTo(19.8,-22.8,33.9,-9.7).curveTo(47.9,3.5,47.9,22).lineTo(47.9,22.8).curveTo(47.5,4.5,33.6,-8.4).closePath();
	this.shape_233.setTransform(75.5,34.8,0.992,0.711);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.beginFill("#F7F9F8").beginStroke().moveTo(-33.9,31.7).curveTo(-48,18.5,-48,0).curveTo(-48,-18.6,-33.9,-31.7).curveTo(-19.9,-44.8,-0,-44.8).curveTo(19.8,-44.8,33.9,-31.7).curveTo(47.9,-18.6,47.9,0).curveTo(47.9,18.5,33.9,31.7).curveTo(19.8,44.8,-0,44.8).curveTo(-19.9,44.8,-33.9,31.7).closePath();
	this.shape_234.setTransform(75.5,50.5,0.992,0.711);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.beginLinearGradientFill(["#007C38","#345B41"],[0,1],0,-71,0,71.1).beginStroke().moveTo(-29.6,65.4).curveTo(-43.2,60.1,-53.8,50.2).curveTo(-64.3,40.4,-70,27.6).curveTo(-76,14.4,-76,-0).curveTo(-76,-14.5,-70,-27.7).curveTo(-64.3,-40.4,-53.8,-50.2).curveTo(-43.2,-60.1,-29.6,-65.4).curveTo(-15.4,-71,-0,-71).curveTo(15.5,-71,29.6,-65.4).curveTo(43.2,-60.1,53.7,-50.2).curveTo(64.3,-40.4,70,-27.7).curveTo(76,-14.5,76,-0).curveTo(76,14.4,70,27.6).curveTo(64.3,40.4,53.7,50.2).curveTo(43.2,60,29.6,65.4).curveTo(15.5,71,-0,71).curveTo(-15.4,71,-29.6,65.4).closePath();
	this.shape_235.setTransform(75.5,50.5,0.992,0.711);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.beginLinearGradientFill(["#3C3C3F","#666666"],[0,1],-0.5,-12.7,1.8,-8.7).beginStroke().moveTo(-8.2,-7.9).lineTo(8.1,-17.7).lineTo(8.1,6.1).curveTo(-1.8,14.6,-8.2,17.7).closePath();
	this.shape_236.setTransform(116,101.7,0.992,0.711);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.beginLinearGradientFill(["#666666","#3C3C3F"],[0,1],-3.5,-8.3,1.1,-12.9).beginStroke().moveTo(-5.8,-1.1).lineTo(-5.8,-19.8).lineTo(5.8,-2.5).lineTo(5.8,19.8).curveTo(-2,9.1,-5.8,-1.1).closePath();
	this.shape_237.setTransform(12.3,84.9,0.992,0.711);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.beginFill("#16281A").beginStroke().moveTo(-2.7,-2.1).lineTo(-2.7,-17.7).lineTo(2.7,-1.1).lineTo(2.7,17.7).curveTo(-1.7,5.8,-2.7,-2.1).closePath();
	this.shape_238.setTransform(3.9,71.6,0.992,0.711);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.beginFill("#000000").beginStroke().moveTo(-0.5,-12.4).lineTo(0.6,-2.7).lineTo(0.6,12.4).curveTo(-1.1,-0.5,-0.5,-12.4).closePath();
	this.shape_239.setTransform(0.6,60.9,0.992,0.711);

	this.instance_10 = new lib.Path_23_8();
	this.instance_10.setTransform(75.6,60,0.992,0.817,0,0,0,79.2,76.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_22},{t:this.shape_21,p:{scaleX:0.994,scaleY:0.71,y:50.6}},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance_1},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.instance_2},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{scaleX:0.992,scaleY:0.712,x:75.6,y:35.3}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44}]},1).to({state:[{t:this.instance_3},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65}]},1).to({state:[{t:this.instance_4},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86}]},1).to({state:[{t:this.instance_5},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109}]},1).to({state:[{t:this.instance_6},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132}]},1).to({state:[{t:this.instance_7},{t:this.shape_175},{t:this.shape_21,p:{scaleX:0.993,scaleY:0.711,y:51}},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154}]},1).to({state:[{t:this.instance_8},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_58,p:{scaleX:0.993,scaleY:0.71,x:75.5,y:34.8}},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176}]},1).to({state:[{t:this.instance_9},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196}]},1).to({state:[{t:this.instance_10},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,151.6,117.1);


(lib.BetBarChip = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"zero":0});

	// chipvalue
	this.chipVal = new lib.chipVal();
	this.chipVal.setTransform(67.2,52.2,2.306,2.637,0,-1.2,0);

	this.timeline.addTween(cjs.Tween.get(this.chipVal).wait(1));

	// chipBG
	this.colorChip = new lib.chipBg();
	this.colorChip.setTransform(70,49,0.882,1,0,0,0,79.4,49);

	this.timeline.addTween(cjs.Tween.get(this.colorChip).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,133.7,117.1);


(lib.Symbol1copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// txt
	this.betTxtMC = new lib.Symbol2copy15();
	this.betTxtMC.setTransform(37.5,-0.1);

	this.instance = new lib.ddd();
	this.instance.setTransform(-24.7,1.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.betTxtMC}]}).wait(2));

	// button top
	this.instance_1 = new lib.Symbol6copy6();

	this.instance_2 = new lib.Symbol6copy2();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	// button bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#755720").setStrokeStyle(1.5,1,1).moveTo(72.8,-38.5).lineTo(-72.8,-38.5).curveTo(-85.5,-38.5,-85.5,-26.5).lineTo(-85.5,26.5).curveTo(-85.5,38.5,-72.8,38.5).lineTo(72.8,38.5).curveTo(85.5,38.5,85.5,26.5).lineTo(85.5,-26.5).curveTo(85.5,-38.5,72.8,-38.5).closePath();
	this.shape.setTransform(5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginLinearGradientFill(["#B6A153","#FFD76D","#BF994D"],[0,0.506,1],-85.5,0,85.5,0).beginStroke().moveTo(-72.8,38.5).curveTo(-85.5,38.5,-85.5,26.5).lineTo(-85.5,-26.5).curveTo(-85.5,-38.5,-72.8,-38.5).lineTo(72.8,-38.5).curveTo(85.5,-38.5,85.5,-26.5).lineTo(85.5,26.5).curveTo(85.5,38.5,72.8,38.5).closePath();
	this.shape_1.setTransform(5,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("#F8C929").setStrokeStyle(1.5,1,1).moveTo(72.8,-38.5).lineTo(-72.8,-38.5).curveTo(-85.5,-38.5,-85.5,-26.5).lineTo(-85.5,26.5).curveTo(-85.5,38.5,-72.8,38.5).lineTo(72.8,38.5).curveTo(85.5,38.5,85.5,26.5).lineTo(85.5,-26.5).curveTo(85.5,-38.5,72.8,-38.5).closePath();
	this.shape_2.setTransform(5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,-39.5,173,79);


(lib.betbarBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.clear_btn = new lib.Clear();
	this.clear_btn.setTransform(1095.9,38.9,1.2,1.2,0,0,0,42.6,19.5);

	this.rebet_btn = new lib.Symbol1copy();
	this.rebet_btn.setTransform(1210.1,39.6,0.6,0.6);

	this.bet_btn = new lib.Symbol1copy6();
	this.bet_btn.setTransform(975.1,38.6,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bet_btn},{t:this.rebet_btn},{t:this.clear_btn}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(926.3,14.9,338.5,48.3);


// stage content:
(lib.commonAssets = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(51,204,102,0)").beginStroke().moveTo(-74,66).lineTo(-74,-66).lineTo(-58,-66).lineTo(-58,-12).lineTo(74,-12).lineTo(74,66).closePath();
	this.shape.setTransform(248,196.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(814,490.1,148.1,132);

})(commonAssets = commonAssets||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var commonAssets, images, createjs, ss;