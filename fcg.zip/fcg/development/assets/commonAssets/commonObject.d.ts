/// <reference path="..\..\def\createjs\createjs.d.ts" />
declare module CommonDesign {
    export class chipMC extends createjs.MovieClip {}
    export class BetspotChip extends createjs.MovieClip {}
 }

