(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1280,
	height: 720,
	fps: 24,
	color: "#FFFFFF",
	webfonts: {},
	manifest: [
		{src:"images/Bet_Bar_Bg.png", id:"Bet_Bar_Bg"},
		{src:"images/vec_text.png", id:"vec_text"}
	]
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.Bet_Bar_Bg = function() {
	this.initialize(img.Bet_Bar_Bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,77);


(lib.vec_text = function() {
	this.initialize(img.vec_text);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1825,374);


(lib.tie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#009900").setStrokeStyle(2,1,1).moveTo(3.9,-6.5).lineTo(-3.9,6.5);
	this.shape.setTransform(3.9,6.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,9.8,15);


(lib.solidCircle = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{one:0,two:1});

	// txt
	this.txt = new cjs.Text("vv", "bold 12px 'Arial'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 16;
	this.txt.lineWidth = 19;
	this.txt.setTransform(10.4,1.3);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(3));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FF0000").beginStroke().moveTo(-8.3,8.1).curveTo(-11.6,4.6,-11.6,-0).curveTo(-11.6,-4.7,-8.3,-8.3).curveTo(-4.7,-11.6,-0,-11.6).curveTo(4.6,-11.6,8.1,-8.3).curveTo(11.6,-4.7,11.6,-0).curveTo(11.6,4.6,8.1,8.1).curveTo(4.6,11.6,-0,11.6).curveTo(-4.7,11.6,-8.3,8.1).closePath();
	this.shape.setTransform(12.6,12.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#0000FF").beginStroke().moveTo(-8.3,8.1).curveTo(-11.6,4.6,-11.6,-0).curveTo(-11.6,-4.7,-8.3,-8.3).curveTo(-4.7,-11.6,-0,-11.6).curveTo(4.6,-11.6,8.1,-8.3).curveTo(11.6,-4.7,11.6,-0).curveTo(11.6,4.6,8.1,8.1).curveTo(4.6,11.6,-0,11.6).curveTo(-4.7,11.6,-8.3,8.1).closePath();
	this.shape_1.setTransform(12.6,12.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#00CC00").beginStroke().moveTo(-8.3,8.1).curveTo(-11.6,4.6,-11.6,-0).curveTo(-11.6,-4.7,-8.3,-8.3).curveTo(-4.7,-11.6,-0,-11.6).curveTo(4.6,-11.6,8.1,-8.3).curveTo(11.6,-4.7,11.6,-0).curveTo(11.6,4.6,8.1,8.1).curveTo(4.6,11.6,-0,11.6).curveTo(-4.7,11.6,-8.3,8.1).closePath();
	this.shape_2.setTransform(12.6,12.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill().beginStroke("rgba(69,69,69,0.02)").setStrokeStyle(1,1,1).moveTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).lineTo(-12.5,12.5).closePath();
	this.shape_3.setTransform(12.5,12.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("rgba(255,255,255,0.02)").beginStroke().moveTo(-12.5,12.5).lineTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).closePath();
	this.shape_4.setTransform(12.5,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3}]}).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,27,27);


(lib.smallRoad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// smallRoad
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FF0000").beginStroke().moveTo(-3,2.9).curveTo(-4.2,1.8,-4.2,0).curveTo(-4.2,-1.8,-3,-3).curveTo(-1.8,-4.2,0,-4.2).curveTo(1.8,-4.2,2.9,-3).curveTo(4.2,-1.8,4.2,0).curveTo(4.2,1.8,2.9,2.9).curveTo(1.8,4.2,0,4.2).curveTo(-1.8,4.2,-3,2.9).closePath();
	this.shape.setTransform(4.2,4.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#0000FF").beginStroke().moveTo(-3,2.9).curveTo(-4.2,1.8,-4.2,0).curveTo(-4.2,-1.8,-3,-3).curveTo(-1.8,-4.2,0,-4.2).curveTo(1.8,-4.2,2.9,-3).curveTo(4.2,-1.8,4.2,0).curveTo(4.2,1.8,2.9,2.9).curveTo(1.8,4.2,0,4.2).curveTo(-1.8,4.2,-3,2.9).closePath();
	this.shape_1.setTransform(4.2,4.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.4,8.4);


(lib.cockroachRoad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cockroach
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FF0000").beginStroke().moveTo(-5,4).lineTo(2.2,-6).lineTo(4.9,-4).lineTo(-2.2,6).closePath();
	this.shape.setTransform(5,6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#0000FF").beginStroke().moveTo(-5,4).lineTo(2.2,-6).lineTo(4.9,-4).lineTo(-2.2,6).closePath();
	this.shape_1.setTransform(5,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9.9,12);


(lib.checkBox = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"one":0,"two":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#000000").setStrokeStyle(1,1,1).moveTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).lineTo(-12.5,12.5).closePath();
	this.shape.setTransform(12.5,12.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#CCCCCC").beginStroke().moveTo(-12.5,12.5).lineTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).closePath();
	this.shape_1.setTransform(12.5,12.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-12.5,12.5).lineTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).closePath();
	this.shape_2.setTransform(12.5,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,27,27);


(lib.bigEyeBoy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bigEye
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FF0000").setStrokeStyle(3,1,1).moveTo(4,0).curveTo(4,1.7,2.8,2.8).curveTo(1.7,4,0,4).curveTo(-1.6,4,-2.9,2.8).curveTo(-4,1.7,-4,0).curveTo(-4,-1.6,-2.9,-2.9).curveTo(-1.6,-4,0,-4).curveTo(1.7,-4,2.8,-2.9).curveTo(4,-1.6,4,0).closePath();
	this.shape.setTransform(4,4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.8,2.8).curveTo(-4,1.7,-4,-0).curveTo(-4,-1.6,-2.8,-2.8).curveTo(-1.6,-4,-0,-4).curveTo(1.7,-4,2.8,-2.8).curveTo(4,-1.6,4,-0).curveTo(4,1.7,2.8,2.8).curveTo(1.7,4,-0,4).curveTo(-1.6,4,-2.8,2.8).closePath();
	this.shape_1.setTransform(4,4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("#0000FF").setStrokeStyle(3,1,1).moveTo(4,0).curveTo(4,1.7,2.8,2.8).curveTo(1.7,4,0,4).curveTo(-1.6,4,-2.9,2.8).curveTo(-4,1.7,-4,0).curveTo(-4,-1.6,-2.9,-2.9).curveTo(-1.6,-4,0,-4).curveTo(1.7,-4,2.8,-2.9).curveTo(4,-1.6,4,0).closePath();
	this.shape_2.setTransform(4,4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-1.5,11,11);


(lib.greenBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#0000FF").beginStroke().moveTo(-29,22.5).lineTo(-29,-22.5).lineTo(29,-22.5).lineTo(29,22.5).closePath();
	this.shape.setTransform(29,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,58,45);


(lib.redBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FF0000").beginStroke().moveTo(-29,22.5).lineTo(-29,-22.5).lineTo(29,-22.5).lineTo(29,22.5).closePath();
	this.shape.setTransform(30,21.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1,-1,58,45);


(lib.tie_mc_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.tie_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{rout:0,rover:1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-83.4,14.3).lineTo(-85.9,14.1).curveTo(-110.2,12.4,-134.4,9.6).lineTo(-117.4,-17).curveTo(-61,-10.7,1.8,-10.7).curveTo(62.8,-10.7,117.6,-16.6).lineTo(134.5,9.9).curveTo(110.7,12.5,86.1,14.2).lineTo(83.6,14.4).curveTo(43.5,17,0.8,17).curveTo(-42.6,17,-83.4,14.3).closePath();
	this.shape.setTransform(134.5,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-83.4,14.3).lineTo(-85.9,14.1).curveTo(-110.2,12.4,-134.4,9.6).lineTo(-117.4,-17).curveTo(-61,-10.7,1.8,-10.7).curveTo(62.8,-10.7,117.6,-16.6).lineTo(134.5,9.9).curveTo(110.7,12.5,86.1,14.2).lineTo(83.6,14.4).curveTo(43.5,17,0.8,17).curveTo(-42.6,17,-83.4,14.3).closePath();
	this.shape_1.setTransform(134.5,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,268.9,34);


(lib.textMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.vec_text();
	this.instance.setTransform(0,0,0.666,0.666);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1215,249);


(lib.player_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-19.5,21.1).curveTo(-42.8,3.4,-82.4,-44.7).lineTo(-29,-54.1).curveTo(-11.3,-31.5,13.2,-12.3).curveTo(42,10.2,82.4,30.7).lineTo(32.8,54.1).curveTo(3.1,38.2,-19.5,21.1).closePath();
	this.shape.setTransform(82.4,54.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-19.5,21.1).curveTo(-42.8,3.4,-82.4,-44.7).lineTo(-29,-54.1).curveTo(-11.3,-31.5,13.2,-12.3).curveTo(42,10.2,82.4,30.7).lineTo(32.8,54.1).curveTo(3.1,38.2,-19.5,21.1).closePath();
	this.shape_1.setTransform(82.4,54.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,164.9,108.2);


(lib.player_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-39.6,8.4).curveTo(-53.5,2.7,-66.5,-3.2).lineTo(-67.5,-3.6).lineTo(-68.8,-4.2).curveTo(-80.8,-9.7,-91.8,-15.4).lineTo(-100.7,-20).lineTo(-51.1,-43.5).lineTo(-46,-40.9).lineTo(-44.1,-40).lineTo(-41.9,-39).curveTo(-29.5,-33,-16.2,-27.1).curveTo(38.7,-3.3,100.7,13.1).lineTo(65.1,43.5).curveTo(10,28.7,-39.6,8.4).closePath();
	this.shape.setTransform(100.7,43.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-39.6,8.4).curveTo(-53.5,2.7,-66.5,-3.2).lineTo(-67.5,-3.6).lineTo(-68.8,-4.2).curveTo(-80.8,-9.7,-91.8,-15.4).lineTo(-100.7,-20).lineTo(-51.1,-43.5).lineTo(-46,-40.9).lineTo(-44.1,-40).lineTo(-41.9,-39).curveTo(-29.5,-33,-16.2,-27.1).curveTo(38.7,-3.3,100.7,13.1).lineTo(65.1,43.5).curveTo(10,28.7,-39.6,8.4).closePath();
	this.shape_1.setTransform(100.7,43.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,201.4,87);


(lib.player_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-83.6,4.8).lineTo(-86.3,4.1).lineTo(-103.3,-0.1).lineTo(-112.4,-2.5).lineTo(-76.8,-32.9).lineTo(-70.2,-31.2).lineTo(-67.7,-30.5).curveTo(16.1,-9.3,112.4,-1.3).lineTo(97.6,32.9).curveTo(0.9,24.9,-83.6,4.8).closePath();
	this.shape.setTransform(112.4,32.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-83.6,4.8).lineTo(-86.3,4.1).lineTo(-103.3,-0.1).lineTo(-112.4,-2.5).lineTo(-76.8,-32.9).lineTo(-70.2,-31.2).lineTo(-67.7,-30.5).curveTo(16.1,-9.3,112.4,-1.3).lineTo(97.6,32.9).curveTo(0.9,24.9,-83.6,4.8).closePath();
	this.shape_1.setTransform(112.4,32.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,224.9,65.8);


(lib.player_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-114,17.2).lineTo(-116.7,17.1).lineTo(-125.9,16.4).lineTo(-142,15.2).lineTo(-127.2,-19).lineTo(-111.4,-17.8).lineTo(-108.9,-17.6).curveTo(-60.1,-14.3,-8.2,-14.3).curveTo(51.4,-14.3,106.8,-18.7).lineTo(109.4,-18.9).lineTo(127.1,-20.5).lineTo(142,13.6).lineTo(124,15.2).lineTo(115.4,15.9).lineTo(112.7,16.1).curveTo(54.2,20.5,-8.8,20.5).curveTo(-63,20.5,-114,17.2).closePath();
	this.shape.setTransform(142,20.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-114,17.2).lineTo(-116.7,17.1).lineTo(-125.9,16.4).lineTo(-142,15.2).lineTo(-127.2,-19).lineTo(-111.4,-17.8).lineTo(-108.9,-17.6).curveTo(-60.1,-14.3,-8.2,-14.3).curveTo(51.4,-14.3,106.8,-18.7).lineTo(109.4,-18.9).lineTo(127.1,-20.5).lineTo(142,13.6).lineTo(124,15.2).lineTo(115.4,15.9).lineTo(112.7,16.1).curveTo(54.2,20.5,-8.8,20.5).curveTo(-63,20.5,-114,17.2).closePath();
	this.shape_1.setTransform(142,20.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,284.1,41);


(lib.player_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-108.8,-0.7).curveTo(-15.2,-9.6,66.1,-31.3).lineTo(68.7,-32).lineTo(73.6,-33.4).lineTo(108.8,-3.2).lineTo(101.3,-1.1).curveTo(93.3,1.1,85.1,3.1).lineTo(82.4,3.8).curveTo(0.2,24.5,-93.9,33.4).closePath();
	this.shape.setTransform(108.8,33.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-108.8,-0.7).curveTo(-15.2,-9.6,66.1,-31.3).lineTo(68.7,-32).lineTo(73.6,-33.4).lineTo(108.8,-3.2).lineTo(101.3,-1.1).curveTo(93.3,1.1,85.1,3.1).lineTo(82.4,3.8).curveTo(0.2,24.5,-93.9,33.4).closePath();
	this.shape_1.setTransform(108.8,33.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,217.6,66.8);


(lib.player_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-96.8,13).curveTo(-40.2,-2.6,10.5,-24.6).curveTo(27.6,-32,43,-39.8).lineTo(45.2,-40.8).lineTo(49.8,-43.2).lineTo(96.8,-19.6).lineTo(92.5,-17.1).curveTo(81.4,-10.8,69.7,-5.2).lineTo(67.4,-4.2).curveTo(51,3.5,33,10.9).curveTo(-12.1,29.3,-61.7,43.2).closePath();
	this.shape.setTransform(96.8,43.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-96.8,13).curveTo(-40.2,-2.6,10.5,-24.6).curveTo(27.6,-32,43,-39.8).lineTo(45.2,-40.8).lineTo(49.8,-43.2).lineTo(96.8,-19.6).lineTo(92.5,-17.1).curveTo(81.4,-10.8,69.7,-5.2).lineTo(67.4,-4.2).curveTo(51,3.5,33,10.9).curveTo(-12.1,29.3,-61.7,43.2).closePath();
	this.shape_1.setTransform(96.8,43.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,193.7,86.5);


(lib.player_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-78,30.3).curveTo(-5.2,-7.4,29.9,-53.9).lineTo(78,-45.4).curveTo(31.8,16.9,-31,53.9).closePath();
	this.shape.setTransform(78,53.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-78,30.3).curveTo(-5.2,-7.4,29.9,-53.9).lineTo(78,-45.4).curveTo(31.8,16.9,-31,53.9).closePath();
	this.shape_1.setTransform(78,53.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,156.1,107.9);


(lib.mc_plus_3_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-85.2,26.1).lineTo(-76.1,22.5).curveTo(-0.9,-7.9,29.9,-46.5).lineTo(85.2,-36.7).curveTo(81.6,-32.2,79.2,-29.5).lineTo(77.7,-27.9).curveTo(69.9,-19.6,60.2,-11.6).lineTo(58.4,-10).curveTo(48.3,-1.9,36.4,5.8).lineTo(34.4,7.1).curveTo(25,13,14.6,18.7).lineTo(12.8,19.7).curveTo(4.2,24.4,-5.3,29).lineTo(-7.5,30).curveTo(-18.8,35.4,-31.1,40.6).lineTo(-31.8,40.8).lineTo(-43.1,45.4).lineTo(-45.8,46.5).closePath();
	this.shape.setTransform(85.2,46.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-85.2,26.1).lineTo(-76.1,22.5).curveTo(-0.9,-7.9,29.9,-46.5).lineTo(85.2,-36.7).curveTo(81.6,-32.2,79.2,-29.5).lineTo(77.7,-27.9).curveTo(69.9,-19.6,60.2,-11.6).lineTo(58.4,-10).curveTo(48.3,-1.9,36.4,5.8).lineTo(34.4,7.1).curveTo(25,13,14.6,18.7).lineTo(12.8,19.7).curveTo(4.2,24.4,-5.3,29).lineTo(-7.5,30).curveTo(-18.8,35.4,-31.1,40.6).lineTo(-31.8,40.8).lineTo(-43.1,45.4).lineTo(-45.8,46.5).closePath();
	this.shape_1.setTransform(85.2,46.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.4,93);


(lib.mc_plus_2_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_plus_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(54,29.2).lineTo(53.2,29.2).curveTo(15.5,23.3,-19.5,14.7).lineTo(-22.1,14.1).curveTo(-68.1,2.8,-109.3,-13.4).lineTo(-69.3,-34.3).curveTo(9.9,-3.5,109.3,7.6).lineTo(92.3,34.3).curveTo(73.1,32.1,54,29.2).closePath();
	this.shape.setTransform(109.3,34.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(54,29.2).lineTo(53.2,29.2).curveTo(15.5,23.3,-19.5,14.7).lineTo(-22.1,14.1).curveTo(-68.1,2.8,-109.3,-13.4).lineTo(-69.3,-34.3).curveTo(9.9,-3.5,109.3,7.6).lineTo(92.3,34.3).curveTo(73.1,32.1,54,29.2).closePath();
	this.shape_1.setTransform(109.3,34.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,218.7,68.6);


(lib.mc_minus_3_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-109.8,7.5).curveTo(-9.6,-3.3,70.3,-34).lineTo(109.8,-13.6).curveTo(68.1,2.6,21.6,13.9).lineTo(19,14.6).curveTo(-15.6,23,-56.4,29.3).lineTo(-57.2,29.4).lineTo(-57.3,29.4).curveTo(-74.8,32,-92.9,34.1).closePath();
	this.shape.setTransform(109.8,34.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-109.8,7.5).curveTo(-9.6,-3.3,70.3,-34).lineTo(109.8,-13.6).curveTo(68.1,2.6,21.6,13.9).lineTo(19,14.6).curveTo(-15.6,23,-56.4,29.3).lineTo(-57.2,29.4).lineTo(-57.3,29.4).curveTo(-74.8,32,-92.9,34.1).closePath();
	this.shape_1.setTransform(109.8,34.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,219.5,68.1);


(lib.mc_minus_2_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_minus_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(42.8,45.9).lineTo(35.5,43).lineTo(34.8,42.7).lineTo(34.7,42.7).lineTo(34.3,42.5).curveTo(17.9,35.5,6.3,30).lineTo(4,28.9).curveTo(-4.6,24.7,-12.5,20.4).lineTo(-14.3,19.5).curveTo(-24.8,13.7,-34.1,7.8).lineTo(-36.1,6.5).curveTo(-48.2,-1.3,-58.2,-9.5).lineTo(-60.1,-11).curveTo(-65,-15.1,-69.5,-19.3).lineTo(-71.1,-20.8).lineTo(-76.8,-26.6).lineTo(-78.3,-28.2).curveTo(-81.4,-31.5,-85.6,-36.8).lineTo(-28.4,-47).curveTo(2.1,-7.6,78.4,23.2).lineTo(85.6,26.1).lineTo(45.6,47).lineTo(42.8,45.9).closePath();
	this.shape.setTransform(85.6,47);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(42.8,45.9).lineTo(35.5,43).lineTo(34.8,42.7).lineTo(34.7,42.7).lineTo(34.3,42.5).curveTo(17.9,35.5,6.3,30).lineTo(4,28.9).curveTo(-4.6,24.7,-12.5,20.4).lineTo(-14.3,19.5).curveTo(-24.8,13.7,-34.1,7.8).lineTo(-36.1,6.5).curveTo(-48.2,-1.3,-58.2,-9.5).lineTo(-60.1,-11).curveTo(-65,-15.1,-69.5,-19.3).lineTo(-71.1,-20.8).lineTo(-76.8,-26.6).lineTo(-78.3,-28.2).curveTo(-81.4,-31.5,-85.6,-36.8).lineTo(-28.4,-47).curveTo(2.1,-7.6,78.4,23.2).lineTo(85.6,26.1).lineTo(45.6,47).lineTo(42.8,45.9).closePath();
	this.shape_1.setTransform(85.6,47);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,171.3,94);


(lib.banker_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-37.6,5).curveTo(-62.2,-14.2,-79.8,-36.8).lineTo(-16.3,-48).curveTo(-2.3,-30.1,16.6,-14.6).lineTo(21.8,-10.7).curveTo(33.9,-1.3,48.5,7.7).curveTo(63,16.7,79.8,25.2).lineTo(31.6,48).curveTo(-8.9,27.6,-37.6,5).closePath();
	this.shape.setTransform(79.9,48);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-37.6,5).curveTo(-62.2,-14.2,-79.8,-36.8).lineTo(-16.3,-48).curveTo(-2.3,-30.1,16.6,-14.6).lineTo(21.8,-10.7).curveTo(33.9,-1.3,48.5,7.7).curveTo(63,16.7,79.8,25.2).lineTo(31.6,48).curveTo(-8.9,27.6,-37.6,5).closePath();
	this.shape_1.setTransform(79.9,48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,159.7,96);


(lib.banker_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-57.6,-0.6).curveTo(-71,-6.4,-83.4,-12.4).lineTo(-85.5,-13.4).lineTo(-87.4,-14.3).lineTo(-92.5,-16.9).lineTo(-44.2,-39.7).lineTo(-39.7,-37.4).lineTo(-39.1,-37.1).lineTo(-36.9,-36).curveTo(-30.4,-32.8,-23.4,-29.7).lineTo(-11.5,-24.4).lineTo(-9,-23.3).lineTo(-7.9,-22.9).lineTo(2.1,-18.7).curveTo(45,-1.3,92.5,11.3).lineTo(59.3,39.7).curveTo(-2.7,23.3,-57.6,-0.6).closePath();
	this.shape.setTransform(92.5,39.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-57.6,-0.6).curveTo(-71,-6.4,-83.4,-12.4).lineTo(-85.5,-13.4).lineTo(-87.4,-14.3).lineTo(-92.5,-16.9).lineTo(-44.2,-39.7).lineTo(-39.7,-37.4).lineTo(-39.1,-37.1).lineTo(-36.9,-36).curveTo(-30.4,-32.8,-23.4,-29.7).lineTo(-11.5,-24.4).lineTo(-9,-23.3).lineTo(-7.9,-22.9).lineTo(2.1,-18.7).curveTo(45,-1.3,92.5,11.3).lineTo(59.3,39.7).curveTo(-2.7,23.3,-57.6,-0.6).closePath();
	this.shape_1.setTransform(92.5,39.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,185.1,79.4);


(lib.banker_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-92.3,0.8).lineTo(-94.9,0.1).lineTo(-101.5,-1.6).lineTo(-68.2,-30).lineTo(-61.7,-28.3).lineTo(-59.6,-27.7).lineTo(-59.1,-27.6).curveTo(-21.7,-18.1,18.6,-11.6).lineTo(21.3,-11.2).curveTo(41.8,-7.9,63.1,-5.4).curveTo(82,-3.1,101.5,-1.5).lineTo(87.8,30).curveTo(-8.6,22,-92.3,0.8).closePath();
	this.shape.setTransform(101.5,30);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-92.3,0.8).lineTo(-94.9,0.1).lineTo(-101.5,-1.6).lineTo(-68.2,-30).lineTo(-61.7,-28.3).lineTo(-59.6,-27.7).lineTo(-59.1,-27.6).curveTo(-21.7,-18.1,18.6,-11.6).lineTo(21.3,-11.2).curveTo(41.8,-7.9,63.1,-5.4).curveTo(82,-3.1,101.5,-1.5).lineTo(87.8,30).curveTo(-8.6,22,-92.3,0.8).closePath();
	this.shape_1.setTransform(101.5,30);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,203,60);


(lib.banker_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-108.8,14.9).lineTo(-111.4,14.7).lineTo(-127.2,13.6).lineTo(-113.5,-17.9).lineTo(-98.1,-16.7).lineTo(-98,-16.7).lineTo(-95.4,-16.5).curveTo(-49.9,-13.4,-1.3,-13.3).curveTo(47.9,-13.4,93.9,-16.6).lineTo(96.5,-16.8).curveTo(105.3,-17.4,114,-18.2).lineTo(127.2,12).lineTo(109.4,13.7).lineTo(106.9,13.8).curveTo(51.4,18.2,-8.2,18.2).curveTo(-60.1,18.2,-108.8,14.9).closePath();
	this.shape.setTransform(127.2,18.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-108.8,14.9).lineTo(-111.4,14.7).lineTo(-127.2,13.6).lineTo(-113.5,-17.9).lineTo(-98.1,-16.7).lineTo(-98,-16.7).lineTo(-95.4,-16.5).curveTo(-49.9,-13.4,-1.3,-13.3).curveTo(47.9,-13.4,93.9,-16.6).lineTo(96.5,-16.8).curveTo(105.3,-17.4,114,-18.2).lineTo(127.2,12).lineTo(109.4,13.7).lineTo(106.9,13.8).curveTo(51.4,18.2,-8.2,18.2).curveTo(-60.1,18.2,-108.8,14.9).closePath();
	this.shape_1.setTransform(127.2,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,254.4,36.4);


(lib.banker_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-97.8,-1.1).curveTo(-79.7,-2.7,-62.1,-4.8).curveTo(-40.3,-7.4,-19.4,-10.8).lineTo(-16.8,-11.2).curveTo(23.1,-17.7,60.2,-27.1).lineTo(60.9,-27.3).lineTo(62.8,-27.8).lineTo(67.9,-29.1).lineTo(97.8,-3.5).lineTo(92.8,-2.2).lineTo(90.3,-1.5).curveTo(9,20.3,-84.6,29.1).closePath();
	this.shape.setTransform(97.8,29.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-97.8,-1.1).curveTo(-79.7,-2.7,-62.1,-4.8).curveTo(-40.3,-7.4,-19.4,-10.8).lineTo(-16.8,-11.2).curveTo(23.1,-17.7,60.2,-27.1).lineTo(60.9,-27.3).lineTo(62.8,-27.8).lineTo(67.9,-29.1).lineTo(97.8,-3.5).lineTo(92.8,-2.2).lineTo(90.3,-1.5).curveTo(9,20.3,-84.6,29.1).closePath();
	this.shape_1.setTransform(97.8,29.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,195.6,58.3);


(lib.banker_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-88.3,12.5).curveTo(-39.7,-0.3,3.9,-18).lineTo(6.5,-19.1).lineTo(13,-21.8).lineTo(14.7,-22.5).lineTo(17.5,-23.7).curveTo(30.1,-29.3,41.8,-34.9).lineTo(44,-36).lineTo(44.3,-36.1).lineTo(48.3,-38.1).lineTo(88.3,-18.1).lineTo(83.6,-15.7).lineTo(81.5,-14.7).curveTo(66,-6.9,49,0.5).curveTo(-1.7,22.5,-58.4,38.1).closePath();
	this.shape.setTransform(88.3,38.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-88.3,12.5).curveTo(-39.7,-0.3,3.9,-18).lineTo(6.5,-19.1).lineTo(13,-21.8).lineTo(14.7,-22.5).lineTo(17.5,-23.7).curveTo(30.1,-29.3,41.8,-34.9).lineTo(44,-36).lineTo(44.3,-36.1).lineTo(48.3,-38.1).lineTo(88.3,-18.1).lineTo(83.6,-15.7).lineTo(81.5,-14.7).curveTo(66,-6.9,49,0.5).curveTo(-1.7,22.5,-58.4,38.1).closePath();
	this.shape_1.setTransform(88.3,38.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,176.6,76.3);


(lib.banker_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"rout":0,"rover":1});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-73.9,26.6).curveTo(-9.2,-6.1,23.1,-46.6).lineTo(73.9,-37.6).curveTo(38.9,8.9,-34,46.6).closePath();
	this.shape.setTransform(73.9,46.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("rgba(102,255,0,0.4)").beginStroke().moveTo(-73.9,26.6).curveTo(-9.2,-6.1,23.1,-46.6).lineTo(73.9,-37.6).curveTo(38.9,8.9,-34,46.6).closePath();
	this.shape_1.setTransform(73.9,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,147.9,93.2);


(lib.betbarMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.balanceVal = new cjs.Text("", "bold 12px 'Arial'", "#FFFFFF");
	this.balanceVal.name = "balanceVal";
	this.balanceVal.lineHeight = 16;
	this.balanceVal.lineWidth = 59;
	this.balanceVal.setTransform(216,43.6);

	this.betlimitVal = new cjs.Text("", "bold 12px 'Arial'", "#FFFFFF");
	this.betlimitVal.name = "betlimitVal";
	this.betlimitVal.lineHeight = 16;
	this.betlimitVal.lineWidth = 55;
	this.betlimitVal.setTransform(220,20.3);

	this.betAmountVal = new cjs.Text("", "bold 12px 'Arial'", "#FFFFFF");
	this.betAmountVal.name = "betAmountVal";
	this.betAmountVal.lineHeight = 16;
	this.betAmountVal.lineWidth = 48;
	this.betAmountVal.setTransform(97,43.6);

	this.dealerVal = new cjs.Text("", "bold 12px 'Arial'", "#FFFFFF");
	this.dealerVal.name = "dealerVal";
	this.dealerVal.lineHeight = 16;
	this.dealerVal.lineWidth = 75;
	this.dealerVal.setTransform(70.5,19.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dealerVal},{t:this.betAmountVal},{t:this.betlimitVal},{t:this.balanceVal}]}).wait(1));

	// Layer 1
	this.balanceTxt = new cjs.Text("Balance :", "bold 12px 'Arial'", "#FFFFFF");
	this.balanceTxt.name = "balanceTxt";
	this.balanceTxt.lineHeight = 16;
	this.balanceTxt.lineWidth = 56;
	this.balanceTxt.setTransform(156,42.6);

	this.betLimitTxt = new cjs.Text("Bet Limit :", "bold 12px 'Arial'", "#FFFFFF");
	this.betLimitTxt.name = "betLimitTxt";
	this.betLimitTxt.lineHeight = 16;
	this.betLimitTxt.lineWidth = 63;
	this.betLimitTxt.setTransform(156,19.3);

	this.betAmountTxt = new cjs.Text("Bet Amount :", "bold 12px 'Arial'", "#FFFFFF");
	this.betAmountTxt.name = "betAmountTxt";
	this.betAmountTxt.textAlign = "center";
	this.betAmountTxt.lineHeight = 16;
	this.betAmountTxt.lineWidth = 83;
	this.betAmountTxt.setTransform(55,42.6);

	this.dealerTxt = new cjs.Text("Dealer :", "bold 12px 'Arial'", "#FFFFFF");
	this.dealerTxt.name = "dealerTxt";
	this.dealerTxt.textAlign = "center";
	this.dealerTxt.lineHeight = 16;
	this.dealerTxt.lineWidth = 54;
	this.dealerTxt.setTransform(39.5,19.3);

	this.instance = new lib.Bet_Bar_Bg();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.dealerTxt},{t:this.betAmountTxt},{t:this.betLimitTxt},{t:this.balanceTxt}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1280,77);


(lib.bigRoad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tie
	this.tie = new lib.tie();
	this.tie.setTransform(16.9,14.5,1,1,0,0,0,3.9,6.5);

	this.timeline.addTween(cjs.Tween.get(this.tie).wait(2));

	// circle
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FF0000").setStrokeStyle(2,1,1).moveTo(10.6,-0).curveTo(10.6,4,7.5,6.8).curveTo(4.4,9.7,0.1,9.7).curveTo(-4.4,9.7,-7.5,6.8).curveTo(-10.6,4,-10.6,-0).curveTo(-10.6,-4.1,-7.5,-6.9).curveTo(-4.4,-9.7,0.1,-9.7).curveTo(4.4,-9.7,7.5,-6.9).curveTo(10.6,-4.1,10.6,-0).closePath();
	this.shape.setTransform(12.6,12.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill().beginStroke("#0000FF").setStrokeStyle(2,1,1).moveTo(10.6,-0).curveTo(10.6,4,7.5,6.8).curveTo(4.4,9.7,0.1,9.7).curveTo(-4.4,9.7,-7.5,6.8).curveTo(-10.6,4,-10.6,-0).curveTo(-10.6,-4.1,-7.5,-6.9).curveTo(-4.4,-9.7,0.1,-9.7).curveTo(4.4,-9.7,7.5,-6.9).curveTo(10.6,-4.1,10.6,-0).closePath();
	this.shape_1.setTransform(12.6,12.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("rgba(0,0,0,0.02)").setStrokeStyle(1,1,1).moveTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).lineTo(-12.5,12.5).closePath();
	this.shape_2.setTransform(12.5,12.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("rgba(0,0,0,0.02)").beginStroke().moveTo(-12.5,12.5).lineTo(-12.5,-12.5).lineTo(12.5,-12.5).lineTo(12.5,12.5).closePath();
	this.shape_3.setTransform(12.5,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,27,27);


(lib.bgMC = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.mc_minus_2_6 = new lib.mc_minus_2_6();
	this.mc_minus_2_6.setTransform(163.8,431);

	this.mc_minus_2_7 = new lib.mc_minus_2_7();
	this.mc_minus_2_7.setTransform(150,416.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_minus_2_7},{t:this.mc_minus_2_6}]}).wait(1));

	// betspot_sideNumber
	this.mc_minus_3_1 = new lib.mc_minus_3_1();
	this.mc_minus_3_1.setTransform(983,502);

	this.mc_minus_3_2 = new lib.mc_minus_3_2();
	this.mc_minus_3_2.setTransform(954,511);

	this.mc_minus_3_3 = new lib.mc_minus_3_3();
	this.mc_minus_3_3.setTransform(925,521);

	this.mc_minus_3_4 = new lib.mc_minus_3_4();
	this.mc_minus_3_4.setTransform(893,529);

	this.mc_minus_3_5 = new lib.mc_minus_3_5();
	this.mc_minus_3_5.setTransform(863,535);

	this.mc_minus_3_6 = new lib.mc_minus_3_6();
	this.mc_minus_3_6.setTransform(832,541);

	this.mc_minus_3_7 = new lib.mc_minus_3_7();
	this.mc_minus_3_7.setTransform(800,546);

	this.mc_plus_3_7 = new lib.mc_plus_3_7();
	this.mc_plus_3_7.setTransform(1011.5,491.1);

	this.mc_plus_3_6 = new lib.mc_plus_3_6();
	this.mc_plus_3_6.setTransform(1035,480);

	this.mc_plus_3_5 = new lib.mc_plus_3_5();
	this.mc_plus_3_5.setTransform(1056,470);

	this.mc_plus_3_4 = new lib.mc_plus_3_4();
	this.mc_plus_3_4.setTransform(1075.8,459.3);

	this.mc_plus_3_3 = new lib.mc_plus_3_3();
	this.mc_plus_3_3.setTransform(1097,445);

	this.mc_plus_3_2 = new lib.mc_plus_3_2();
	this.mc_plus_3_2.setTransform(1114.2,431);

	this.mc_plus_3_1 = new lib.mc_plus_3_1();
	this.mc_plus_3_1.setTransform(1130.5,415.5);

	this.tie_mc_7 = new lib.tie_mc_7();
	this.tie_mc_7.setTransform(514.1,548.9);

	this.tie_mc_6 = new lib.tie_mc_6();
	this.tie_mc_6.setTransform(553,551.9);

	this.tie_mc_5 = new lib.tie_mc_5();
	this.tie_mc_5.setTransform(593,555);

	this.tie_mc_4 = new lib.tie_mc_4();
	this.tie_mc_4.setTransform(641.8,555.8);

	this.tie_mc_3 = new lib.tie_mc_3();
	this.tie_mc_3.setTransform(688.9,554.9);

	this.tie_mc_2 = new lib.tie_mc_2();
	this.tie_mc_2.setTransform(728,552.7);

	this.tie_mc_1 = new lib.tie_mc_1();
	this.tie_mc_1.setTransform(767.5,548.9);

	this.mc_plus_2_7 = new lib.mc_plus_2_7();
	this.mc_plus_2_7.setTransform(297.2,502.2);

	this.mc_plus_2_6 = new lib.mc_plus_2_6();
	this.mc_plus_2_6.setTransform(324.9,511.1);

	this.mc_plus_2_5 = new lib.mc_plus_2_5();
	this.mc_plus_2_5.setTransform(353,521.3);

	this.mc_plus_2_4 = new lib.mc_plus_2_4();
	this.mc_plus_2_4.setTransform(384.5,529.3);

	this.mc_plus_2_3 = new lib.mc_plus_2_3();
	this.mc_plus_2_3.setTransform(415.8,535.9);

	this.mc_plus_2_2 = new lib.mc_plus_2_2();
	this.mc_plus_2_2.setTransform(448.9,541.1);

	this.mc_plus_2_1 = new lib.mc_plus_2_1();
	this.mc_plus_2_1.setTransform(480,545.5);

	this.mc_minus_2_5 = new lib.mc_minus_2_5();
	this.mc_minus_2_5.setTransform(180,445);

	this.mc_minus_2_4 = new lib.mc_minus_2_4();
	this.mc_minus_2_4.setTransform(203.5,460);

	this.mc_minus_2_3 = new lib.mc_minus_2_3();
	this.mc_minus_2_3.setTransform(224,470.5);

	this.mc_minus_2_2 = new lib.mc_minus_2_2();
	this.mc_minus_2_2.setTransform(246.6,480.2);

	this.mc_minus_2_1 = new lib.mc_minus_2_1();
	this.mc_minus_2_1.setTransform(266.9,491.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_minus_2_1},{t:this.mc_minus_2_2},{t:this.mc_minus_2_3},{t:this.mc_minus_2_4},{t:this.mc_minus_2_5},{t:this.mc_plus_2_1},{t:this.mc_plus_2_2},{t:this.mc_plus_2_3},{t:this.mc_plus_2_4},{t:this.mc_plus_2_5},{t:this.mc_plus_2_6},{t:this.mc_plus_2_7},{t:this.tie_mc_1},{t:this.tie_mc_2},{t:this.tie_mc_3},{t:this.tie_mc_4},{t:this.tie_mc_5},{t:this.tie_mc_6},{t:this.tie_mc_7},{t:this.mc_plus_3_1},{t:this.mc_plus_3_2},{t:this.mc_plus_3_3},{t:this.mc_plus_3_4},{t:this.mc_plus_3_5},{t:this.mc_plus_3_6},{t:this.mc_plus_3_7},{t:this.mc_minus_3_7},{t:this.mc_minus_3_6},{t:this.mc_minus_3_5},{t:this.mc_minus_3_4},{t:this.mc_minus_3_3},{t:this.mc_minus_3_2},{t:this.mc_minus_3_1}]}).wait(1));

	// lines
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("rgba(255,255,255,0.502)").setStrokeStyle(2.8,1,1).moveTo(298,-85.3).curveTo(302.5,-87.1,307.1,-88.9).curveTo(382.3,-119.3,413.1,-157.9).lineTo(468.4,-148.1).curveTo(464.8,-143.6,462.4,-140.9).curveTo(461.6,-140.1,460.9,-139.3).curveTo(453.1,-131,443.5,-123).curveTo(442.5,-122.2,441.5,-121.4).curveTo(431.5,-113.3,419.5,-105.6).curveTo(418.5,-105,417.6,-104.3).curveTo(408.3,-98.4,397.8,-92.7).curveTo(397,-92.2,396,-91.7).curveTo(387.3,-87,377.9,-82.4).curveTo(376.8,-81.9,375.7,-81.4).curveTo(364.4,-76,352,-70.8).curveTo(351.8,-70.7,351.4,-70.6).curveTo(344.1,-67.6,340.1,-66).curveTo(338.8,-65.5,337.4,-64.9).curveTo(295.8,-48.7,249.3,-37.3).curveTo(248,-37,246.7,-36.6).curveTo(212,-28.3,171.3,-22).lineTo(170.5,-21.9).curveTo(170.4,-21.9,170.4,-21.9).curveTo(152.8,-19.3,134.7,-17.2).curveTo(111,-14.6,86.4,-12.9).curveTo(85.1,-12.8,83.8,-12.7).curveTo(43.8,-10.1,1,-10.1).curveTo(-42.4,-10.1,-83.2,-12.8).curveTo(-84.4,-12.9,-85.7,-13).curveTo(-110,-14.7,-134.2,-17.5).lineTo(-150.8,8.3).curveTo(-172.1,5.8,-192.6,2.5).curveTo(-193.9,2.3,-195.3,2.1).curveTo(-235.6,-4.4,-273,-13.9).curveTo(-273.2,-14,-273.5,-14).curveTo(-274.5,-14.3,-275.6,-14.6).curveTo(-278.9,-15.4,-282.1,-16.3).lineTo(-315.4,12.1).curveTo(-377.4,-4.3,-432.2,-28.1).curveTo(-445.6,-34,-458,-40).curveTo(-459.1,-40.5,-460.2,-41).curveTo(-461.2,-41.5,-462.1,-41.9).curveTo(-464.7,-43.2,-467.2,-44.5).curveTo(-507.6,-64.9,-536.4,-87.5).curveTo(-560.9,-106.7,-578.6,-129.2).lineTo(-632,-119.8).lineTo(-640.2,-118.3).moveTo(236.6,-21).lineTo(249,-9).moveTo(280.8,-16.1).curveTo(278.3,-15.4,275.7,-14.7).curveTo(274.7,-14.5,273.7,-14.2).curveTo(273.4,-14.1,273.1,-14.1).curveTo(235.9,-4.7,196,1.9).curveTo(194.8,2.1,193.4,2.3).curveTo(172.5,5.7,150.8,8.3).moveTo(173.3,-8.9).lineTo(183.9,3.2).moveTo(204.1,-14.1).lineTo(215.4,-2.1).moveTo(295.4,-36.2).lineTo(309.6,-25.1).moveTo(266.5,-28.3).lineTo(280.8,-16.1).lineTo(310.6,9.5).curveTo(308.1,10.3,305.7,10.9).curveTo(304.4,11.3,303.1,11.6).curveTo(221.8,33.3,128.3,42.2).curveTo(119.4,43,110.5,43.8).curveTo(109.2,43.9,107.9,44).curveTo(52.5,48.3,-7.1,48.3).curveTo(-59,48.3,-107.8,45).curveTo(-109.1,44.9,-110.3,44.9).curveTo(-118.3,44.3,-126.1,43.7).curveTo(-222.5,35.8,-306.2,14.5).curveTo(-307.5,14.2,-308.8,13.8).curveTo(-312.1,13,-315.4,12.1).lineTo(-351,42.5).curveTo(-406.1,27.7,-455.7,7.4).curveTo(-469.6,1.7,-482.6,-4.2).curveTo(-483.1,-4.4,-483.5,-4.6).curveTo(-484.2,-4.9,-484.9,-5.2).curveTo(-496.9,-10.7,-507.9,-16.4).curveTo(-512.4,-18.7,-516.8,-21).lineTo(-600.5,18.3).moveTo(26.8,3.9).lineTo(27.9,15.6).moveTo(68.9,2.1).lineTo(71.9,13.9).moveTo(109.8,-0.1).lineTo(115,11.9).curveTo(106.3,12.8,97.6,13.3).curveTo(96.3,13.4,95,13.5).curveTo(48.9,16.8,-0.3,16.8).curveTo(-48.9,16.8,-94.4,13.6).curveTo(-95.7,13.5,-96.9,13.4).curveTo(-97,13.4,-97.1,13.4).curveTo(-104.8,12.9,-112.4,12.3).lineTo(-126.1,43.7).lineTo(-140.9,77.9).curveTo(-237.7,69.9,-322.1,49.8).curveTo(-323.5,49.5,-324.8,49.1).curveTo(-333.4,47.1,-341.8,44.9).curveTo(-346.4,43.8,-351,42.5).lineTo(-429.5,109.7).moveTo(134.7,-17.2).lineTo(150.8,8.3).curveTo(133.1,10.4,115,11.9).lineTo(128.3,42.2).lineTo(143.1,76.3).curveTo(134.2,77.1,125.1,77.9).curveTo(120.8,78.3,116.5,78.6).curveTo(115.3,78.7,113.8,78.8).curveTo(55.3,83.1,-7.7,83.1).curveTo(-61.9,83.1,-112.9,79.9).curveTo(-114.3,79.8,-115.6,79.8).curveTo(-120.2,79.4,-124.8,79.1).curveTo(-132.9,78.5,-140.9,77.9).lineTo(-176.2,158.8).moveTo(117.9,-43.7).lineTo(134.7,-17.2).moveTo(345.8,39.8).curveTo(342.1,40.8,338.3,41.8).curveTo(330.3,44,322.1,46).curveTo(320.8,46.4,319.4,46.8).curveTo(237.3,67.4,143.1,76.3).lineTo(179.2,159.1).moveTo(117.9,-43.7).curveTo(218.1,-54.6,298,-85.3).lineTo(337.4,-64.9).lineTo(372.9,-46.6).curveTo(329.3,-28.9,280.8,-16.1).moveTo(613.3,-122.4).lineTo(640.2,-117.7).moveTo(514.3,-139.9).lineTo(565.2,-130.9).lineTo(613.3,-122.4).curveTo(567.1,-60.1,504.3,-23.1).curveTo(502.1,-21.9,500,-20.6).curveTo(488.9,-14.3,477.2,-8.7).curveTo(476,-8.2,474.9,-7.7).curveTo(458.5,0,440.5,7.4).curveTo(395.4,25.8,345.8,39.8).lineTo(428.3,110.3).moveTo(504.3,-23.1).lineTo(595.8,23).moveTo(459.5,-113.5).lineTo(480.3,-107.3).moveTo(420.8,-87).lineTo(439.3,-79.5).moveTo(417.3,-66.7).curveTo(415.3,-65.7,413.3,-64.7).curveTo(413.1,-64.6,413,-64.6).curveTo(411.8,-64,410.8,-63.5).curveTo(399.1,-57.9,386.5,-52.3).curveTo(385.1,-51.7,383.7,-51.1).curveTo(382.9,-50.8,382,-50.4).curveTo(378.8,-49,375.5,-47.7).curveTo(374.2,-47.2,372.9,-46.6).moveTo(440.3,-99.8).lineTo(460.5,-93).moveTo(457.3,-46.7).curveTo(455,-45.5,452.6,-44.3).curveTo(451.5,-43.8,450.5,-43.3).curveTo(435,-35.5,418,-28.1).curveTo(367.3,-6.1,310.6,9.5).lineTo(345.8,39.8).moveTo(378,-65.3).lineTo(396.5,-57.5).moveTo(417.3,-66.7).lineTo(457.3,-46.7).lineTo(504.3,-23.1).moveTo(399.8,-75.6).lineTo(417.3,-66.7).moveTo(468.4,-148.1).lineTo(514.3,-139.9).curveTo(482,-99.5,417.3,-66.7).moveTo(474.8,-127.6).lineTo(497.2,-122.6).moveTo(565.2,-130.9).curveTo(530.1,-84.4,457.3,-46.7).moveTo(324.4,-45.5).lineTo(340.5,-35.2).moveTo(-335.8,-65.2).curveTo(-337.2,-65.7,-338.6,-66.2).curveTo(-342.3,-67.7,-345.9,-69.2).curveTo(-346.2,-69.3,-346.6,-69.5).lineTo(-346.7,-69.5).curveTo(-346.9,-69.6,-347.1,-69.7).curveTo(-363.5,-76.6,-375.1,-82.2).curveTo(-376.3,-82.7,-377.4,-83.2).curveTo(-386,-87.4,-393.9,-91.7).curveTo(-394.8,-92.2,-395.7,-92.7).curveTo(-406.2,-98.5,-415.5,-104.4).curveTo(-416.5,-105,-417.5,-105.7).curveTo(-429.6,-113.5,-439.6,-121.6).curveTo(-440.6,-122.4,-441.5,-123.2).curveTo(-446.4,-127.3,-450.9,-131.4).curveTo(-451.7,-132.2,-452.5,-133).curveTo(-455.5,-135.9,-458.2,-138.8).curveTo(-459,-139.6,-459.7,-140.3).curveTo(-462.8,-143.7,-467,-149).lineTo(-515,-140.5).lineTo(-578.6,-129.2).moveTo(-441.8,-99.8).lineTo(-462.1,-93).moveTo(-418.9,-67.3).curveTo(-435.7,-75.8,-450.2,-84.8).curveTo(-464.8,-93.8,-477,-103.1).curveTo(-479.6,-105.1,-482.1,-107.1).curveTo(-501,-122.6,-515,-140.5).moveTo(-401.3,-75.6).lineTo(-418.9,-67.3).lineTo(-467.2,-44.5).lineTo(-516.8,-21).curveTo(-546.5,-36.9,-569.1,-54).curveTo(-592.4,-71.7,-632,-119.8).moveTo(-398.1,-57.3).curveTo(-405,-60.4,-411.6,-63.6).curveTo(-412.7,-64.2,-413.7,-64.7).curveTo(-414,-64.8,-414.3,-65).curveTo(-416.7,-66.1,-418.9,-67.3).moveTo(-422.4,-87).lineTo(-440.9,-79.5).moveTo(-326,-45.5).lineTo(-342.1,-35.2).moveTo(-372.5,-46.3).curveTo(-377.6,-48.3,-382.6,-50.4).curveTo(-383.2,-50.7,-383.7,-50.9).curveTo(-385,-51.4,-386.2,-52).curveTo(-392.3,-54.6,-398.1,-57.3).moveTo(-379.6,-65.3).lineTo(-398.1,-57.3).moveTo(-335.8,-65.2).lineTo(-372.5,-46.3).moveTo(-461.1,-113.5).lineTo(-482.1,-107.1).moveTo(-476.4,-127.6).lineTo(-498.8,-122.6).moveTo(-117.2,-44.1).lineTo(-134.2,-17.5).curveTo(-153.4,-19.7,-172.5,-22.5).curveTo(-172.9,-22.6,-173.3,-22.6).curveTo(-211,-28.5,-246,-37).curveTo(-247.3,-37.3,-248.6,-37.6).curveTo(-294.6,-49,-335.8,-65.2).moveTo(-107.1,-0.1).lineTo(-112.4,12.3).curveTo(-131.9,10.6,-150.8,8.3).moveTo(-66.2,2.1).lineTo(-69.2,13.9).moveTo(-24.1,3.9).lineTo(-25.3,15.6).moveTo(-117.2,-44.1).curveTo(-60.8,-37.8,2.1,-37.8).curveTo(63,-37.8,117.9,-43.7).moveTo(-467,-149).lineTo(-409.8,-159.1).curveTo(-379.3,-119.8,-303,-88.9).curveTo(-299.4,-87.5,-295.8,-86.1).curveTo(-216.6,-55.3,-117.2,-44.1).moveTo(-238.2,-21).lineTo(-250.5,-9).moveTo(-297,-36.2).lineTo(-311.2,-25.1).moveTo(-268.1,-28.3).lineTo(-282.1,-16.3).curveTo(-329.7,-28.9,-372.5,-46.3).moveTo(-205.7,-14.1).lineTo(-216.9,-2.1).moveTo(-174.9,-8.9).lineTo(-185.5,3.2).moveTo(-295.8,-86.1).lineTo(-335.8,-65.2);
	this.shape.setTransform(640.2,552.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// text
	this.textMC = new lib.textMC();
	this.textMC.setTransform(635,536.3,1,1,0,0,0,607.5,124.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(8.4,90.9).curveTo(9.2,91.1,10.7,91).lineTo(16.3,90.9).curveTo(17.3,90.8,17.4,90.2).lineTo(17.7,88.4).lineTo(17.6,88.4).curveTo(17,89.3,16,89.3).lineTo(11.1,89.5).curveTo(8.3,89.4,8.6,87.6).lineTo(9.2,83.6).curveTo(9.2,82.8,9,82.1).lineTo(13.4,82).lineTo(12.8,87.8).curveTo(12.6,88.2,13.4,88.2).lineTo(16.9,88.1).curveTo(17.7,88.1,17.7,87.6).lineTo(18.3,83.4).curveTo(18.3,82.6,18.2,81.9).lineTo(22.5,81.8).lineTo(21.6,90).curveTo(21.5,90.8,20.7,91.4).curveTo(20,91.9,18.6,92).lineTo(8.6,92.3).closePath().moveTo(-30.3,89.9).curveTo(-29.8,89.3,-29.8,88.7).lineTo(-28.4,81.2).curveTo(-28.3,80.6,-28.4,80).lineTo(-16.7,79.9).curveTo(-13.2,79.8,-13.5,81.8).lineTo(-14,84.4).curveTo(-14.3,86.3,-18,86.3).lineTo(-24.8,86.4).lineTo(-25.3,88.7).curveTo(-25.4,89.3,-25.3,89.9).closePath().moveTo(-23.9,81.2).lineTo(-24.6,85.1).lineTo(-19.6,85.1).curveTo(-19,85.1,-18.6,84.9).curveTo(-18.5,84.7,-18.3,84.3).lineTo(-18,82).curveTo(-17.8,81.5,-18,81.3).curveTo(-18.3,81.1,-18.8,81.1).closePath().moveTo(-12.7,88.3).lineTo(-11.4,81.2).lineTo(-11.4,79.8).lineTo(-7.1,79.8).lineTo(-8.5,88.3).curveTo(-8.6,89,-8.5,89.8).lineTo(-13.1,89.8).curveTo(-12.8,89.1,-12.7,88.3).closePath().moveTo(-6,89.2).curveTo(-6.6,88.6,-6.4,87.3).lineTo(-6.4,87.1).curveTo(-6.2,85.8,-5.5,85.2).curveTo(-4.7,84.7,-3.2,84.6).lineTo(2.6,84.5).curveTo(3.3,84.5,3.3,84.2).lineTo(3.4,83.7).curveTo(3.4,83.3,2.9,83.4).lineTo(-3.7,83.5).lineTo(-5.5,83.6).lineTo(-5,82.4).lineTo(5,82.3).curveTo(7.7,82.1,7.5,84.1).lineTo(6.8,88.2).curveTo(6.8,88.9,6.8,89.6).lineTo(3.1,89.6).lineTo(3.1,88.9).lineTo(3,88.9).curveTo(2.4,89.6,1.3,89.7).lineTo(-4.1,89.8).curveTo(-5.6,89.7,-6,89.2).closePath().moveTo(-1.3,85.7).curveTo(-2,85.8,-2.1,86.3).lineTo(-2.4,88).curveTo(-2.5,88.5,-1.8,88.6).lineTo(2,88.4).curveTo(2.8,88.4,2.7,88).lineTo(3.1,85.6).closePath().moveTo(23.6,87.2).lineTo(23.9,83.7).curveTo(24.1,81.8,26.9,81.7).lineTo(34.8,81.4).curveTo(37.5,81.4,37.4,83.3).lineTo(37.1,85.7).lineTo(27.8,86).lineTo(27.7,87.3).curveTo(27.7,87.9,28.4,87.9).lineTo(35.7,87.5).lineTo(37,87.4).lineTo(36.5,88.7).lineTo(26.1,89).lineTo(26,89.1).curveTo(23.3,89.1,23.6,87.2).closePath().moveTo(28.8,82.7).curveTo(28.2,82.8,28.1,83.4).lineTo(28,84.8).lineTo(33.1,84.6).lineTo(33.2,83.2).curveTo(33.3,82.6,32.6,82.6).closePath().moveTo(38.6,87.1).lineTo(39.1,82.7).curveTo(39.1,82,38.9,81.3).lineTo(42.9,81.1).lineTo(43,81.9).lineTo(43.1,81.9).curveTo(43.3,81.2,44.9,81.1).lineTo(48.4,80.9).lineTo(48.3,82.6).curveTo(47.2,82.4,45.7,82.5).lineTo(43.9,82.6).curveTo(43.2,82.7,43.1,83.1).lineTo(42.8,87.1).curveTo(42.7,87.7,42.9,88.4).lineTo(38.3,88.7).lineTo(38.6,87.1).closePath().moveTo(207.6,74.8).lineTo(204.7,67.7).curveTo(204.4,67.2,203.9,66.6).lineTo(215.2,64.4).curveTo(218.6,63.8,219.4,65.6).lineTo(220.4,68).curveTo(221.2,69.9,217.8,70.6).lineTo(211.1,71.8).lineTo(212,73.9).curveTo(212.2,74.6,212.7,75.1).lineTo(207.8,76).curveTo(207.8,75.3,207.6,74.8).closePath().moveTo(213.8,66).lineTo(209,66.9).lineTo(210.5,70.6).lineTo(215.4,69.7).curveTo(216.1,69.6,216.2,69.3).curveTo(216.3,69.2,216.1,68.7).lineTo(215.2,66.6).curveTo(215,66.1,214.8,66).lineTo(214.4,65.9).lineTo(213.8,66).closePath().moveTo(-203,74.7).lineTo(-202.1,73.4).lineTo(-200.1,69.1).curveTo(-199.8,68.3,-199.8,67.6).lineTo(-195.9,68.1).lineTo(-196.2,68.9).lineTo(-196,68.9).curveTo(-195.6,68.1,-193.9,68.3).lineTo(-190.6,68.7).lineTo(-191.3,70.3).curveTo(-192.3,70,-193.7,69.8).lineTo(-195.5,69.7).curveTo(-196.1,69.5,-196.4,70).lineTo(-198.1,73.8).curveTo(-198.4,74.6,-198.5,75.3).closePath().moveTo(-222.7,75.1).lineTo(-232.5,73.7).lineTo(-232,72.4).lineTo(-229.8,72.9).lineTo(-224.4,73.6).curveTo(-223.6,73.8,-223.3,73.1).lineTo(-222.5,71.4).lineTo(-222.5,71.4).curveTo(-223.2,72.2,-224.2,72).lineTo(-228.9,71.3).curveTo(-231.6,70.9,-230.6,69.1).lineTo(-228.7,65.3).curveTo(-228.3,64.6,-228.1,63.9).lineTo(-224.1,64.5).lineTo(-226.8,70).curveTo(-227,70.4,-226.3,70.5).lineTo(-222.9,70.9).curveTo(-222.2,71,-222,70.6).lineTo(-220,66.5).curveTo(-219.6,65.8,-219.5,65).lineTo(-215.3,65.6).lineTo(-219.2,73.6).curveTo(-219.7,74.4,-220.6,74.7).curveTo(-221.3,75.1,-222.2,75.1).lineTo(-222.7,75.1).closePath().moveTo(-214.6,73.3).curveTo(-217.4,72.9,-216.4,71.1).lineTo(-214.7,67.6).curveTo(-213.9,65.9,-211.2,66.2).lineTo(-203.6,67.2).curveTo(-201,67.4,-201.9,69.3).lineTo(-203,71.7).lineTo(-211.9,70.5).lineTo(-212.5,71.8).curveTo(-212.7,72.3,-212,72.4).lineTo(-205,73.3).curveTo(-204.5,73.4,-203.8,73.4).lineTo(-204.7,74.5).closePath().moveTo(-210.6,67.9).lineTo(-211.3,69.4).lineTo(-206.5,70).lineTo(-205.8,68.5).curveTo(-205.5,68.1,-206.2,68).lineTo(-209.8,67.5).lineTo(-210,67.5).curveTo(-210.5,67.5,-210.6,67.9).closePath().moveTo(224,71.5).lineTo(221,64.8).curveTo(220.7,64,220.2,63.5).lineTo(224.3,62.7).lineTo(228,70.7).curveTo(228.3,71.4,228.9,72).lineTo(224.4,72.8).lineTo(224,71.5).closePath().moveTo(230.8,71).curveTo(229.9,70.6,229.5,69.5).lineTo(229.2,69.2).curveTo(228.7,67.9,229.1,67.3).curveTo(229.4,66.7,230.9,66.4).lineTo(236.5,65.2).curveTo(237.1,65.1,237,64.8).lineTo(236.7,64.3).curveTo(236.5,64,236.1,64.1).lineTo(229.8,65.4).curveTo(229.1,65.5,228.2,65.9).lineTo(227.9,64.6).lineTo(237.3,62.7).curveTo(240,62.1,240.8,64).lineTo(242.7,67.9).curveTo(243,68.5,243.5,69).lineTo(239.9,69.7).lineTo(239.3,69.1).lineTo(239.2,69.1).curveTo(239.1,69.9,238.2,70.1).lineTo(233.1,71.2).lineTo(232.2,71.3).curveTo(231.4,71.3,230.8,71).closePath().moveTo(233.4,67).curveTo(232.7,67.1,232.9,67.6).lineTo(233.7,69.3).curveTo(233.9,69.7,234.5,69.7).lineTo(238.2,69).curveTo(238.8,68.8,238.7,68.3).lineTo(237.6,66.2).closePath().moveTo(245.8,70).curveTo(246.7,70,248.2,69.7).lineTo(253.4,68.5).curveTo(254.3,68.4,254,67.7).lineTo(253.3,66.2).lineTo(253.2,66.2).curveTo(253.2,66.9,252.3,67.2).lineTo(247.4,68.2).curveTo(244.9,68.7,244,67).lineTo(242.1,63.2).curveTo(241.9,62.5,241.2,61.9).lineTo(245.5,61).lineTo(248.1,66.3).curveTo(248.3,66.8,249,66.6).lineTo(252.3,65.9).curveTo(253,65.8,252.8,65.3).lineTo(250.8,61.3).curveTo(250.4,60.6,249.8,60.1).lineTo(254.2,59.2).lineTo(257.9,66.8).curveTo(258.3,67.6,258,68.3).curveTo(257.6,68.9,256.3,69.2).lineTo(246.6,71.2).closePath().moveTo(-236.5,70.2).lineTo(-236.4,69.4).curveTo(-237.2,70.2,-238.2,70).lineTo(-243.3,69.2).curveTo(-244.7,69,-245.1,68.4).curveTo(-245.3,67.8,-244.6,66.6).lineTo(-244.4,66.3).curveTo(-243.8,65,-243,64.6).curveTo(-242.1,64.2,-240.7,64.4).lineTo(-235,65.2).curveTo(-234.5,65.3,-234.3,64.9).lineTo(-234.1,64.5).curveTo(-233.9,64.2,-234.4,64.1).lineTo(-240.7,63.1).lineTo(-242.4,63.1).lineTo(-241.5,61.9).lineTo(-232,63.4).curveTo(-229.4,63.7,-230.4,65.5).lineTo(-232.5,69.5).curveTo(-232.8,70.1,-232.9,70.8).closePath().moveTo(-240.1,66.1).lineTo(-241.1,67.9).curveTo(-241.4,68.3,-240.7,68.4).lineTo(-237.1,68.9).curveTo(-236.6,69,-236.2,68.6).lineTo(-235.1,66.4).lineTo(-239.3,65.8).lineTo(-239.6,65.8).curveTo(-240,65.8,-240.1,66.1).closePath().moveTo(-251.8,67.9).lineTo(-250.8,66.6).lineTo(-247.1,59.9).curveTo(-246.6,59,-246.5,58.3).lineTo(-242.4,59.1).lineTo(-246.9,67.2).curveTo(-247.3,67.9,-247.4,68.6).closePath().moveTo(-268,65.3).curveTo(-267.3,64.7,-267,64.1).lineTo(-263,57.1).curveTo(-262.6,56.5,-262.5,55.8).lineTo(-251.4,57.6).curveTo(-248.2,58.1,-249.3,60.1).lineTo(-250.6,62.4).curveTo(-251.7,64.3,-255.1,63.8).lineTo(-261.5,62.7).lineTo(-262.8,64.8).curveTo(-263.1,65.4,-263.2,66.1).closePath().moveTo(-260.8,61.4).lineTo(-256.1,62.2).curveTo(-255.6,62.3,-255.2,62.2).curveTo(-254.9,62,-254.6,61.6).lineTo(-253.4,59.4).curveTo(-253.1,59,-253.3,58.8).curveTo(-253.4,58.6,-254,58.4).lineTo(-258.7,57.7).closePath().moveTo(258.1,63.9).lineTo(256.4,60.7).curveTo(255.4,58.8,258,58.3).lineTo(265.5,56.5).curveTo(268,56.1,269,57.7).lineTo(270.3,60.1).lineTo(261.5,61.9).lineTo(262.2,63.3).curveTo(262.4,63.7,263.1,63.6).lineTo(269.9,62).lineTo(271.1,61.7).lineTo(271.4,62.9).lineTo(261.7,65).lineTo(260.4,65.2).curveTo(258.8,65.2,258.1,63.9).closePath().moveTo(264.1,58.1).lineTo(260.6,58.9).curveTo(259.9,59,260.2,59.4).lineTo(260.9,61).lineTo(265.8,59.9).lineTo(265,58.4).curveTo(264.8,58.1,264.4,58.1).lineTo(264.1,58.1).closePath().moveTo(272.6,61.1).lineTo(270.3,57.1).curveTo(269.9,56.3,269.3,55.6).lineTo(273.1,54.8).lineTo(273.6,55.6).curveTo(273.4,54.7,275,54.4).lineTo(278.2,53.6).lineTo(279,55).lineTo(276.6,55.5).lineTo(274.9,55.9).curveTo(274.1,56.1,274.4,56.5).lineTo(276.5,60.2).curveTo(276.9,60.9,277.5,61.4).lineTo(273.1,62.5).curveTo(273,61.7,272.6,61.1).closePath().moveTo(0.9,56.1).curveTo(1.3,55.6,1.4,54.8).lineTo(1.9,51.1).curveTo(2,50.3,1.9,49.7).lineTo(5.7,49.7).lineTo(5.6,50.3).lineTo(5.7,50.3).curveTo(6,49.7,6.9,49.7).lineTo(11.5,49.6).curveTo(14,49.6,13.7,51.3).lineTo(13.2,54.8).curveTo(13,55.5,13.2,56).lineTo(9.1,56).curveTo(9.3,55.5,9.5,54.8).lineTo(10.1,51.1).curveTo(10,50.7,9.5,50.6).lineTo(6.3,50.6).curveTo(5.7,50.7,5.7,51.1).lineTo(5,54.8).curveTo(5,55.5,5,56.1).closePath().moveTo(-3.6,56.1).lineTo(-3.7,55.5).curveTo(-4.2,56.1,-5.2,56.1).lineTo(-9.9,56).curveTo(-11.1,56,-11.7,55.6).curveTo(-12.1,55.1,-12,54).lineTo(-11.9,53.7).curveTo(-11.7,52.6,-11.1,52.1).curveTo(-10.4,51.7,-9.1,51.7).lineTo(-3.8,51.7).curveTo(-3.3,51.7,-3.2,51.3).lineTo(-3.1,51).curveTo(-3.1,50.7,-3.6,50.6).lineTo(-9.5,50.6).lineTo(-11,50.8).lineTo(-10.6,49.6).lineTo(-1.8,49.7).curveTo(0.8,49.8,0.5,51.4).lineTo(-0.2,55).curveTo(-0.3,55.6,-0.1,56.1).closePath().moveTo(-8.1,53.1).lineTo(-8.4,54.7).curveTo(-8.5,55.1,-7.8,55.1).lineTo(-4.6,55.1).curveTo(-3.9,55.1,-3.8,54.7).lineTo(-3.5,52.7).lineTo(-7.4,52.7).curveTo(-8,52.6,-8.1,53.1).closePath().moveTo(14.9,54.8).lineTo(15.6,48.6).curveTo(15.7,48,15.6,47.4).lineTo(19.5,47.3).lineTo(18.9,52.1).lineTo(23.6,49.9).curveTo(23.9,49.7,24,49.5).lineTo(27.3,49.5).lineTo(25.8,50.2).lineTo(23.3,51.2).lineTo(26,54.8).curveTo(26.1,55.2,27.1,55.9).lineTo(22.7,55.9).lineTo(20.3,52.7).lineTo(18.7,53.4).lineTo(18.5,54.8).lineTo(18.5,56).lineTo(14.4,56).lineTo(14.9,54.8).closePath().moveTo(-16.6,56).lineTo(-27.5,55.8).curveTo(-27.1,55.2,-27.1,54.8).lineTo(-25.6,48.3).lineTo(-25.6,47.1).lineTo(-14.8,47.3).curveTo(-13.6,47.3,-13,47.7).curveTo(-12.4,48.2,-12.5,49).lineTo(-12.9,50.3).curveTo(-12.9,51,-13.7,51.2).curveTo(-14.3,51.5,-16.1,51.5).lineTo(-16.1,51.6).curveTo(-14.4,51.6,-13.8,51.9).curveTo(-13.2,52.2,-13.3,52.9).lineTo(-13.7,54.5).curveTo(-13.9,55.2,-14.6,55.6).curveTo(-15.3,56,-16.4,56).lineTo(-16.6,56).closePath().moveTo(-23,54.8).lineTo(-18.3,54.8).curveTo(-17.6,54.8,-17.5,54.4).lineTo(-17.2,52.7).curveTo(-17.1,52.2,-17.8,52.1).lineTo(-22.5,52).closePath().moveTo(-22.2,51).lineTo(-17.5,51.1).curveTo(-16.8,51.1,-16.6,50.4).lineTo(-16.4,49).curveTo(-16.2,48.3,-16.9,48.4).lineTo(-21.6,48.4).closePath().moveTo(28.4,54.2).lineTo(28.7,51.1).curveTo(28.9,49.5,31.3,49.4).lineTo(38.4,49.3).curveTo(40.9,49.2,40.7,50.9).lineTo(40.5,53).lineTo(32.3,53.1).lineTo(32.1,54.4).curveTo(32.1,54.8,32.7,54.8).lineTo(39.2,54.7).lineTo(40.3,54.6).lineTo(40,55.6).lineTo(30.7,55.8).lineTo(30.6,55.9).curveTo(28.3,55.9,28.4,54.2).closePath().moveTo(33.1,50.3).curveTo(32.5,50.4,32.5,50.9).lineTo(32.3,52.2).lineTo(36.8,52).lineTo(37.1,50.8).curveTo(37.1,50.3,36.5,50.3).closePath().moveTo(41.9,54.4).lineTo(42.2,50.4).lineTo(42.1,49.2).lineTo(45.6,49.1).lineTo(45.7,49.7).curveTo(45.9,49.1,47.4,49.1).lineTo(50.6,49).lineTo(50.4,50.3).lineTo(48.2,50.3).lineTo(46.5,50.3).curveTo(45.9,50.3,45.8,50.8).lineTo(45.6,54.1).curveTo(45.6,54.8,45.7,55.5).lineTo(41.6,55.6).lineTo(41.9,54.4).closePath().moveTo(-177.5,44.7).lineTo(-176.8,43.5).lineTo(-175.4,39.7).lineTo(-175.1,38.4).lineTo(-171.7,38.8).lineTo(-171.8,39.5).lineTo(-171.7,39.5).curveTo(-171.4,38.8,-169.9,39.1).lineTo(-166.9,39.4).lineTo(-167.4,40.9).lineTo(-169.6,40.4).lineTo(-171.2,40.3).curveTo(-171.9,40.2,-172,40.5).lineTo(-173.2,43.9).curveTo(-173.5,44.6,-173.5,45.1).closePath().moveTo(181.4,43.7).lineTo(179.1,37.4).curveTo(179,36.9,178.5,36.4).lineTo(189,34.6).curveTo(190.2,34.5,191.1,34.8).curveTo(191.8,35.1,192.1,35.8).lineTo(192.6,37.1).curveTo(192.8,37.8,192.4,38.1).curveTo(191.8,38.4,190.1,38.8).curveTo(191.9,38.6,192.5,38.7).curveTo(193.3,38.9,193.5,39.5).lineTo(194.1,41.1).curveTo(194.3,41.8,193.9,42.3).curveTo(193.3,42.8,192.1,43).lineTo(181.5,44.8).curveTo(181.6,44.1,181.4,43.7).closePath().moveTo(188.8,39.6).lineTo(184.4,40.4).lineTo(185.3,43).lineTo(189.8,42.2).curveTo(190.5,42.1,190.3,41.6).lineTo(189.8,40.1).curveTo(189.5,39.6,189,39.6).lineTo(188.8,39.6).closePath().moveTo(187.5,36).lineTo(183.1,36.8).lineTo(184,39.3).lineTo(188.5,38.5).curveTo(189.1,38.5,188.9,37.9).lineTo(188.5,36.5).curveTo(188.2,36,187.7,36).lineTo(187.5,36).closePath().moveTo(-187.9,43.3).curveTo(-190.4,42.9,-189.6,41.3).lineTo(-188.4,38.4).curveTo(-187.9,36.7,-185.4,37).lineTo(-178.6,38).curveTo(-176.3,38.3,-177,39.9).lineTo(-177.7,42).lineTo(-185.8,40.9).lineTo(-186.3,42.1).curveTo(-186.4,42.4,-185.8,42.5).lineTo(-179.4,43.4).lineTo(-178.4,43.4).lineTo(-179.2,44.5).closePath().moveTo(-184.8,38.6).lineTo(-185.4,39.9).lineTo(-181,40.5).lineTo(-180.4,39.2).curveTo(-180.2,38.8,-180.9,38.7).lineTo(-184,38.3).lineTo(-184.3,38.2).curveTo(-184.7,38.2,-184.8,38.6).closePath().moveTo(-195.6,42.2).lineTo(-196.9,38.6).lineTo(-198.7,39).lineTo(-199.3,40.3).curveTo(-199.6,41,-199.6,41.6).lineTo(-203.5,41).curveTo(-203.1,40.5,-202.8,39.7).lineTo(-200.2,33.9).curveTo(-199.9,33.2,-199.8,32.5).lineTo(-196,33.1).lineTo(-198.2,37.8).lineTo(-192.9,36.3).lineTo(-192.4,36).lineTo(-189.3,36.5).lineTo(-190.9,36.8).lineTo(-193.7,37.6).lineTo(-192.1,41.7).lineTo(-191.4,42.8).closePath().moveTo(196.7,41.8).curveTo(195.9,41.4,195.6,40.4).lineTo(195.5,40.1).curveTo(195,39,195.4,38.5).curveTo(195.7,37.9,197,37.6).lineTo(202.2,36.8).curveTo(202.6,36.7,202.4,36.4).lineTo(202.3,36).curveTo(202.3,35.7,201.8,35.8).lineTo(196.1,36.8).lineTo(194.7,37.2).lineTo(194.6,36.1).lineTo(203,34.7).curveTo(205.5,34.2,206,35.8).lineTo(207.5,39.3).curveTo(207.7,39.8,208.2,40.3).lineTo(204.8,40.9).lineTo(204.3,40.3).curveTo(204.2,41,203.3,41.2).lineTo(198.6,42).lineTo(197.8,42).curveTo(197.2,42,196.7,41.8).closePath().moveTo(199.2,38.3).curveTo(198.7,38.4,198.8,38.8).lineTo(199.3,40.4).curveTo(199.5,40.8,200.1,40.7).lineTo(203.3,40.2).curveTo(203.9,40,203.8,39.6).lineTo(203,37.7).closePath().moveTo(-208.7,40.2).lineTo(-207.9,38.9).lineTo(-206.3,35.4).curveTo(-206,35,-206.6,34.9).lineTo(-209.6,34.4).curveTo(-210.2,34.3,-210.4,34.7).lineTo(-212.1,38.3).lineTo(-212.6,39.5).lineTo(-216.4,38.9).lineTo(-215.7,37.7).lineTo(-213.9,34).curveTo(-213.6,33.3,-213.5,32.7).lineTo(-210,33.3).lineTo(-210.2,34).lineTo(-210.1,34).curveTo(-209.6,33.3,-208.8,33.5).lineTo(-204.4,34.2).curveTo(-202,34.6,-202.8,36.2).lineTo(-204.4,39.5).curveTo(-204.7,40.2,-204.8,40.8).closePath().moveTo(208.8,38.9).lineTo(207.2,35.2).curveTo(206.9,34.5,206.6,34).lineTo(210.1,33.3).lineTo(210.4,34).lineTo(210.5,34).curveTo(210.5,33.3,211.3,33.1).lineTo(215.8,32.3).curveTo(218.1,31.9,218.7,33.5).lineTo(220.2,36.8).curveTo(220.4,37.4,220.9,38).lineTo(216.9,38.7).curveTo(216.9,38.1,216.6,37.5).lineTo(215.1,34).curveTo(215,33.5,214.3,33.7).lineTo(211.3,34.2).curveTo(210.6,34.3,210.9,34.7).lineTo(212.3,38.3).curveTo(212.6,38.9,213,39.4).lineTo(209.1,40.2).curveTo(209,39.5,208.8,38.9).closePath().moveTo(-220.8,38.2).lineTo(-220.6,37.5).lineTo(-220.7,37.5).curveTo(-221.3,38,-222.1,37.9).lineTo(-226.8,37.1).curveTo(-227.9,36.9,-228.2,36.4).curveTo(-228.5,35.8,-228,34.8).lineTo(-227.8,34.4).curveTo(-227.3,33.4,-226.4,33.1).curveTo(-225.7,32.7,-224.5,32.9).lineTo(-219.5,33.7).curveTo(-219,33.8,-218.9,33.6).lineTo(-218.7,33.1).curveTo(-218.6,33.1,-218.6,33).curveTo(-218.6,33,-218.7,32.9).curveTo(-218.7,32.9,-218.8,32.9).curveTo(-218.8,32.8,-219,32.8).lineTo(-224.5,31.8).lineTo(-226.1,31.7).lineTo(-225.3,30.7).lineTo(-216.9,32.2).curveTo(-214.6,32.6,-215.4,34.1).lineTo(-217.2,37.6).curveTo(-217.5,38.1,-217.5,38.7).closePath().moveTo(-224,34.4).lineTo(-224.7,35.9).curveTo(-225,36.4,-224.5,36.5).lineTo(-221.3,37).curveTo(-220.7,37.1,-220.5,36.7).lineTo(-219.5,34.8).lineTo(-223.2,34.1).lineTo(-223.5,34.1).curveTo(-223.9,34.1,-224,34.4).closePath().moveTo(221.9,36.6).lineTo(219.2,30.7).curveTo(218.9,30,218.4,29.5).lineTo(222.1,28.8).lineTo(224.2,33.3).lineTo(227.5,30.4).curveTo(227.6,30.4,227.6,30.4).curveTo(227.6,30.3,227.7,30.3).curveTo(227.7,30.2,227.7,30.2).curveTo(227.7,30.1,227.7,30.1).lineTo(230.8,29.5).lineTo(229.7,30.3).lineTo(228,31.8).lineTo(232.7,34.7).curveTo(232.9,34.9,234.2,35.5).lineTo(230,36.2).lineTo(225.8,33.6).lineTo(224.8,34.6).lineTo(225.4,35.9).curveTo(225.6,36.5,226.1,37).lineTo(222.1,37.7).curveTo(222.1,37.2,221.9,36.6).closePath().moveTo(-233.1,35.9).lineTo(-243.3,34).curveTo(-242.7,33.5,-242.4,33).lineTo(-239,26.9).curveTo(-238.7,26.4,-238.7,25.8).lineTo(-228.6,27.7).curveTo(-227.4,27.9,-226.9,28.5).curveTo(-226.5,29,-226.9,29.7).lineTo(-227.6,31).curveTo(-228,31.7,-228.8,31.7).curveTo(-229.4,31.9,-231.1,31.6).lineTo(-231.1,31.6).curveTo(-229.6,32,-229,32.4).curveTo(-228.6,32.8,-229,33.4).lineTo(-229.8,34.9).curveTo(-230.2,35.6,-230.9,35.8).curveTo(-231.5,36.1,-232.1,36.1).lineTo(-233.1,35.9).closePath().moveTo(-238.7,33.7).lineTo(-234.3,34.6).curveTo(-233.7,34.7,-233.4,34.2).lineTo(-232.5,32.6).curveTo(-232.2,32.1,-232.9,32).lineTo(-237.3,31.2).closePath().moveTo(-236.7,30.1).lineTo(-232.3,30.9).curveTo(-231.7,31,-231.4,30.5).lineTo(-230.6,29.1).curveTo(-230.3,28.6,-230.9,28.4).lineTo(-235.3,27.6).closePath().moveTo(234.5,33.6).lineTo(233,30.7).curveTo(232.3,29.2,234.6,28.7).lineTo(241.4,27.4).curveTo(243.6,26.9,244.4,28.4).lineTo(245.4,30.4).lineTo(237.5,32.1).lineTo(238.2,33.2).curveTo(238.3,33.6,238.9,33.4).lineTo(245.2,32.2).lineTo(246.2,31.9).lineTo(246.3,33).lineTo(237.6,34.8).lineTo(236.6,34.8).curveTo(235.1,34.8,234.5,33.6).closePath().moveTo(240,28.7).lineTo(236.9,29.3).curveTo(236.2,29.4,236.5,29.8).lineTo(237.2,31.1).lineTo(241.4,30.2).lineTo(240.8,28.9).curveTo(240.7,28.6,240.4,28.6).lineTo(240,28.7).closePath().moveTo(247.4,31.4).lineTo(245.5,27.8).curveTo(245.3,27.1,244.7,26.6).lineTo(248.1,25.9).lineTo(248.6,26.6).lineTo(248.6,26.6).curveTo(248.3,25.8,249.8,25.6).lineTo(252.8,24.9).lineTo(253.4,26.2).curveTo(252.4,26.3,251.3,26.6).lineTo(249.8,26.9).curveTo(249,27,249.3,27.4).lineTo(250.9,30.7).lineTo(251.8,31.8).lineTo(247.9,32.6).curveTo(247.8,32,247.4,31.4).closePath().moveTo(387.2,30.5).lineTo(381.3,24.4).lineTo(380.1,23.3).lineTo(390,19.7).curveTo(392.9,18.7,394.5,20.4).lineTo(396.5,22.4).curveTo(398.1,24.1,395,25.1).lineTo(389.2,27.3).lineTo(391,29.2).curveTo(391.4,29.6,392.2,30.2).lineTo(387.9,31.7).curveTo(387.6,31,387.2,30.5).closePath().moveTo(389.3,21.4).lineTo(385.1,23).lineTo(388.2,26.2).lineTo(392.3,24.7).curveTo(393,24.5,393,24.2).curveTo(393,24,392.7,23.7).lineTo(390.9,21.7).curveTo(390.6,21.4,390.2,21.4).lineTo(389.9,21.3).lineTo(389.3,21.4).closePath().moveTo(-392.2,30.4).curveTo(-391.4,29.9,-390.9,29.2).lineTo(-387.3,25.4).curveTo(-386.6,24.7,-386.3,24).lineTo(-382.9,25.1).lineTo(-383.4,25.9).lineTo(-383.4,25.9).curveTo(-382.6,25.2,-381.2,25.7).lineTo(-378.3,26.6).lineTo(-379.5,28).curveTo(-380.3,27.6,-381.6,27.2).lineTo(-383.1,26.7).curveTo(-383.8,26.5,-384.1,26.9).lineTo(-387.4,30.4).curveTo(-387.9,31,-388.2,31.6).closePath().moveTo(-402.3,27).curveTo(-404.6,26.2,-403,24.6).lineTo(-400,21.5).curveTo(-398.3,19.9,-396.1,20.7).lineTo(-389.5,22.9).lineTo(-388.6,23.3).curveTo(-387.7,24.1,-389,25.3).lineTo(-391,27.4).lineTo(-398.6,24.8).lineTo(-399.8,25.9).curveTo(-400.2,26.3,-399.6,26.6).lineTo(-393.5,28.6).lineTo(-392.4,28.9).lineTo(-393.7,29.9).closePath().moveTo(-396.4,22.5).lineTo(-397.7,23.8).lineTo(-393.5,25.2).lineTo(-392.2,24).curveTo(-391.8,23.5,-392.3,23.3).lineTo(-395.4,22.3).lineTo(-395.7,22.2).curveTo(-396.1,22.2,-396.4,22.5).closePath().moveTo(-410.6,27.2).lineTo(-418.8,24.3).lineTo(-417.9,23.1).curveTo(-417.3,23.5,-416,24).lineTo(-411.6,25.6).curveTo(-410.7,25.9,-410.2,25.3).lineTo(-408.6,23.9).lineTo(-408.7,23.8).curveTo(-409.6,24.4,-410.5,24.1).lineTo(-414.6,22.6).curveTo(-416.8,21.8,-415.2,20.3).lineTo(-411.7,16.9).lineTo(-410.6,15.6).lineTo(-407.1,16.9).lineTo(-411.9,21.6).curveTo(-412.4,22,-411.7,22.3).lineTo(-408.9,23.3).curveTo(-408.4,23.5,-407.9,23.2).lineTo(-404.2,19.6).curveTo(-403.6,18.9,-403.2,18.2).lineTo(-399.6,19.5).lineTo(-406.7,26.5).curveTo(-407.4,27.2,-408.4,27.4).lineTo(-409.2,27.5).curveTo(-409.9,27.5,-410.6,27.2).closePath().moveTo(401.4,25.1).lineTo(395.7,19.4).curveTo(395,18.6,394.2,18.2).lineTo(397.9,16.8).lineTo(404.8,23.9).curveTo(405.5,24.4,406.3,24.9).lineTo(402.5,26.3).curveTo(402,25.7,401.4,25.1).closePath().moveTo(407.6,23.7).curveTo(406.8,23.5,405.6,22.4).lineTo(405.4,22.2).curveTo(404.4,21.1,404.4,20.5).curveTo(404.4,19.8,405.6,19.4).lineTo(410.5,17.4).curveTo(411,17.2,410.8,16.9).lineTo(410.3,16.6).curveTo(410.1,16.2,409.6,16.4).lineTo(404.3,18.6).lineTo(402.9,19.3).lineTo(402,18.2).lineTo(410.3,15).curveTo(412.5,14,414.1,15.6).lineTo(417.6,18.9).lineTo(418.9,19.9).lineTo(415.7,21.2).lineTo(414.9,20.6).lineTo(414.9,20.6).curveTo(415.2,21.4,414.3,21.7).lineTo(409.9,23.5).curveTo(409.1,23.8,408.4,23.8).lineTo(407.6,23.7).closePath().moveTo(408.3,19.6).curveTo(407.8,19.8,408.2,20.3).lineTo(409.7,21.7).curveTo(410.1,22.1,410.6,21.8).lineTo(413.7,20.6).curveTo(414.3,20.5,413.9,20).lineTo(412,18.1).closePath().moveTo(421.5,20.6).curveTo(422.4,20.4,423.6,19.9).lineTo(428.1,18).curveTo(428.8,17.8,428.3,17.2).lineTo(426.8,15.9).lineTo(426.8,15.9).curveTo(427.1,16.5,426.3,16.9).lineTo(422.2,18.6).curveTo(420,19.6,418.4,17.9).lineTo(414.9,14.8).curveTo(414.3,14.1,413.6,13.7).lineTo(417.1,12.3).lineTo(422,16.8).curveTo(422.4,17.1,423,16.9).lineTo(425.9,15.8).curveTo(426.5,15.5,426.1,15.1).lineTo(422.4,11.7).lineTo(420.9,10.6).lineTo(424.5,9.2).lineTo(431.6,15.8).curveTo(432.3,16.5,432.2,17).curveTo(432.1,17.8,431,18.2).lineTo(422.9,21.5).closePath().moveTo(-421.1,20.3).lineTo(-420.6,19.6).lineTo(-420.6,19.5).curveTo(-421.6,20.1,-422.5,19.7).lineTo(-426.9,18).curveTo(-428,17.7,-428,17).curveTo(-428.1,16.3,-426.9,15.3).lineTo(-426.6,15.1).curveTo(-425.5,14,-424.4,13.7).curveTo(-423.4,13.4,-422.3,13.9).lineTo(-417.4,15.7).curveTo(-417,15.9,-416.7,15.5).lineTo(-416.2,15.1).curveTo(-416.2,15.1,-416.2,15).curveTo(-416.1,15,-416.2,14.9).curveTo(-416.2,14.9,-416.2,14.8).curveTo(-416.3,14.8,-416.4,14.8).lineTo(-421.7,12.7).lineTo(-423.3,12.4).lineTo(-421.9,11.4).lineTo(-414,14.3).curveTo(-413.3,14.5,-413,14.9).curveTo(-412.2,15.5,-413.1,16.6).lineTo(-413.4,16.8).lineTo(-417.1,20.3).curveTo(-417.6,20.8,-418,21.4).closePath().moveTo(-422.6,15.7).lineTo(-424.2,17.1).curveTo(-424.6,17.5,-424.2,17.8).lineTo(-421,18.9).curveTo(-420.6,19.1,-420,18.8).lineTo(-418,16.9).lineTo(-421.6,15.4).lineTo(-421.9,15.4).curveTo(-422.3,15.4,-422.6,15.7).closePath().moveTo(-434,15.4).lineTo(-432.5,14.3).lineTo(-426.1,8.5).curveTo(-425.3,7.8,-425,7.1).lineTo(-421.5,8.5).lineTo(-429.2,15.5).curveTo(-429.9,16.2,-430.3,16.9).closePath().moveTo(430.5,13.1).lineTo(427.3,10.1).curveTo(425.6,8.7,427.8,7.8).lineTo(434.1,5.1).curveTo(436,4.3,437.7,5.4).lineTo(437.9,5.6).lineTo(440.1,7.6).lineTo(432.8,10.7).lineTo(434,11.8).curveTo(434.3,12.2,435,11.9).lineTo(440.7,9.4).lineTo(441.6,8.9).lineTo(442.5,10).lineTo(434.3,13.5).curveTo(433.4,13.9,432.7,13.9).curveTo(431.5,13.9,430.5,13.1).closePath().moveTo(433.4,6.7).lineTo(430.5,8).curveTo(429.9,8.2,430.5,8.6).lineTo(431.7,9.8).lineTo(435.9,8.1).lineTo(434.4,6.9).curveTo(434.1,6.6,433.8,6.6).lineTo(433.4,6.7).closePath().moveTo(-447.6,10).curveTo(-446.7,9.6,-446.1,9).lineTo(-439.3,3).lineTo(-438.4,1.9).lineTo(-429.8,5.3).lineTo(-429.8,6).lineTo(-428.2,6).curveTo(-426.7,6.9,-428.1,8.2).lineTo(-430.5,10.3).curveTo(-432.3,11.9,-435.1,10.8).lineTo(-440.5,8.7).lineTo(-442.6,10.5).curveTo(-443.2,11,-443.5,11.6).closePath().moveTo(-439.4,7.6).lineTo(-435.4,9.2).curveTo(-435,9.3,-434.5,9.2).curveTo(-434.2,9.2,-433.8,8.8).lineTo(-431.7,7).curveTo(-431.3,6.6,-431.3,6.3).curveTo(-431.4,6.1,-431.8,6).lineTo(-435.8,4.4).closePath().moveTo(442.8,8.2).lineTo(438.9,4.7).lineTo(437.2,3.7).lineTo(440.4,2.3).lineTo(441.1,2.8).lineTo(441.3,2.8).curveTo(440.6,2.2,441.9,1.6).lineTo(444.7,0.4).lineTo(446.1,1.6).curveTo(445.1,1.9,444,2.4).lineTo(442.5,3.1).curveTo(442.1,3.3,442.4,3.6).lineTo(446.1,6.8).curveTo(446.7,7.3,447.6,7.8).lineTo(444,9.5).curveTo(443.4,8.7,442.8,8.2).closePath().moveTo(347.1,5.1).lineTo(342.3,-0.4).curveTo(341.8,-0.9,341.2,-1.3).lineTo(350.5,-4.6).curveTo(351.6,-4.8,352.4,-4.7).curveTo(353.5,-4.6,354,-3.8).lineTo(355,-2.7).curveTo(355.6,-2.1,355.2,-1.7).curveTo(354.8,-1.3,353.3,-0.8).lineTo(353.4,-0.7).curveTo(354.9,-1.2,355.7,-1.2).curveTo(356.4,-1.2,357,-0.5).lineTo(358.1,0.8).curveTo(358.6,1.2,358.6,1.6).curveTo(358.6,1.6,358.6,1.7).curveTo(358.6,1.7,358.6,1.8).curveTo(358.6,1.8,358.5,1.8).curveTo(358.5,1.9,358.5,1.9).curveTo(358.2,2.5,357.1,2.9).lineTo(347.8,6.1).curveTo(347.5,5.6,347.1,5.1).closePath().moveTo(352.5,0.2).lineTo(348.5,1.6).lineTo(350.6,3.8).lineTo(354.6,2.5).curveTo(355.2,2.3,354.8,1.8).lineTo(353.5,0.5).curveTo(353.3,0.1,352.9,0.1).lineTo(352.5,0.2).closePath().moveTo(349.7,-3).lineTo(345.6,-1.7).lineTo(347.7,0.7).lineTo(351.6,-0.7).curveTo(352.3,-1,351.8,-1.4).lineTo(350.7,-2.7).curveTo(350.4,-3.1,350.1,-3.1).lineTo(349.7,-3).closePath().moveTo(-347.6,4.3).lineTo(-346.5,3.3).lineTo(-343.4,-0.1).lineTo(-342.6,-1.2).lineTo(-339.6,-0.3).lineTo(-340,0.3).lineTo(-339.9,0.3).curveTo(-339.4,-0.3,-338,0.1).lineTo(-335.3,1).lineTo(-336.1,1.8).lineTo(-337.3,1.8).lineTo(-338.2,1.5).lineTo(-339.7,1).curveTo(-340.2,0.9,-340.6,1.3).lineTo(-343.3,4.3).curveTo(-343.7,4.9,-344,5.4).closePath().moveTo(-356.8,1.5).curveTo(-358.9,0.8,-357.6,-0.6).lineTo(-355.1,-3.4).curveTo(-353.7,-4.7,-351.7,-4.1).lineTo(-345.7,-2.2).curveTo(-343.6,-1.6,-345,-0.1).lineTo(-346.7,1.7).lineTo(-353.7,-0.5).lineTo(-354.6,0.5).curveTo(-354.9,0.9,-354.4,1.1).lineTo(-348.8,2.9).lineTo(-347.8,3.1).lineTo(-349,3.9).closePath().moveTo(-351.7,-2.5).lineTo(-352.9,-1.3).lineTo(-349,-0.2).lineTo(-347.9,-1.3).curveTo(-347.6,-1.7,-348,-1.8).lineTo(-350.9,-2.7).lineTo(-351.2,-2.8).curveTo(-351.5,-2.8,-351.7,-2.5).closePath().moveTo(360.9,1).curveTo(360.1,0.8,359.2,-0.1).lineTo(358.9,-0.3).curveTo(358.1,-1.3,358.1,-1.9).curveTo(358.2,-2.4,359.5,-2.8).lineTo(364,-4.5).curveTo(364.1,-4.5,364.1,-4.5).curveTo(364.2,-4.6,364.2,-4.6).curveTo(364.2,-4.7,364.2,-4.7).curveTo(364.2,-4.8,364.1,-4.8).lineTo(363.8,-5.3).curveTo(363.5,-5.4,363.2,-5.3).lineTo(358.2,-3.6).curveTo(357.6,-3.3,357,-2.9).lineTo(356.3,-4).lineTo(363.9,-6.6).curveTo(366,-7.3,367.2,-5.9).lineTo(370.1,-2.9).lineTo(371.2,-2).lineTo(368.3,-1).lineTo(367.6,-1.5).lineTo(367.6,-1.5).curveTo(367.7,-0.8,366.9,-0.5).lineTo(362.9,0.9).curveTo(362.2,1.2,361.7,1.2).lineTo(360.9,1).closePath().moveTo(361.7,-2.5).curveTo(361.3,-2.4,361.6,-2).lineTo(362.9,-0.7).curveTo(363.2,-0.3,363.6,-0.4).lineTo(366.6,-1.5).curveTo(367.1,-1.7,366.7,-2).lineTo(365.1,-3.7).closePath().moveTo(-363.5,-0.8).lineTo(-363.2,-4.4).lineTo(-364.9,-4.2).lineTo(-366.1,-3).lineTo(-366.7,-2.4).lineTo(-366.9,-1.9).lineTo(-370.4,-3.1).lineTo(-369.9,-3.5).lineTo(-369.2,-4.1).lineTo(-364,-9.4).lineTo(-363.1,-10.6).lineTo(-359.9,-9.5).lineTo(-363.9,-5.3).lineTo(-358.4,-5.9).lineTo(-357.7,-6.2).lineTo(-355,-5.2).lineTo(-356.7,-5.1).lineTo(-359.6,-4.8).lineTo(-360,-0.7).curveTo(-360,-0.4,-359.9,0.5).closePath().moveTo(371.3,-3.5).lineTo(368.1,-6.7).lineTo(366.9,-7.6).lineTo(370.1,-8.8).lineTo(370.7,-8.2).curveTo(370.4,-8.9,371.2,-9.2).lineTo(375,-10.7).curveTo(377,-11.4,378.4,-10).lineTo(381.2,-7.1).curveTo(381.6,-6.5,382.4,-6.1).lineTo(378.9,-4.8).curveTo(378.6,-5.4,378.1,-5.9).lineTo(375.1,-9).curveTo(374.7,-9.4,374.2,-9.2).lineTo(371.6,-8.2).curveTo(371.1,-8,371.4,-7.6).lineTo(374.3,-4.6).lineTo(375.5,-3.6).lineTo(372.1,-2.3).curveTo(371.8,-2.9,371.3,-3.5).closePath().moveTo(-374.8,-4.7).curveTo(-374.2,-5.1,-373.6,-5.7).lineTo(-370.4,-8.9).curveTo(-370,-9.2,-370.5,-9.4).lineTo(-373.1,-10.3).curveTo(-373.6,-10.5,-374,-10.1).lineTo(-377.3,-7).lineTo(-377.9,-6.2).lineTo(-378.1,-5.9).lineTo(-381.6,-7.1).curveTo(-380.8,-7.6,-380.3,-8.1).lineTo(-376.9,-11.3).lineTo(-375.9,-12.5).lineTo(-372.9,-11.4).lineTo(-373.4,-10.8).lineTo(-373.3,-10.8).curveTo(-372.5,-11.3,-371.9,-11).lineTo(-368.1,-9.7).curveTo(-366.1,-8.9,-367.5,-7.5).lineTo(-370.5,-4.6).lineTo(-371.4,-3.5).lineTo(-371.5,-3.5).closePath().moveTo(382.6,-7.5).lineTo(377.5,-12.7).curveTo(376.8,-13.3,376.2,-13.7).lineTo(379.4,-14.9).lineTo(383.5,-10.9).lineTo(385.3,-14.1).curveTo(385.3,-14.1,385.4,-14.2).curveTo(385.4,-14.2,385.4,-14.3).curveTo(385.4,-14.3,385.4,-14.4).curveTo(385.3,-14.4,385.3,-14.5).lineTo(388.1,-15.5).lineTo(387.4,-14.6).lineTo(386.3,-12.9).lineTo(392,-10.9).lineTo(393.9,-10.4).lineTo(390.3,-9.1).lineTo(385.1,-10.9).lineTo(384.6,-9.9).lineTo(385.7,-8.8).curveTo(386.1,-8.2,386.9,-7.8).lineTo(383.4,-6.5).curveTo(383.1,-7.1,382.6,-7.5).closePath().moveTo(-385.2,-8.4).lineTo(-384.7,-9.1).lineTo(-384.7,-9.1).curveTo(-385.7,-8.7,-386.4,-9).lineTo(-390.2,-10.4).curveTo(-391.2,-10.9,-391.2,-11.4).curveTo(-391.3,-11.9,-390.3,-12.9).lineTo(-390.1,-13.1).curveTo(-389.1,-14,-388.2,-14.3).curveTo(-387.3,-14.5,-386.2,-14.1).lineTo(-381.9,-12.5).curveTo(-381.6,-12.3,-381.2,-12.6).lineTo(-380.9,-12.9).curveTo(-380.8,-13,-380.8,-13).curveTo(-380.8,-13.1,-380.8,-13.1).curveTo(-380.8,-13.2,-380.9,-13.2).curveTo(-381,-13.3,-381.1,-13.3).lineTo(-385.7,-15.1).curveTo(-386.3,-15.3,-387.1,-15.4).lineTo(-385.9,-16.3).lineTo(-378.8,-13.6).curveTo(-376.8,-12.8,-378.3,-11.4).lineTo(-381.6,-8.4).curveTo(-382.1,-7.9,-382.4,-7.4).closePath().moveTo(-386.5,-12.5).lineTo(-387.9,-11.2).curveTo(-388.3,-10.9,-387.9,-10.7).lineTo(-385.2,-9.7).curveTo(-384.6,-9.5,-384.3,-9.8).lineTo(-382.5,-11.5).lineTo(-385.6,-12.7).lineTo(-386,-12.7).curveTo(-386.3,-12.7,-386.5,-12.5).closePath().moveTo(393.5,-12.1).lineTo(390.8,-14.7).curveTo(389.2,-16.1,391.3,-16.9).lineTo(397.1,-19.1).curveTo(399,-20,400.4,-18.7).lineTo(402.3,-16.9).lineTo(395.6,-14.2).lineTo(396.5,-13.3).curveTo(396.9,-12.9,397.5,-13.1).lineTo(402.8,-15.2).lineTo(403.6,-15.7).lineTo(404.3,-14.6).lineTo(396.8,-11.7).curveTo(396,-11.4,395.4,-11.4).curveTo(394.3,-11.4,393.5,-12.1).closePath().moveTo(396.4,-17.8).lineTo(393.7,-16.6).curveTo(393.1,-16.5,393.6,-16.1).lineTo(394.7,-15).lineTo(398.4,-16.5).lineTo(397.4,-17.5).curveTo(397.1,-17.8,396.7,-17.8).lineTo(396.4,-17.8).closePath().moveTo(-395.5,-12.5).lineTo(-404.1,-16.1).lineTo(-402.8,-16.9).lineTo(-396.7,-22.1).curveTo(-396.1,-22.6,-395.8,-23.2).lineTo(-387.4,-19.6).curveTo(-386.4,-19.3,-386.3,-18.7).curveTo(-386.1,-18.1,-386.8,-17.4).lineTo(-388.2,-16.4).curveTo(-388.7,-15.8,-389.5,-15.8).curveTo(-390.2,-15.8,-391.7,-16.4).lineTo(-391.7,-16.3).curveTo(-390.4,-15.7,-390.1,-15.3).curveTo(-389.9,-14.8,-390.5,-14.3).lineTo(-392,-13).curveTo(-392.7,-12.4,-393.6,-12.3).lineTo(-394.2,-12.2).curveTo(-394.9,-12.2,-395.5,-12.5).closePath().moveTo(-399.7,-15.6).lineTo(-396,-14).curveTo(-395.5,-13.9,-394.9,-14.3).lineTo(-393.5,-15.6).curveTo(-393,-16.1,-393.5,-16.4).lineTo(-397.1,-17.9).closePath().moveTo(-396,-18.8).lineTo(-392.5,-17.2).curveTo(-391.9,-17,-391.3,-17.4).lineTo(-390,-18.7).curveTo(-389.4,-19.1,-389.9,-19.3).lineTo(-393.5,-20.9).closePath().moveTo(404.7,-16.3).lineTo(401.2,-19.4).lineTo(400,-20.3).lineTo(402.8,-21.5).lineTo(403.5,-21).lineTo(403.6,-21).curveTo(403,-21.6,404.1,-22.1).lineTo(406.7,-23.2).lineTo(408,-22).lineTo(405.9,-21.4).lineTo(404.6,-20.9).curveTo(404.2,-20.6,404.6,-20.3).lineTo(407.6,-17.5).lineTo(408.9,-16.6).lineTo(405.5,-15.3).curveTo(405.3,-15.7,404.7,-16.3).closePath().moveTo(-533.1,-36.8).lineTo(-531.4,-37.7).lineTo(-526.3,-40.7).lineTo(-524.8,-41.9).lineTo(-522.3,-40.3).lineTo(-523.1,-39.7).curveTo(-522.1,-40.2,-521.1,-39.6).lineTo(-518.8,-38.1).lineTo(-520.6,-37).curveTo(-521.2,-37.6,-522.1,-38.1).lineTo(-523.3,-38.8).curveTo(-523.7,-39.2,-524.2,-38.8).lineTo(-528.7,-36.1).lineTo(-530.3,-35).closePath().moveTo(-540.5,-41.7).curveTo(-542.1,-42.8,-540.1,-44.1).lineTo(-535.9,-46.5).curveTo(-533.6,-47.8,-532.1,-46.6).lineTo(-527.2,-43.4).curveTo(-525.5,-42.3,-527.7,-41).lineTo(-530.5,-39.4).lineTo(-536.1,-43.2).lineTo(-537.7,-42.3).curveTo(-538.3,-42,-537.9,-41.6).lineTo(-533.4,-38.7).curveTo(-533.1,-38.4,-532.6,-38.2).lineTo(-534.2,-37.5).closePath().moveTo(-533.1,-45).lineTo(-534.8,-43.9).lineTo(-531.7,-41.8).lineTo(-529.9,-42.9).curveTo(-529.5,-43.2,-529.8,-43.5).lineTo(-532.1,-45).lineTo(-532.5,-45.1).curveTo(-532.8,-45.1,-533.1,-45).closePath().moveTo(530.9,-38.8).lineTo(522.3,-43.4).lineTo(520.6,-44.1).lineTo(527.6,-49.2).curveTo(529.7,-50.7,531.9,-49.6).lineTo(534.9,-48).curveTo(537.2,-46.8,535.1,-45.2).lineTo(531,-42.2).lineTo(533.6,-40.8).curveTo(534.4,-40.4,535.3,-40.2).lineTo(532.3,-37.9).curveTo(531.7,-38.5,530.9,-38.8).closePath().moveTo(527.9,-47.6).lineTo(524.9,-45.3).lineTo(529.5,-43).lineTo(532.5,-45.2).curveTo(532.9,-45.5,532.8,-45.7).curveTo(532.8,-45.9,532.2,-46.2).lineTo(529.6,-47.6).curveTo(529,-47.9,528.6,-47.8).lineTo(528.4,-47.8).curveTo(528.2,-47.8,527.9,-47.6).closePath().moveTo(-548,-42.9).lineTo(-553.8,-47.1).lineTo(-552.3,-48.1).curveTo(-552.1,-47.6,-551.1,-47).lineTo(-548,-44.6).curveTo(-547.5,-44.3,-546.6,-44.7).lineTo(-544.6,-45.8).curveTo(-545.8,-45.5,-546.4,-45.9).lineTo(-549.2,-48).curveTo(-550.8,-49.2,-548.5,-50.4).lineTo(-543.7,-53).curveTo(-542.8,-53.4,-542.1,-54).lineTo(-539.5,-52.1).lineTo(-546.4,-48.5).curveTo(-546.9,-48.2,-546.6,-47.8).lineTo(-544.6,-46.4).curveTo(-544.1,-46.1,-543.5,-46.4).lineTo(-538.4,-49.1).lineTo(-536.8,-50.1).lineTo(-534.3,-48.3).lineTo(-544.2,-43).curveTo(-545.2,-42.4,-546.1,-42.4).lineTo(-546.3,-42.4).curveTo(-547.3,-42.4,-548,-42.9).closePath().moveTo(540.7,-46.5).lineTo(532.4,-50.6).lineTo(530.5,-51.4).lineTo(533,-53.4).lineTo(543.2,-48.4).curveTo(544.1,-47.9,545,-47.6).lineTo(542.4,-45.5).curveTo(541.7,-46.1,540.7,-46.5).closePath().moveTo(543.1,-49.7).lineTo(542.6,-49.9).curveTo(541.1,-50.6,540.7,-51.2).curveTo(540.4,-51.8,541.3,-52.5).lineTo(544.5,-55.2).curveTo(544.6,-55.3,544.6,-55.4).curveTo(544.6,-55.4,544.6,-55.5).curveTo(544.6,-55.5,544.6,-55.6).curveTo(544.5,-55.6,544.4,-55.7).lineTo(543.8,-56).curveTo(543.4,-56.2,543.1,-55.9).lineTo(539.5,-52.9).curveTo(539.1,-52.6,538.7,-52).lineTo(537.3,-52.9).lineTo(542.8,-57.4).curveTo(544.3,-58.7,546.7,-57.6).lineTo(551.6,-55.2).lineTo(553.3,-54.7).lineTo(551.3,-52.9).lineTo(550.3,-53.2).lineTo(550.2,-53.2).curveTo(551,-52.5,550.4,-52.1).lineTo(547.5,-49.6).curveTo(546.7,-49,545.7,-49).curveTo(544.6,-49,543.1,-49.7).closePath().moveTo(543.8,-52.8).curveTo(543.4,-52.5,544,-52.2).lineTo(546.2,-51.2).curveTo(546.8,-50.9,547.1,-51.2).lineTo(549.3,-53).curveTo(549.6,-53.3,549,-53.5).lineTo(546.2,-54.9).closePath().moveTo(-553.7,-51.4).lineTo(-552.8,-52).lineTo(-552.9,-52).curveTo(-554.1,-51.7,-554.6,-52.2).lineTo(-557.5,-54.5).curveTo(-558.2,-55.1,-557.9,-55.8).curveTo(-557.7,-56.4,-556,-57.1).lineTo(-555.6,-57.4).curveTo(-554.1,-58.1,-553,-58.3).curveTo(-552,-58.3,-551.2,-57.7).lineTo(-548,-55.1).curveTo(-547.7,-54.9,-547.3,-55.1).lineTo(-546.6,-55.3).curveTo(-546.6,-55.4,-546.5,-55.5).curveTo(-546.5,-55.5,-546.5,-55.6).curveTo(-546.5,-55.6,-546.5,-55.7).curveTo(-546.5,-55.7,-546.6,-55.8).lineTo(-550.2,-58.7).lineTo(-551.2,-59.3).lineTo(-549.6,-59.9).lineTo(-544.2,-55.7).curveTo(-542.7,-54.4,-545,-53.2).lineTo(-550.2,-50.6).lineTo(-551.6,-49.7).closePath().moveTo(-552.5,-56).lineTo(-554.7,-55).curveTo(-555.3,-54.6,-554.9,-54.3).lineTo(-552.9,-52.7).curveTo(-552.6,-52.4,-551.9,-52.7).lineTo(-549.1,-54.1).lineTo(-551.5,-56).curveTo(-551.6,-56.1,-551.6,-56.1).curveTo(-551.7,-56.1,-551.7,-56.2).curveTo(-551.8,-56.2,-551.8,-56.2).curveTo(-551.9,-56.2,-552,-56.2).lineTo(-552.5,-56).closePath().moveTo(479.4,-54.6).lineTo(472.1,-59).curveTo(471.7,-59.4,470.8,-59.7).lineTo(477.9,-64.1).curveTo(478.7,-64.6,479.7,-64.6).curveTo(480.6,-64.5,481.5,-64.1).lineTo(483.1,-63.2).curveTo(483.8,-62.7,483.6,-62.2).curveTo(483.5,-61.8,482.4,-61.1).lineTo(482.5,-61.1).curveTo(483.6,-61.6,484.4,-61.9).curveTo(485.2,-61.8,485.9,-61.3).lineTo(487.6,-60.3).curveTo(488.4,-59.8,488.4,-59.3).curveTo(488.5,-58.6,487.7,-58.1).lineTo(480.5,-53.7).lineTo(479.4,-54.6).closePath().moveTo(482.1,-60).lineTo(479,-58.1).lineTo(482,-56.2).lineTo(485.2,-58).curveTo(485.6,-58.4,485,-58.7).lineTo(483.2,-59.8).curveTo(482.9,-60.1,482.5,-60.1).lineTo(482.1,-60).closePath().moveTo(477.9,-62.5).lineTo(474.9,-60.7).lineTo(477.7,-58.8).lineTo(480.9,-60.7).curveTo(481.3,-61,480.7,-61.4).lineTo(479,-62.4).curveTo(478.6,-62.7,478.3,-62.7).lineTo(477.9,-62.5).closePath().moveTo(556,-54.7).curveTo(556.8,-55,557.5,-55.7).lineTo(560.4,-58.3).curveTo(560.8,-58.7,560,-59).lineTo(557.7,-60.1).curveTo(558.6,-59.5,558.1,-58.9).lineTo(555.6,-56.6).curveTo(554.2,-55.4,551.7,-56.3).lineTo(546.8,-58.5).curveTo(545.7,-58.9,544.9,-59.2).lineTo(547.1,-61.2).lineTo(554.1,-58.2).curveTo(554.7,-57.9,555.1,-58.3).lineTo(556.9,-59.9).curveTo(557.4,-60.2,556.7,-60.5).lineTo(551.4,-62.8).lineTo(549.5,-63.4).lineTo(551.6,-65.5).lineTo(562.1,-61.2).curveTo(563,-60.6,563.3,-60.2).curveTo(563.7,-59.4,563,-58.8).lineTo(557.9,-54.1).closePath().moveTo(-479.3,-58).curveTo(-478.5,-58.3,-477.7,-58.8).lineTo(-473.5,-61.6).lineTo(-472.1,-62.6).lineTo(-469.9,-61.3).lineTo(-470.5,-60.7).lineTo(-470.4,-60.7).curveTo(-469.5,-61.2,-468.6,-60.6).lineTo(-466.6,-59.5).lineTo(-468.1,-58.4).curveTo(-468.6,-58.9,-469.5,-59.4).lineTo(-470.5,-60).curveTo(-471,-60.3,-471.5,-59.9).lineTo(-475.3,-57.4).lineTo(-476.5,-56.5).closePath().moveTo(-562.2,-58.6).curveTo(-561.2,-58.9,-560.3,-59.3).lineTo(-551.4,-63.5).lineTo(-549.7,-64.4).lineTo(-547.4,-62.5).lineTo(-558.1,-57.5).curveTo(-559.1,-57,-559.8,-56.5).closePath().moveTo(-486.2,-62.3).curveTo(-487.8,-63.2,-485.7,-64.3).lineTo(-482.2,-66.6).curveTo(-480.4,-67.7,-478.8,-66.7).lineTo(-474.4,-64).curveTo(-472.9,-63,-474.7,-61.9).lineTo(-477.1,-60.3).lineTo(-482.4,-63.5).lineTo(-483.7,-62.7).curveTo(-484.2,-62.5,-483.8,-62.2).lineTo(-479.7,-59.6).lineTo(-478.9,-59.3).lineTo(-480.3,-58.6).closePath().moveTo(-479.7,-65.2).lineTo(-481.2,-64.2).lineTo(-478.3,-62.5).lineTo(-476.8,-63.4).curveTo(-476.3,-63.7,-476.6,-64).lineTo(-478.8,-65.3).lineTo(-479.2,-65.4).curveTo(-479.4,-65.4,-479.7,-65.2).closePath().moveTo(490.3,-60.5).curveTo(489.3,-60.5,488.2,-61.3).lineTo(487.7,-61.4).curveTo(486.4,-62.2,486.3,-62.8).curveTo(486.1,-63.3,486.9,-63.9).lineTo(490.2,-66).curveTo(490.3,-66.1,490.3,-66.1).curveTo(490.4,-66.2,490.4,-66.3).curveTo(490.4,-66.3,490.3,-66.4).curveTo(490.3,-66.4,490.2,-66.5).lineTo(489.8,-66.8).curveTo(489.4,-67,489.1,-66.7).lineTo(485.4,-64.2).curveTo(484.9,-64,484.7,-63.5).lineTo(483.5,-64.3).lineTo(489.1,-68).curveTo(490.7,-69.1,492.6,-68).lineTo(496.7,-65.6).lineTo(498.2,-65).lineTo(496,-63.5).lineTo(495.1,-63.9).lineTo(495,-63.9).curveTo(495.6,-63.3,495,-62.9).lineTo(491.9,-60.8).curveTo(491.4,-60.5,490.7,-60.5).lineTo(490.3,-60.5).closePath().moveTo(489.3,-64).curveTo(488.8,-63.7,489.4,-63.4).lineTo(491.2,-62.4).curveTo(491.6,-62.1,492,-62.3).lineTo(494.2,-63.8).curveTo(494.5,-64,494,-64.2).lineTo(491.8,-65.6).closePath().moveTo(-560.4,-63).lineTo(-563.8,-66.1).lineTo(-566.7,-64.9).curveTo(-567.4,-64.5,-568.2,-64.1).lineTo(-570.7,-66.4).curveTo(-569.6,-66.6,-568.9,-66.9).lineTo(-559.4,-71.2).curveTo(-558.6,-71.5,-558,-72.1).lineTo(-552.2,-66.7).curveTo(-550.4,-65.1,-553,-64).lineTo(-556.1,-62.5).curveTo(-557.2,-62.1,-558.1,-62.1).curveTo(-559.4,-62.1,-560.4,-63).closePath().moveTo(-562.2,-66.9).lineTo(-559.8,-64.6).curveTo(-559.4,-64.3,-559,-64.3).lineTo(-558.1,-64.6).lineTo(-555.3,-65.8).curveTo(-554.7,-66.1,-554.6,-66.4).curveTo(-554.5,-66.6,-554.8,-66.8).lineTo(-557.2,-69.2).closePath().moveTo(559.3,-63.3).lineTo(554.8,-65.1).curveTo(552.3,-66.1,553.5,-67.4).lineTo(557.4,-71.2).curveTo(558.5,-72.5,561.1,-71.5).lineTo(564.2,-70.3).lineTo(559.8,-65.9).lineTo(561.5,-65.1).curveTo(562.2,-65,562.4,-65.2).lineTo(566,-68.8).lineTo(566.5,-69.5).lineTo(567.9,-68.6).lineTo(563,-63.7).curveTo(562.2,-62.9,561.1,-62.9).curveTo(560.3,-62.9,559.3,-63.3).closePath().moveTo(557.8,-69.6).lineTo(556,-67.8).curveTo(555.7,-67.5,556.4,-67.2).lineTo(558.4,-66.5).lineTo(560.7,-68.9).lineTo(558.8,-69.7).lineTo(558.3,-69.8).curveTo(558.2,-69.8,558.2,-69.8).curveTo(558.1,-69.8,558,-69.8).curveTo(558,-69.8,557.9,-69.7).curveTo(557.9,-69.7,557.8,-69.6).closePath().moveTo(-491,-65.3).lineTo(-488.9,-68.7).lineTo(-490.6,-68.9).lineTo(-492.1,-67.9).curveTo(-493,-67.6,-493.5,-67).lineTo(-496,-68.7).lineTo(-494.4,-69.5).lineTo(-487,-73.7).lineTo(-485.6,-74.7).lineTo(-483.3,-73.1).lineTo(-489,-69.7).lineTo(-483.8,-69.5).lineTo(-483.1,-69.5).lineTo(-481.2,-68.2).lineTo(-482.7,-68.4).lineTo(-485.5,-68.6).lineTo(-488,-64.8).lineTo(-488.4,-63.6).closePath().moveTo(497.5,-66.3).lineTo(493,-68.7).lineTo(491.2,-69.5).lineTo(493.5,-71.1).lineTo(494.3,-70.7).curveTo(493.7,-71.3,494.3,-71.6).lineTo(497.1,-73.7).curveTo(498.5,-74.7,500.4,-73.7).lineTo(504.6,-71.4).lineTo(506.2,-70.7).lineTo(503.7,-68.9).lineTo(502.4,-69.8).lineTo(498,-72.2).curveTo(497.5,-72.4,497.1,-72.2).lineTo(495.2,-70.8).curveTo(494.8,-70.5,495.3,-70.3).lineTo(499.7,-67.9).lineTo(501.4,-67.2).lineTo(498.9,-65.3).curveTo(498.3,-66,497.5,-66.3).closePath().moveTo(-499,-71.1).lineTo(-497.4,-71.8).lineTo(-492.8,-74.2).curveTo(-492.3,-74.4,-492.7,-74.8).lineTo(-494.4,-76).curveTo(-494.8,-76.3,-495.4,-76.1).lineTo(-499.9,-73.7).curveTo(-500.7,-73.2,-501.3,-72.8).lineTo(-503.6,-74.6).curveTo(-502.7,-74.8,-501.9,-75.2).lineTo(-497.2,-77.7).lineTo(-495.7,-78.6).lineTo(-493.6,-77.1).lineTo(-494.5,-76.6).lineTo(-494.4,-76.6).curveTo(-493.5,-76.9,-492.9,-76.6).lineTo(-490.3,-74.5).curveTo(-488.9,-73.5,-491,-72.4).lineTo(-495.3,-70.2).curveTo(-496.2,-69.8,-496.8,-69.3).closePath().moveTo(566.9,-70.3).lineTo(561.1,-72.4).curveTo(560,-72.9,559.1,-73.1).lineTo(560.8,-75).lineTo(562,-74.8).lineTo(562,-74.8).curveTo(561,-75.2,561.8,-76).lineTo(563.3,-77.7).lineTo(565.4,-76.9).curveTo(564.8,-76.5,564.1,-75.8).lineTo(563.2,-74.9).curveTo(562.9,-74.5,563.7,-74.3).lineTo(568.7,-72.4).lineTo(570.6,-71.9).lineTo(568.7,-69.5).curveTo(568,-70,566.9,-70.3).closePath().moveTo(505.5,-72.2).lineTo(498,-75.9).curveTo(497.2,-76.4,496.3,-76.6).lineTo(498.5,-78.3).lineTo(504.5,-75.4).lineTo(504.3,-78.6).lineTo(504.1,-79.1).lineTo(506,-80.5).lineTo(505.8,-79.5).lineTo(505.8,-77.8).lineTo(512.3,-76.9).lineTo(514.2,-76.9).lineTo(511.7,-75).lineTo(506,-75.7).lineTo(506,-74.7).lineTo(507.6,-73.8).curveTo(508.6,-73.3,509.3,-73.1).lineTo(507,-71.3).lineTo(505.5,-72.2).closePath().moveTo(-506,-76.5).lineTo(-505.2,-77).curveTo(-506.3,-76.7,-506.8,-77.2).lineTo(-509.2,-79.3).curveTo(-510,-79.8,-509.6,-80.4).curveTo(-509.3,-80.9,-508,-81.7).lineTo(-507.5,-81.9).curveTo(-506.1,-82.5,-505.2,-82.5).curveTo(-504.3,-82.6,-503.5,-82).lineTo(-500.8,-79.6).curveTo(-500.6,-79.5,-500.1,-79.6).lineTo(-499.7,-79.9).curveTo(-499.6,-79.9,-499.5,-80).curveTo(-499.5,-80,-499.5,-80.1).curveTo(-499.5,-80.1,-499.5,-80.2).curveTo(-499.5,-80.3,-499.6,-80.3).lineTo(-502.6,-82.9).curveTo(-503,-83.1,-503.5,-83.5).lineTo(-502.1,-84).lineTo(-497.4,-80.1).curveTo(-496.2,-79,-498.2,-78).lineTo(-502.8,-75.8).curveTo(-503.6,-75.4,-504.2,-75).closePath().moveTo(-504.7,-80.5).lineTo(-506.8,-79.6).curveTo(-507.3,-79.4,-507,-79.1).lineTo(-505.2,-77.6).curveTo(-504.9,-77.4,-504.4,-77.6).lineTo(-501.8,-78.8).lineTo(-503.8,-80.5).curveTo(-503.9,-80.6,-504,-80.6).curveTo(-504,-80.6,-504.1,-80.7).curveTo(-504.1,-80.7,-504.2,-80.7).curveTo(-504.2,-80.7,-504.3,-80.7).lineTo(-504.7,-80.5).closePath().moveTo(512.6,-78.4).lineTo(508.9,-80.1).curveTo(506.7,-81.1,508,-82.2).lineTo(511.7,-85.5).curveTo(513,-86.6,515.2,-85.6).lineTo(517.8,-84.4).lineTo(513.5,-80.6).lineTo(515,-80).curveTo(515.5,-79.7,515.8,-80).lineTo(519.2,-83).curveTo(519.6,-83.2,519.8,-83.6).lineTo(520.9,-82.8).lineTo(516.1,-78.5).curveTo(515.4,-77.9,514.4,-77.9).curveTo(513.6,-77.9,512.6,-78.4).closePath().moveTo(512,-84).lineTo(510.3,-82.5).curveTo(509.9,-82.3,510.6,-82).lineTo(512.1,-81.2).lineTo(514.5,-83.3).lineTo(512.9,-84).lineTo(512.4,-84.1).lineTo(512,-84).closePath().moveTo(-511,-81.7).curveTo(-512.1,-81.7,-512.6,-82.3).lineTo(-517.8,-87.3).lineTo(-516.2,-87.8).lineTo(-507.7,-91.6).lineTo(-506.3,-92.2).lineTo(-501.3,-87.3).curveTo(-500.6,-86.8,-500.8,-86.2).curveTo(-501.1,-85.6,-502.1,-85.1).lineTo(-503.9,-84.4).curveTo(-504.8,-84,-505.4,-84.1).curveTo(-506.1,-84.3,-507,-85).lineTo(-507,-85).curveTo(-506.3,-84.2,-506.2,-83.8).curveTo(-506.3,-83.3,-507.2,-82.9).lineTo(-509.3,-82).curveTo(-510.1,-81.6,-510.9,-81.6).lineTo(-511,-81.7).closePath().moveTo(-514.3,-86).lineTo(-512.1,-83.8).curveTo(-511.7,-83.6,-511.1,-83.8).lineTo(-508.9,-84.8).curveTo(-508.2,-85.1,-508.6,-85.4).lineTo(-510.7,-87.5).closePath().moveTo(-509.2,-88.2).lineTo(-507.1,-86).curveTo(-506.7,-85.8,-506.1,-86).lineTo(-504.1,-86.9).curveTo(-503.2,-87.2,-503.5,-87.5).lineTo(-505.8,-89.7).closePath().moveTo(520.2,-84.4).lineTo(515.3,-86.5).lineTo(513.5,-87).lineTo(515.3,-88.7).lineTo(516.2,-88.3).curveTo(515.4,-88.8,516.2,-89.5).lineTo(517.6,-91).lineTo(519.5,-90.2).curveTo(518.9,-89.8,518.2,-89.2).lineTo(517.4,-88.5).curveTo(517,-88.2,517.6,-88).lineTo(522.1,-86.1).curveTo(522.9,-85.7,523.8,-85.5).lineTo(521.7,-83.6).curveTo(521.1,-84,520.2,-84.4).closePath();
	this.shape_1.setTransform(635.3,533);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.textMC}]}).wait(1));

	// bgseat
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("rgba(0,0,0,0.4)").beginStroke().moveTo(-176.2,150.3).curveTo(-308.5,142,-429.4,101.2).curveTo(-533.7,66.4,-600.5,9.9).curveTo(-633.5,-20.8,-640.2,-56.7).lineTo(-640.2,-126.8).lineTo(-632,-128.2).curveTo(-592.4,-80.2,-569,-62.5).curveTo(-546.5,-45.4,-516.7,-29.5).lineTo(-507.8,-24.8).curveTo(-496.8,-19.2,-484.9,-13.7).lineTo(-483.5,-13).lineTo(-482.5,-12.6).curveTo(-469.6,-6.8,-455.6,-1).curveTo(-406.1,19.2,-350.9,34).lineTo(-341.8,36.5).lineTo(-324.8,40.7).lineTo(-322.1,41.3).curveTo(-237.7,61.4,-140.9,69.4).lineTo(-124.8,70.6).lineTo(-115.6,71.3).lineTo(-112.9,71.4).curveTo(-61.9,74.7,-7.7,74.7).curveTo(55.3,74.7,113.8,70.3).lineTo(116.5,70.1).lineTo(125.2,69.4).lineTo(143.2,67.8).curveTo(237.3,58.9,319.5,38.3).lineTo(322.2,37.6).curveTo(330.3,35.5,338.3,33.3).lineTo(345.8,31.3).curveTo(395.4,17.3,440.4,-1).curveTo(458.5,-8.5,474.9,-16.1).lineTo(477.2,-17.2).curveTo(488.9,-22.7,500,-29.1).lineTo(504.3,-31.5).curveTo(567.1,-68.5,613.3,-130.9).lineTo(640.2,-126.1).lineTo(640.2,-58.1).curveTo(629.9,-18.5,595.8,14.6).curveTo(523.8,72,428.3,101.9).curveTo(307.7,140,179.2,150.6).curveTo(90.9,157.4,3,157.4).curveTo(-86.8,157.4,-176.2,150.3).closePath().moveTo(-94.4,5.2).lineTo(-96.9,5).lineTo(-97.1,5).lineTo(-112.4,3.8).curveTo(-131.9,2.1,-150.8,-0.1).curveTo(-172,-2.6,-192.6,-5.9).lineTo(-195.2,-6.4).curveTo(-235.6,-12.9,-272.9,-22.4).lineTo(-273.5,-22.5).lineTo(-275.5,-23).lineTo(-282.1,-24.7).curveTo(-329.6,-37.3,-372.5,-54.7).lineTo(-382.5,-58.9).lineTo(-383.6,-59.4).lineTo(-386.1,-60.4).lineTo(-398,-65.7).curveTo(-405,-68.9,-411.5,-72.1).lineTo(-413.7,-73.1).lineTo(-414.3,-73.4).lineTo(-418.9,-75.7).curveTo(-435.7,-84.3,-450.2,-93.2).curveTo(-464.8,-102.2,-476.9,-111.6).lineTo(-482.1,-115.6).curveTo(-501,-131,-515,-148.9).lineTo(-467,-157.4).curveTo(-462.7,-152.1,-459.7,-148.8).lineTo(-458.2,-147.2).lineTo(-452.5,-141.4).lineTo(-450.8,-139.9).curveTo(-446.4,-135.7,-441.5,-131.6).lineTo(-439.6,-130.1).curveTo(-429.5,-121.9,-417.5,-114.1).lineTo(-415.5,-112.8).curveTo(-406.2,-106.9,-395.7,-101.1).lineTo(-393.9,-100.2).curveTo(-386,-95.9,-377.3,-91.7).lineTo(-375.1,-90.6).curveTo(-363.5,-85.1,-347.1,-78.1).lineTo(-346.6,-77.9).lineTo(-346.5,-77.9).lineTo(-345.8,-77.6).lineTo(-338.5,-74.7).lineTo(-335.8,-73.6).curveTo(-294.6,-57.5,-248.6,-46.1).lineTo(-245.9,-45.5).curveTo(-211,-36.9,-173.3,-31.1).lineTo(-172.5,-31).curveTo(-153.3,-28.1,-134.2,-25.9).curveTo(-110,-23.1,-85.7,-21.5).lineTo(-83.2,-21.3).curveTo(-42.3,-18.6,1,-18.6).curveTo(43.8,-18.6,83.8,-21.2).lineTo(86.4,-21.4).curveTo(111,-23,134.7,-25.7).curveTo(152.8,-27.7,170.4,-30.3).lineTo(170.5,-30.3).lineTo(171.2,-30.4).curveTo(212.1,-36.7,246.7,-45.1).lineTo(249.3,-45.8).curveTo(295.8,-57.2,337.4,-73.4).lineTo(340.1,-74.4).lineTo(351.4,-79).lineTo(352,-79.3).curveTo(364.4,-84.5,375.7,-89.8).lineTo(377.9,-90.9).curveTo(387.3,-95.5,396.1,-100.1).lineTo(397.9,-101.1).curveTo(408.3,-106.8,417.6,-112.7).lineTo(419.5,-114).curveTo(431.6,-121.8,441.5,-129.9).lineTo(443.5,-131.4).curveTo(453.2,-139.4,460.9,-147.8).lineTo(462.4,-149.4).curveTo(464.8,-152,468.4,-156.5).lineTo(514.3,-148.4).curveTo(482,-107.9,417.4,-75.2).lineTo(413.3,-73.1).lineTo(413,-73).lineTo(410.8,-71.9).curveTo(399.2,-66.3,386.5,-60.8).lineTo(383.7,-59.6).lineTo(382,-58.9).lineTo(375.5,-56.1).lineTo(372.9,-55.1).curveTo(329.3,-37.3,280.8,-24.5).lineTo(275.7,-23.2).lineTo(273.7,-22.7).lineTo(273.1,-22.5).curveTo(235.9,-13.1,196.1,-6.6).lineTo(193.5,-6.2).curveTo(172.5,-2.8,150.7,-0.2).curveTo(133.1,1.9,115.1,3.5).curveTo(106.3,4.3,97.6,4.9).lineTo(95,5.1).curveTo(49,8.3,-0.2,8.3).curveTo(-48.8,8.3,-94.4,5.2).closePath();
	this.shape_2.setTransform(640.2,561.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// sidebet
	this.mc_plus_3 = new lib.mc_plus_3();
	this.mc_plus_3.setTransform(1023.4,441.4,1,1,0,0,0,85.2,46.5);

	this.mc_minus_3 = new lib.mc_minus_3();
	this.mc_minus_3.setTransform(867.9,501.4,1,1,0,0,0,109.8,34);

	this.tie_mc = new lib.tie_mc();
	this.tie_mc.setTransform(640.4,525.6,1,1,0,0,0,134.4,17);

	this.mc_plus_2 = new lib.mc_plus_2();
	this.mc_plus_2.setTransform(413.7,501,1,1,0,0,0,109.3,34.3);

	this.mc_minus_2 = new lib.mc_minus_2();
	this.mc_minus_2.setTransform(258.8,440.6,1,1,0,0,0,85.6,47);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_minus_2},{t:this.mc_plus_2},{t:this.tie_mc},{t:this.mc_minus_3},{t:this.mc_plus_3}]}).wait(1));

	// banker
	this.banker_1 = new lib.banker_1();
	this.banker_1.setTransform(1131.5,459.4,1,1,0,0,0,73.9,46.6);

	this.banker_2 = new lib.banker_2();
	this.banker_2.setTransform(1009.3,524.1,1,1,0,0,0,88.3,38.1);

	this.banker_3 = new lib.banker_3();
	this.banker_3.setTransform(853.1,565.8,1,1,0,0,0,97.8,29.1);

	this.banker_4 = new lib.banker_4();
	this.banker_4.setTransform(641.3,582.9,1,1,0,0,0,127.2,18.2);

	this.banker_5 = new lib.banker_5();
	this.banker_5.setTransform(426.4,566.4,1,1,0,0,0,101.5,29.9);

	this.banker_6 = new lib.banker_6();
	this.banker_6.setTransform(265.6,525.2,1,1,0,0,0,92.5,39.7);

	this.banker_7 = new lib.banker_7();
	this.banker_7.setTransform(141.6,460.3,1,1,0,0,0,79.9,48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.banker_7},{t:this.banker_6},{t:this.banker_5},{t:this.banker_4},{t:this.banker_3},{t:this.banker_2},{t:this.banker_1}]}).wait(1));

	// player
	this.player_1 = new lib.player_1();
	this.player_1.setTransform(1175.5,475.7,1,1,0,0,0,78,53.9);

	this.player_2 = new lib.player_2();
	this.player_2.setTransform(1047.7,549.2,1,1,0,0,0,96.8,43.2);

	this.player_3 = new lib.player_3();
	this.player_3.setTransform(877.3,595.7,1,1,0,0,0,108.8,33.4);

	this.player_4 = new lib.player_4();
	this.player_4.setTransform(641.3,615.3,1,1,0,0,0,142,20.4);

	this.player_5 = new lib.player_5();
	this.player_5.setTransform(401.7,597.8,1,1,0,0,0,112.4,32.9);

	this.player_6 = new lib.player_6();
	this.player_6.setTransform(224.2,551.8,1,1,0,0,0,100.7,43.5);

	this.player_7 = new lib.player_7();
	this.player_7.setTransform(90.6,477.6,1,1,0,0,0,82.4,54.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.player_7},{t:this.player_6},{t:this.player_5},{t:this.player_4},{t:this.player_3},{t:this.player_2},{t:this.player_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,392.2,1283.2,326.5);


// stage content:
(lib.gameAssets = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(gameAssets = gameAssets||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var gameAssets, images, createjs, ss;