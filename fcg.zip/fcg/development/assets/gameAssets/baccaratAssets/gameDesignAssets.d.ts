/// <reference path="\..\..\..\def\createjs\createjs.d.ts"/>
declare module GameDesign {
    export class bgMC extends createjs.MovieClip {}
    export class betbarMC extends createjs.MovieClip {}
   }

