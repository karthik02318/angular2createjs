module.exports = function(grunt) {
  grunt.initConfig({
    typescript: {
      default : {
        options: {
        module: 'amd', //or commonjs 
        target: 'es5', //or es3 
        basePath: '',
        sourceMap: false,
        declaration: true
      },
        src: ["development/com/**/*.ts"]
        
      }
    }
  });
  grunt.loadNpmTasks("grunt-typescript");
  grunt.registerTask("default", ["typescript"]);
};